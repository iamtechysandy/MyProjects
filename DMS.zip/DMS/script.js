document.addEventListener("DOMContentLoaded", () => {
  const sidebarItems = document.querySelectorAll(".side-bar-li");
  const contents = document.querySelectorAll(".content");
  const darkModeToggle = document.getElementById("dark-mode-toggle");
  const backToHomeButton = document.getElementById("back-to-home");
  const collapseBtn = document.getElementById("collapse-btn");
  const sidebar = document.querySelector(".side-bar");

  // Function to set active content based on the id
  function setActiveContent(id) {
    // Remove active class from all sidebar items
    sidebarItems.forEach((item) => item.classList.remove("active"));

    // Remove active class from all content divs
    contents.forEach((content) => content.classList.remove("active"));

    // Add active class to the clicked item and corresponding content
    const activeItem = document.getElementById(id);
    if (activeItem) {
      activeItem.classList.add("active");
      document.getElementById(id + "-content").classList.add("active");
    }
  }

  // Load the active item from localStorage
  const activeItemId = localStorage.getItem("activeSidebarItem") || "home";
  setActiveContent(activeItemId);

  // Add click event listener to sidebar items
  sidebarItems.forEach((item) => {
    item.addEventListener("click", () => {
      // Save the clicked item's ID in localStorage
      localStorage.setItem("activeSidebarItem", item.id);

      // Set the clicked item as active
      setActiveContent(item.id);
    });
  });

  // Add click event listener to "Back to Home" button
  backToHomeButton?.addEventListener("click", () => {
    window.location.href = "index.html";
  });

  // Handle sidebar collapse
  collapseBtn.addEventListener("click", () => {
    sidebar.classList.toggle("collapsed");
  });
});
