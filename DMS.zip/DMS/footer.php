<style>
    footer {



        width: 100%;
        position: fixed;
        bottom: 0;
    }

    footer p {
        padding-left: 40rem;
    }
</style>

<footer>
    <p class="text-muted"> &copy; <?php echo date("Y"); ?> DMS || <a href="https://techysandy.com" target="blank">Techysandy.com</a></p>
</footer>