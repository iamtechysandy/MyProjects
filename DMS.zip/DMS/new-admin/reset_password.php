<?php
// reset_password.php

header('Content-Type: application/json');

try {
    // Validate and sanitize input
    $input = json_decode(file_get_contents('php://input'), true);

    // Check if 'id' and 'newPassword' keys exist in the input array
    if (!isset($input['id']) || !isset($input['newPassword'])) {
        throw new Exception('Invalid input');
    }

    $employeeId = filter_var($input['id'], FILTER_VALIDATE_INT);
    $newPassword = filter_var($input['newPassword'], FILTER_SANITIZE_SPECIAL_CHARS);

    if (!$employeeId || !$newPassword) {
        throw new Exception('Invalid input');
    }

    // Replace with your database connection details
    $conn = new PDO('mysql:host=localhost;dbname=user_management', 'root', '');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Hash the new password
    $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);

    $sql = "UPDATE employees SET password = :password WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
    $stmt->bindParam(':id', $employeeId, PDO::PARAM_INT);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Password reset successfully']);
    } else {
        throw new Exception('Failed to reset password');
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
