<style>
    .slider-value {
        display: inline-block;
        width: 40px;
    }

    .employee-details {
        display: none;
    }

    .select2-container--bootstrap5 .select2-selection--single {
        height: 38px;
        padding: 6px 12px;
        font-size: 14px;
        line-height: 1.428571429;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
</style>

<div class="container mt-5">
    <h2>Employee Permissions Management</h2>
    <div>
        <div id="messageContainer"></div>
        <form id="permissionsForm" method="POST" action="update_employee_permissions.php">
            <label for="employeeSelect">Select Employee:</label>
            <input type="text" id="employeeSearch" class="form-control" placeholder="Search Employee..." onkeyup="searchEmployee()">
            <select id="employeeSelect" class="form-select" name="employeeId" onchange="fetchEmployeePermissions()">
                <option value="">Select an employee</option>
                <!-- PHP code to populate options -->
                <?php
                // Assuming you have a function getAllEmployees() that fetches employee data
                $employees = getAllEmployees(); // Fetch employees from database
                foreach ($employees as $employee) {
                    echo '<option value="' . $employee['id'] . '">' . $employee['fullname'] . '</option>';
                }
                ?>
            </select>
            <div class="mt-3">
                <table class="table table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Permission</th>
                            <th>Allowed</th>
                        </tr>
                    </thead>
                    <tbody id="permissionsTableBody">
                        <!-- Permissions checkboxes will be inserted here -->
                    </tbody>
                </table>
                <button type="button" onclick="savePermissions()" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
    <div id="messageContainer"></div> <!-- Container for success/error message -->

    <h3>Current Employee Permissions</h3>
    <table class="table table-hover">
        <thead class="table-dark">
            <tr>
                <th>Employee Name</th>
                <th>Permission</th>
            </tr>
        </thead>
        <tbody id="currentPermissionsTableBody">
            <!-- Current employee permissions will be inserted here -->
        </tbody>
    </table>
</div>

<script>
    const PERMISSION_HOD = 1;
    const PERMISSION_FULL_DEPT_CONTROL = 2;
    const PERMISSION_CREATE_FOLDERS = 4;
    const PERMISSION_FOLDERS_FULL = 8;
    const PERMISSION_READ_OPTION = 16;
    const PERMISSION_READ_DOWNLOAD = 32;
    const PERMISSION_UPLOAD_READ_DOWNLOAD = 64;
    const PERMISSION_ADMIN = 128;
    const PERMISSION_POWER_USER = 256;

    function calculateAccessCode(selectedPermissions) {
        let accessCode = 0;

        selectedPermissions.forEach(permission => {
            switch (permission) {
                case 'HOD':
                    accessCode |= PERMISSION_HOD;
                    break;
                case 'Full-Department-control':
                    accessCode |= PERMISSION_FULL_DEPT_CONTROL;
                    break;
                case 'Create-Folders':
                    accessCode |= PERMISSION_CREATE_FOLDERS;
                    break;
                case 'Folders-full-permission':
                    accessCode |= PERMISSION_FOLDERS_FULL;
                    break;
                case 'Read-Option':
                    accessCode |= PERMISSION_READ_OPTION;
                    break;
                case 'Read/Download':
                    accessCode |= PERMISSION_READ_DOWNLOAD;
                    break;
                case 'Upload/Read/Download':
                    accessCode |= PERMISSION_UPLOAD_READ_DOWNLOAD;
                    break;
                case 'Admin-permission':
                    accessCode |= PERMISSION_ADMIN;
                    break;
                case 'Global-Search':
                    accessCode |= PERMISSION_POWER_USER;
                    break;
                default:
                    console.error('Unrecognized permission:', permission);
                    break;
            }
        });

        return accessCode;
    }

    function fetchEmployeePermissions() {
        const employeeId = document.getElementById('employeeSelect').value;
        if (!employeeId) {
            document.getElementById('permissionsTableBody').innerHTML = '';
            return;
        }

        fetch(`fetch_employee_permissions.php?id=${employeeId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const permissions = data.permissions;
                const accessCode = parseInt(data.accesscode);

                const permissionsTableBody = document.getElementById('permissionsTableBody');
                permissionsTableBody.innerHTML = '';

                Object.keys(permissions).forEach(permission => {
                    const isChecked = (accessCode & permissions[permission]) === permissions[permission] ? 'checked' : '';
                    const row = `
                        <tr>
                            <td>${permission}</td>
                            <td><input type="checkbox" data-permission="${permission}" name="permissions[]" value="${permissions[permission]}" ${isChecked}></td>
                        </tr>
                    `;
                    permissionsTableBody.insertAdjacentHTML('beforeend', row);
                });

                // Fetch and display current employee permissions
                fetchCurrentEmployeePermissions(employeeId);
            })
            .catch(error => {
                console.error('Error fetching employee permissions:', error);
            });
    }

    function fetchCurrentEmployeePermissions(employeeId) {
        fetch(`fetch_current_employee_permissions.php?id=${employeeId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const currentPermissionsTableBody = document.getElementById('currentPermissionsTableBody');
                currentPermissionsTableBody.innerHTML = '';

                data.forEach(permission => {
                    const row = `
                        <tr>
                            <td>${permission.employeeName}</td>
                            <td>${permission.permissionName}</td>
                        </tr>
                    `;
                    currentPermissionsTableBody.insertAdjacentHTML('beforeend', row);
                });
            })
            .catch(error => {
                console.error('Error fetching current employee permissions:', error);
            });
    }

    function savePermissions() {
        const form = document.getElementById('permissionsForm');
        const formData = new FormData(form);

        fetch('update_employee_permissions.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const messageContainer = document.getElementById('messageContainer');
                if (data.success) {
                    messageContainer.innerHTML = `<div class="alert alert-success" role="alert">${data.success}</div>`;
                    form.reset();
                    document.getElementById('permissionsTableBody').innerHTML = '';
                } else if (data.error) {
                    messageContainer.innerHTML = `<div class="alert alert-danger" role="alert">${data.error}</div>`;
                }
            })
            .catch(error => {
                console.error('Error updating permissions:', error);
            });
    }

    function searchEmployee() {
        const searchValue = document.getElementById('employeeSearch').value.toLowerCase();
        const options = document.getElementById('employeeSelect').options;

        for (let i = 0; i < options.length; i++) {
            const optionText = options[i].text.toLowerCase();
            if (optionText.includes(searchValue)) {
                options[i].style.display = '';
            } else {
                options[i].style.display = 'none';
            }
        }
    }
</script>

<iframe src="upload_per.php" width="100%" height="500px"></iframe>