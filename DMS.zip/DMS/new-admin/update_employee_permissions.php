<?php
// update_employee_permissions.php

// Define permission codes
define('PERMISSION_HOD', 1);
define('PERMISSION_FULL_DEPT_CONTROL', 2);
define('PERMISSION_CREATE_FOLDERS', 4);
define('PERMISSION_FOLDERS_FULL', 8);
define('PERMISSION_READ_OPTION', 16);
define('PERMISSION_READ_DOWNLOAD', 32);
define('PERMISSION_UPLOAD_READ_DOWNLOAD', 64);
define('PERMISSION_ADMIN', 128);
define('PERMISSION_POWER_USER', 256);

// Function to calculate access code based on selected permissions
function calculateAccessCode($permissions)
{
    // Map numeric values to corresponding permission names
    $mappedPermissions = [];
    foreach ($permissions as $permission) {
        switch ($permission) {
            case '1':
                $mappedPermissions[] = 'HOD';
                break;
            case '2':
                $mappedPermissions[] = 'Full-Department-control';
                break;
            case '4':
                $mappedPermissions[] = 'Create-Folders';
                break;
            case '8':
                $mappedPermissions[] = 'Folders-full-permission';
                break;
            case '16':
                $mappedPermissions[] = 'Read-Option';
                break;
            case '32':
                $mappedPermissions[] = 'Read/Download';
                break;
            case '64':
                $mappedPermissions[] = 'Upload/Read/Download';
                break;
            case '128':
                $mappedPermissions[] = 'Admin-permission';
                break;
            case '256':
                $mappedPermissions[] = 'Power-user';
                break;
            default:
                // Handle unrecognized permissions
                break;
        }
    }

    // Calculate access code based on mapped permissions array
    $accessCode = 0;
    foreach ($mappedPermissions as $permission) {
        switch ($permission) {
            case 'HOD':
                $accessCode |= PERMISSION_HOD;
                break;
            case 'Full-Department-control':
                $accessCode |= PERMISSION_FULL_DEPT_CONTROL;
                break;
            case 'Create-Folders':
                $accessCode |= PERMISSION_CREATE_FOLDERS;
                break;
            case 'Folders-full-permission':
                $accessCode |= PERMISSION_FOLDERS_FULL;
                break;
            case 'Read-Option':
                $accessCode |= PERMISSION_READ_OPTION;
                break;
            case 'Read/Download':
                $accessCode |= PERMISSION_READ_DOWNLOAD;
                break;
            case 'Upload/Read/Download':
                $accessCode |= PERMISSION_UPLOAD_READ_DOWNLOAD;
                break;
            case 'Admin-permission':
                $accessCode |= PERMISSION_ADMIN;
                break;
            case 'Power-user':
                $accessCode |= PERMISSION_POWER_USER;
                break;
            default:
                // Handle unrecognized permissions
                break;
        }
    }

    return $accessCode;
}

// Validate and sanitize input
$employeeId = filter_input(INPUT_POST, 'employeeId', FILTER_VALIDATE_INT);
$permissions = filter_input(INPUT_POST, 'permissions', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);

if ($employeeId === null || $employeeId === false || empty($permissions)) {
    // Handle validation errors, redirect or display an error message
    // Example: header('Location: error.php');
    exit(json_encode(['error' => 'Invalid input data']));
}

// Update employee permissions in the database
try {
    // Replace with your database connection details
    $conn = new PDO('mysql:host=localhost;dbname=user_management', 'root', '');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Calculate access code using the local function
    $accessCode = calculateAccessCode($permissions);

    // Prepare and execute SQL statement
    $sql = "UPDATE employees SET accesscode = :accesscode WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':accesscode', $accessCode, PDO::PARAM_INT);
    $stmt->bindParam(':id', $employeeId, PDO::PARAM_INT);
    $stmt->execute();

    // Check if update was successful
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => 'Permissions updated successfully']);
    } else {
        echo json_encode(['error' => 'Failed to update permissions']);
    }
} catch (PDOException $e) {
    // Handle database connection or query error
    exit(json_encode(['error' => 'Database error: ' . $e->getMessage()]));
}
