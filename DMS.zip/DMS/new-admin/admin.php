<?php
session_start();
include 'functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create_user'])) {
        createUser($_POST['username'], $_POST['password'], $_POST['role']);
    } elseif (isset($_POST['disable_user'])) {
        disableUser($_POST['user_id']);
    } elseif (isset($_POST['enable_user'])) {
        enableUser($_POST['user_id']);
    } elseif (isset($_POST['reset_password'])) {
        resetPassword($_POST['user_id'], $_POST['new_password']);
    } elseif (isset($_POST['change_role'])) {
        changeRole($_POST['user_id'], $_POST['new_role']);
    } elseif (isset($_POST['create_department'])) {
        createDepartment($_POST['department_name']);
    } elseif (isset($_POST['delete_department'])) {
        deleteDepartment($_POST['department_id']);
    }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['assign_user'])) {
        $permissions = isset($_POST['permission']) ? $_POST['permission'] : [];
        assignUserToDepartment($_POST['user_id'], $_POST['department_id'], $permissions);
    }
}

// Fetch all users for display
$users = $conn->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);
$departments = $conn->query("SELECT * FROM departments")->fetchAll(PDO::FETCH_ASSOC);
$stmt = $conn->query("SELECT logs.*, users.username AS user_username, admins.username AS admin_username 
                      FROM logs 
                      LEFT JOIN users ON logs.user_id = users.id 
                      LEFT JOIN users AS admins ON logs.admin_id = admins.id 
                      ORDER BY logs.id DESC");
$userDepartments = getUserDepartments();
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
$employees = getAllEmployees();


?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DMS 2.0 -Admin</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
</head>

<body>
    <div class="main-body">
        <div class="side-bar">
            <button class="collapse-btn" id="collapse-btn"><i class="bi bi-list"></i></button>
            <div class="side-bar-li active" id="home">
                <i class="bi bi-house-exclamation-fill"></i> <span>Create Users</span>
            </div>
            <div class="side-bar-li" id="customize">
                <i class="bi bi-gear-fill"></i> <span>Users Setting</span>
            </div>
            <div class="side-bar-li" id="employee">
                <i class="bi bi-clipboard-data"></i> <span>Audit Logs</span>
            </div>
            <div class="side-bar-li" id="asset">
                <i class="bi bi-building-fill-gear"></i> <span>Departments</span>
            </div>
            <div class="side-bar-li" id="profile">
                <i class="bi bi-buildings"></i> <span>User Department</span>
            </div>
            <div class="side-bar-li last-li" id="help">
                <i class="bi bi-question-circle-fill"></i> <span>Help</span>
            </div>
            <div class="side-bar-li toggle-switch">
                <input type="checkbox" id="dark-mode-toggle">
                <label for="dark-mode-toggle">Dark Mode</label>


            </div>
            <div class="side-bar-li toggle-switch">
                <a href="logout.php"><i class="bi bi-box-arrow-right" style="font-size: 2rem;"></i></a>


            </div>
        </div>
        <div class="main-content">
            <div class="content active" id="home-content">
                <h1 class="text-center">Create Employee</h1>
                <?php include 'employees.php'; ?>
                <div class="mb-4">
                    <h4>Admin</h4>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select class="form-control" id="role" name="role" required>

                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary" name="create_user">Create User</button>
                    </form>
                </div>
            </div>
            <div class="content" id="customize-content">
                <h1 class="text-center">Upcoming Features</h1>
            </div>

            <div class="content" id="employee-content">

                <h2>View Logs</h2>
                <p class="text-center text-muted">Upcoming Features</p>

            </div>
            <div class="content" id="asset-content">
                <div class="mb-4">
                    <h4>Create Department</h4>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="department_name" class="form-label">Department Name</label>
                            <input type="text" class="form-control" id="department_name" name="department_name" required>
                        </div>
                        <button type="submit" class="btn btn-primary" name="create_department">Create Department</button>
                    </form>
                </div>
                <div class="mb-4">
                    <h4>Departments</h4>
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Sr#</th>
                                <th>ID</th>
                                <th>Department Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($departments as $index => $department) : ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo $department['id']; ?></td>
                                    <td><?php echo htmlspecialchars($department['department_name']); ?></td>
                                    <td>
                                        <form method="POST" action="">
                                            <input type="hidden" name="department_id" value="<?php echo $department['id']; ?>">
                                            <button type="submit" class="btn btn-danger" name="delete_department">
                                                <i class="bi bi-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            </div>

            <div class="content" id="profile-content">


                <?php include 'permission.php' ?>
            </div>


            <div class="content" id="help-content">
                <?php
                include 'help.html'
                ?>
            </div>

        </div>
    </div>


    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-beta3/js/bootstrap.bundle.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.0/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery for AJAX -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#createEmployeeForm').submit(function(e) {
                e.preventDefault();

                $.ajax({
                    url: 'create_employee.php',
                    type: 'POST',
                    data: $(this).serialize(),
                    dataType: 'json',
                    success: function(response) {
                        var messageClass = response.status === 'success' ? 'alert-success' : 'alert-danger';
                        $('#response-message').html('<div class="alert ' + messageClass + '">' + response.message + '</div>');
                        if (response.status === 'success') {
                            $('#createEmployeeForm')[0].reset();
                        }
                    },
                    error: function() {
                        $('#response-message').html('<div class="alert alert-danger">An error occurred while creating the employee.</div>');
                    }
                });
            });
        });
    </script>

    <script src="../script.js"></script>


</body>

</html>