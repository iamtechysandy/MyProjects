<?php
require 'db.php';

if (isset($_GET['id'])) {
    $employeeId = $_GET['id'];

    $sql = "SELECT * FROM employees WHERE id = :employeeId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['employeeId' => $employeeId]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($employee) {
?>
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title"><?php echo htmlspecialchars($employee['fullname']); ?></h5>
                <p class="card-text">Email: <?php echo htmlspecialchars($employee['email']); ?></p>
                <form method="POST" action="admin.php">
                    <input type="hidden" name="employeeId" value="<?php echo $employee['id']; ?>">
                    <div class="mb-3">
                        <label for="max_upload_size_<?php echo $employee['id']; ?>" class="form-label">Max Upload Size (MB)</label>
                        <input type="range" class="form-range" id="max_upload_size_<?php echo $employee['id']; ?>" name="max_upload_size" min="1" max="100" value="<?php echo $employee['max_upload_size']; ?>" oninput="document.getElementById('upload_size_value_<?php echo $employee['id']; ?>').innerText = this.value">
                        <span class="slider-value" id="upload_size_value_<?php echo $employee['id']; ?>"><?php echo $employee['max_upload_size']; ?></span>
                    </div>
                    <div class="mb-3">
                        <label for="max_file_uploads_<?php echo $employee['id']; ?>" class="form-label">Max File Uploads</label>
                        <input type="range" class="form-range" id="max_file_uploads_<?php echo $employee['id']; ?>" name="max_file_uploads" min="1" max="100" value="<?php echo $employee['max_file_uploads']; ?>" oninput="document.getElementById('file_uploads_value_<?php echo $employee['id']; ?>').innerText = this.value">
                        <span class="slider-value" id="file_uploads_value_<?php echo $employee['id']; ?>"><?php echo $employee['max_file_uploads']; ?></span>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
<?php
    } else {
        echo "Employee not found.";
    }
}
?>