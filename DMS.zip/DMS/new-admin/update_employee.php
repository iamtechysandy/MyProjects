<?php
// update_employee.php
header('Content-Type: application/json');

include 'db.php';
$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'];
$fullname = $data['fullname'];
$username = $data['username'];
$email = $data['email'];
$department_id = $data['department_id'];
$status = $data['status'];
$role = $data['role'];

$stmt = $conn->prepare("UPDATE employees SET fullname = :fullname, username = :username, email = :email, department_id = :department_id, status = :status, role = :role WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->bindParam(':fullname', $fullname);
$stmt->bindParam(':username', $username);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':department_id', $department_id);
$stmt->bindParam(':status', $status);
$stmt->bindParam(':role', $role);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
