<?php
session_start();
require 'db.php';
include 'functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$employees = getAllEmployees($conn);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Manage Employee Upload Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
    <style>
        .slider-value {
            display: inline-block;
            width: 40px;
        }

        .employee-details {
            display: none;
        }

        .select2-container--bootstrap5 .select2-selection--single {
            height: 38px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.428571429;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        th {
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center text-muted">Manage Employee Upload Settings</h2>
        <?php if (isset($_GET['success'])) : ?>
            <div class="alert alert-success">Settings updated successfully!</div>
        <?php endif; ?>

        <label for="employeeSelect">Select Employee:</label>
        <select id="employeeSelect" class="form-select mb-4">
            <option value="">Select an employee</option>
            <?php foreach ($employees as $employee) : ?>
                <option value="<?php echo $employee['id']; ?>"><?php echo htmlspecialchars($employee['fullname']); ?></option>
            <?php endforeach; ?>
        </select>

        <div id="employeeContainer"></div>
    </div>
    <hr>
    <div class="container">
        <h3 class="text-center text-muted">All Employee Data</h3>
        <div class="table-responsive">
            <table class="table table-hover" id="employeeTable">
                <thead class="table-dark">
                    <tr>
                        <th>Sr#</th>
                        <th onclick="sortTable(1)">Employee Name</th>
                        <th onclick="sortTable(2)">Email</th>
                        <th onclick="sortTable(3)">Max Upload Size (MB)</th>
                        <th onclick="sortTable(4)">Max File Uploads</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $srNo = 1; ?>
                    <?php foreach ($employees as $employee) : ?>
                        <tr>
                            <td><?php echo $srNo++; ?></td>
                            <td><?php echo htmlspecialchars($employee['fullname']); ?></td>
                            <td><?php echo htmlspecialchars($employee['email']); ?></td>
                            <td><?php echo htmlspecialchars($employee['max_upload_size']); ?></td>
                            <td><?php echo htmlspecialchars($employee['max_file_uploads']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#employeeSelect').select2({
                theme: 'bootstrap-5',
                placeholder: "Select an employee",
                allowClear: true
            });

            $('#employeeSelect').on('change', function() {
                const employeeId = $(this).val();
                if (employeeId) {
                    $.ajax({
                        url: 'fetch_employee_details.php',
                        method: 'GET',
                        data: {
                            id: employeeId
                        },
                        success: function(response) {
                            $('#employeeContainer').html(response);
                        },
                        error: function() {
                            alert('Failed to fetch employee details.');
                        }
                    });
                } else {
                    $('#employeeContainer').html('');
                }
            });
        });

        function searchEmployee() {
            const searchValue = document.getElementById('employeeSearch').value.toLowerCase();
            const options = document.getElementById('employeeSelect').options;

            for (let i = 0; i < options.length; i++) {
                const optionText = options[i].text.toLowerCase();
                if (optionText.includes(searchValue)) {
                    options[i].style.display = '';
                } else {
                    options[i].style.display = 'none';
                }
            }
        }

        function sortTable(n) {
            const table = document.getElementById("employeeTable");
            let switching = true;
            let shouldSwitch, switchCount = 0;
            let dir = "asc";
            let rows, i, x, y;

            while (switching) {
                switching = false;
                rows = table.rows;
                for (i = 1; i < rows.length - 1; i++) {
                    shouldSwitch = false;
                    x = rows[i].getElementsByTagName("TD")[n];
                    y = rows[i + 1].getElementsByTagName("TD")[n];
                    if (dir === "asc" && x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                        shouldSwitch = true;
                        break;
                    } else if (dir === "desc" && x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                        shouldSwitch = true;
                        break;
                    }
                }
                if (shouldSwitch) {
                    rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                    switching = true;
                    switchCount++;
                } else if (switchCount === 0 && dir === "asc") {
                    dir = "desc";
                    switching = true;
                }
            }
        }
    </script>
</body>

</html>