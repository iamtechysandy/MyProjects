<?php
require 'db.php';

if (isset($_GET['id'])) {
    $employeeId = $_GET['id'];

    // Query to fetch permissions
    $sql = "SELECT accesscode FROM employees WHERE id = :employeeId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['employeeId' => $employeeId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        // Define permissions array
        $permissions = [
            'HOD' => 1,
            'Full-Department-control' => 2,
            'Create-Folders' => 4,
            'Folders-full-permission' => 8,
            'Read-Option' => 16,
            'Read/Download' => 32,
            'Upload/Read/Download' => 64,
            'Admin-permission' => 128,
            'Global-Search' => 256
        ];

        echo json_encode([
            'accesscode' => $result['accesscode'],
            'permissions' => $permissions
        ]);
    } else {
        echo json_encode(['error' => 'Employee not found']);
    }
} else {
    echo json_encode(['error' => 'Invalid request']);
}
