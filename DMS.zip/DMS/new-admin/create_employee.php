<?php
session_start();
require 'db.php';
require '../function_audit.php'; // Include the audit logging function

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Function to get the client's IP address
function getClientIP()
{
    return $_SERVER['REMOTE_ADDR'];
}

$response = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hashed password
    $department_id = $_POST['department_id'];

    try {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO employees (fullname, username, email, password, department_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->bindParam(1, $fullname);
        $stmt->bindParam(2, $username);
        $stmt->bindParam(3, $email);
        $stmt->bindParam(4, $password);
        $stmt->bindParam(5, $department_id);

        if ($stmt->execute()) {
            // Get the last inserted ID
            $newUserId = $conn->lastInsertId();

            // Fetch the username using the last inserted ID
            $stmt = $conn->prepare("SELECT username FROM employees WHERE id = ?");
            $stmt->bindParam(1, $newUserId);
            $stmt->execute();
            $newUsername = $stmt->fetchColumn();

            // Log the action with the IP address
            $ipAddress = getClientIP();
            logAudit($conn, $_SESSION['admin_id'], 'User Created', 'User with username ' . $newUsername . ' was created.', $ipAddress);

            $response['status'] = 'success';
            $response['message'] = 'Employee created successfully with username: ' . $newUsername;
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error: ' . $stmt->errorInfo()[2];
        }
    } catch (PDOException $e) {
        $response['status'] = 'error';
        $response['message'] = 'Error: ' . $e->getMessage();
    }
}

// Close connection
$conn = null;

// Return response as JSON
echo json_encode($response);
