<div class="container mt-5">
    <h2>Create Employee</h2>
    <div id="response-message" class="mb-3"></div>
    <form id="createEmployeeForm" method="POST">
        <div class="mb-3">
            <label for="fullname" class="form-label">Full Name</label>
            <input type="text" class="form-control" id="fullname" name="fullname" required>
        </div>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="mb-3">
            <label for="department_id" class="form-label">Department</label>
            <select class="form-select" id="department_id" name="department_id" required>
                <?php foreach ($departments as $department) : ?>
                    <option value="<?php echo $department['id']; ?>"><?php echo $department['department_name']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Create Employee</button>
    </form>
</div>

<h2 class="text-center">Employee Management</h2>
<div class="container">

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Username</th>
                <th>Email</th>
                <th>Department</th>
                <th>Status</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($employees as $employee) : ?>
                <tr data-id="<?php echo $employee['id']; ?>">
                    <td><?php echo $employee['id']; ?></td>
                    <td class="editable" data-field="fullname"><?php echo $employee['fullname']; ?></td>
                    <td class="editable" data-field="username"><?php echo $employee['username']; ?></td>
                    <td class="editable" data-field="email"><?php echo $employee['email']; ?></td>
                    <td class="editable" data-field="department_id">
                        <select class="form-select department-select" disabled>
                            <?php foreach ($departments as $department) : ?>
                                <option value="<?php echo $department['id']; ?>" <?php echo $employee['department_id'] == $department['id'] ? 'selected' : ''; ?>><?php echo $department['department_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td class="editable" data-field="status">
                        <select class="form-select status-select" disabled>
                            <option value="enabled" <?php echo $employee['status'] == 'enabled' ? 'selected' : ''; ?>>Enabled</option>
                            <option value="disabled" <?php echo $employee['status'] == 'disabled' ? 'selected' : ''; ?>>Disabled</option>
                        </select>
                    </td>
                    <td class="editable" data-field="role"><?php echo $employee['role']; ?></td>
                    <td>
                        <button class="btn btn-primary btn-edit">Edit</button>
                        <button class="btn btn-success btn-save" style="display:none;">Save</button>
                        <button class="btn btn-danger btn-reset-password" data-toggle="modal" data-target="#resetPasswordModal" data-id="<?php echo $employee['id']; ?>">Reset Password</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>



<!-- Reset Password Modal -->
<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1" role="dialog" aria-labelledby="resetPasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="resetPasswordModalLabel">Reset Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="selectedEmployeeId">
                <div class="form-group">
                    <label for="newPassword">New Password</label>
                    <input type="password" class="form-control" id="newPassword" placeholder="Enter new password">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="confirmResetPassword">Reset Password</button>
            </div>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.btn-edit').forEach(button => {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                row.querySelectorAll('.editable').forEach(cell => {
                    if (cell.querySelector('select')) {
                        cell.querySelector('select').disabled = false;
                    } else {
                        const input = document.createElement('input');
                        input.type = 'text';
                        input.classList.add('form-control'); // Add form-control class here
                        input.value = cell.innerText;
                        cell.innerHTML = '';
                        cell.appendChild(input);
                    }
                });
                this.style.display = 'none';
                row.querySelector('.btn-save').style.display = 'inline-block';
            });
        });

        document.querySelectorAll('.btn-save').forEach(button => {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const id = row.dataset.id;
                const data = {};
                row.querySelectorAll('.editable').forEach(cell => {
                    const field = cell.dataset.field;
                    if (cell.querySelector('select')) {
                        const value = cell.querySelector('select').value;
                        data[field] = value;
                    } else {
                        const value = cell.querySelector('input').value;
                        data[field] = value;
                    }
                });

                fetch('update_employee.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            id,
                            ...data
                        })
                    })
                    .then(response => response.json())
                    .then(result => {
                        if (result.success) {
                            row.querySelectorAll('.editable').forEach(cell => {
                                if (cell.querySelector('select')) {
                                    cell.querySelector('select').disabled = true;
                                } else {
                                    const value = cell.querySelector('input').value;
                                    cell.innerText = value; // Update cell content with new value
                                    cell.innerHTML = value; // Revert to non-editable state
                                }
                            });
                            this.style.display = 'none';
                            row.querySelector('.btn-edit').style.display = 'inline-block';
                        } else {
                            alert('Failed to update employee');
                        }
                    });
            });
        });

        // Reset Password button click handler
        document.querySelectorAll('.btn-reset-password').forEach(button => {
            button.addEventListener('click', function() {
                const employeeId = this.dataset.id;
                document.getElementById('selectedEmployeeId').value = employeeId;
            });
        });

        // Confirm Reset Password button click handler
        document.getElementById('confirmResetPassword').addEventListener('click', function() {
            const newPassword = document.getElementById('newPassword').value;
            const selectedEmployeeId = document.getElementById('selectedEmployeeId').value;

            fetch('reset_password.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: selectedEmployeeId,
                        newPassword: newPassword
                    })
                })
                .then(response => response.text()) // Read the response as text for debugging
                .then(result => {
                    try {
                        const jsonResult = JSON.parse(result);
                        if (jsonResult.success) {
                            alert('Password reset successfully');
                        } else {
                            console.error('Error:', jsonResult.message);
                            alert('Failed to reset password: ' + jsonResult.message);
                        }
                    } catch (e) {
                        console.error('JSON parse error:', e);
                        console.error('Response:', result); // Log the full response for debugging
                        alert('An error occurred while processing the request.');
                    }
                    $('#resetPasswordModal').modal('hide');
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                });
        });
    });
</script>