<?php
include 'dbConnection.php';

function addEmployee($fullname, $username, $email, $password, $departmentId = null)
{
    $pdo = getConnection();
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO employees (fullname, username, email, password, department_id, status, role) VALUES (?, ?, ?, ?, ?, 'active', 'user')");
    return $stmt->execute([$fullname, $username, $email, $hashedPassword, $departmentId]);
}

function getEmployees()
{
    $pdo = getConnection();
    $stmt = $pdo->query("SELECT * FROM employees");
    return $stmt->fetchAll();
}
