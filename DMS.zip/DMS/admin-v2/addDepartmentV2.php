<?php
include 'departmentFunctions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $departmentName = $_POST['departmentName'];
    if (addDepartment($departmentName)) {
        http_response_code(200);
        echo json_encode("Department added successfully!");
    } else {
        http_response_code(500);
        echo json_encode(array("message" => "Error adding department."));
    }
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(array("message" => "Method not allowed."));
}
