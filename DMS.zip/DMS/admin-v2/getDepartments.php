<?php
include 'departmentFunctions.php';

$departments = getDepartments();
$options = '<option value="">None</option>';
foreach ($departments as $department) {
    $options .= '<option value="' . $department['id'] . '">' . $department['department_name'] . '</option>';
}
echo $options;
