<?php
include 'dbConnection.php';

function addDepartment($departmentName)
{
    $pdo = getConnection();
    $stmt = $pdo->prepare("INSERT INTO departments (department_name) VALUES (?)");
    return $stmt->execute([$departmentName]);
}

function getDepartments()
{
    $pdo = getConnection();
    $stmt = $pdo->query("SELECT * FROM departments");
    return $stmt->fetchAll();
}
