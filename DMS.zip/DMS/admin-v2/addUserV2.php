<?php
include 'employeeFunctions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $departmentId = $_POST['departmentId'];
    if (addEmployee($fullname, $username, $email, $password, $departmentId)) {
        echo "User added successfully!";
    } else {
        echo "Error adding user.";
    }
}
