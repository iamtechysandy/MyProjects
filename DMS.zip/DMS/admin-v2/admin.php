<?php
session_start();
include 'dbConnection.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin-Version 2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.8.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        .v2-highlight {
            background-color: #f0f0f0;
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>
    <div class="container v2-highlight">
        <h1 class="my-4">Admin-Version 2</h1>
        <div class="row">
            <div class="col-md-6">
                <h3>Add User to Department</h3>
                <form id="addUserForm">
                    <div class="mb-3">
                        <label for="fullname" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="fullname" required>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="departmentSelect" class="form-label">Select Department</label>
                        <select class="form-select" id="departmentSelect">
                            <option value="">None</option>
                            <!-- Options will be populated dynamically -->
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Add User</button>
                </form>
            </div>
        </div>
        <div id="successMessage" class="alert alert-success mt-4" role="alert" style="display:none;"></div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <h3>Add Department</h3>
            <form id="addDepartmentForm">
                <div class="mb-3">
                    <label for="departmentName" class="form-label">Department Name</label>
                    <input type="text" class="form-control" id="departmentName" required>
                </div>
                <button type="submit" class="btn btn-primary">Add Department</button>
            </form>
        </div>
        <div class="col-md-6">
            <h3>Existing Departments</h3>
            <ul id="departmentList" class="list-group">
                <!-- Departments will be populated dynamically -->
            </ul>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-latest.min.js"></script>

    <script>
        $(document).ready(function() {
            function fetchDepartments() {
                $.get('getDepartments.php', function(data) {
                    $('#departmentSelect').html(data);
                });
            }

            $('#addUserForm').submit(function(e) {
                e.preventDefault();
                $.post('addUserV2.php', {
                    fullname: $('#fullname').val(),
                    username: $('#username').val(),
                    email: $('#email').val(),
                    password: $('#password').val(),
                    departmentId: $('#departmentSelect').val()
                }, function(response) {
                    $('#successMessage').show().text(response);
                });
            });

            fetchDepartments();
        });
        // Submit handler for adding departments
        $('#addDepartmentForm').submit(function(e) {
            e.preventDefault();
            $.post('addDepartmentV2.php', {
                departmentName: $('#departmentName').val()
            }, function(response) {
                $('#departmentName').val(''); // Clear input field
                fetchDepartments(); // Refresh department list
                $('#successMessage').html('<div class="alert alert-success" role="alert">' + response + '</div>').show();
            }).fail(function(xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Error adding department.";
                $('#successMessage').html('<div class="alert alert-danger" role="alert">' + errorMessage + '</div>').show();
            });
        });
    </script>
</body>

</html>