-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2024 at 01:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `description`, `ip_address`, `timestamp`) VALUES
(2, 1, 'User Created', 'User with ID 11 was created.', '::1', '2024-06-26 12:51:16'),
(3, 1, 'User Created', 'User with ID 12 was created.', '192.168.41.44', '2024-06-26 12:52:54'),
(4, 1, 'User Created', 'User with username d was created.', '::1', '2024-06-26 12:56:40');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `department_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `department_name`) VALUES
(8, 'BOOKS'),
(9, 'Accounts'),
(10, 'Human Resource'),
(11, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `role` varchar(20) NOT NULL,
  `accesscode` varchar(100) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('enabled','disabled') DEFAULT 'disabled',
  `deleted` tinyint(1) DEFAULT 1,
  `max_upload_size` int(11) DEFAULT 104857600,
  `max_file_uploads` int(11) DEFAULT 100
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `fullname`, `username`, `email`, `password`, `department_id`, `role`, `accesscode`, `timestamp`, `status`, `deleted`, `max_upload_size`, `max_file_uploads`) VALUES
(1, 'sandeep kushwahas', '4601', 'skushwaha017.sk@gmail.com', '$2y$10$rgsVq0StFyyM0jR2r3IV/.OIuWwRY3WIE5VKl1YpDqRoh.utl1efi', 9, 'user', '265', '2024-06-15 21:46:02', 'enabled', 1, 100, 23),
(2, 'sandeep kushwaha', 'sandeep', 'aisocialpedia@hotmail.com', '$2y$10$Nz7ZNBy4Hc8nKv87lMHeh.kERu1PIToTqE3YDf630x1.XKDlQ3P8.', 9, '', '3', '2024-06-15 22:10:13', 'enabled', 1, 104857600, 100),
(3, 'Sulfi', 'sulfi', 's@gmail.com', '$2y$10$rJ25Qfp9AurPHw1mXQD65OxfCvevQvm1Q4B/VHQucmGxuCayuz/.q', 9, '', '8', '2024-06-15 22:15:29', 'enabled', 1, 104857600, 100),
(4, 'It Admin', 'itadmin', 'it.team@shar.com.sa', '$2y$10$kxEOEDPcDuFcXu/OjJOoc.dHHjRx8zP2vp7GD5yB5hwyMfQ.JN71.', 8, '', '128', '2024-06-20 07:43:57', 'enabled', 1, 104857600, 100),
(10, 'Deepak', 'deep', 'deep@g.com', '$2y$10$eEqaLBG/SjsYE5/R5DSH2O4AZAA1E5WcYjNZqEdu2mIO5o7TETzNi', 9, '', NULL, '2024-06-26 12:50:26', 'disabled', 1, 104857600, 100),
(11, 'Deepak', 'deesp', 'deesp@g.com', '$2y$10$.LbXHH/QKAk95gagoOIjXOuUAHll3AVf7si/pGty5usYJXp5aZ6hO', 9, '', NULL, '2024-06-26 12:51:16', 'disabled', 1, 104857600, 100),
(12, 'Deepa', 'deppa', '123@f.com', '$2y$10$AKy4RM1kwtj.1SBc3V6r6OGNMo5Jv67E6sreFfdCmrSqOMrrdeNje', 9, '', NULL, '2024-06-26 12:52:54', 'disabled', 1, 104857600, 100),
(13, 'd', 'd', 'd@gmail.com', '$2y$10$jPIKReGgVU7XXukrMqnhIe6rB9lDTu33N7ZgG.OHSdP2hF4P/stau', 9, '', NULL, '2024-06-26 12:56:40', 'disabled', 1, 104857600, 100);

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `folder_id` int(11) NOT NULL,
  `original_file_name` varchar(255) NOT NULL,
  `file_extension` varchar(50) NOT NULL,
  `uploaded_file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `uploaded_date` timestamp NULL DEFAULT current_timestamp(),
  `validation` varchar(20) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `doc_number` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `folder_id`, `original_file_name`, `file_extension`, `uploaded_file_name`, `file_path`, `uploaded_by`, `uploaded_date`, `validation`, `expiry_date`, `doc_number`, `description`) VALUES
(280, 20, '3.pdf', 'pdf', '25f064b057fd88549bd6b962917658a1aa6f0f29f0d6020b4725a124f8acd6bc', 'uploads/25f064b057fd88549bd6b962917658a1aa6f0f29f0d6020b4725a124f8acd6bc', 2, '2024-06-13 08:15:26', NULL, NULL, NULL, NULL),
(279, 20, '2.pdf', 'pdf', '0f0bd6d86c5c7ed9516b50ec5df7e5e570c673232d5c5569e00e77a38c998688', 'uploads/0f0bd6d86c5c7ed9516b50ec5df7e5e570c673232d5c5569e00e77a38c998688', 2, '2024-06-13 08:15:26', NULL, NULL, NULL, NULL),
(278, 20, '1.pdf', 'pdf', '1631c79aa22e2f4bc13f948755920009b10195c69c744199d0fb9e13d93197be', 'uploads/1631c79aa22e2f4bc13f948755920009b10195c69c744199d0fb9e13d93197be', 2, '2024-06-13 08:15:26', NULL, NULL, NULL, NULL),
(277, 20, '100647 1D.pdf', 'pdf', '2c03de42a4f01eec69bc56edd6ce9840ed07bb0811690ed73c1fe6ad2c03e5e2', 'uploads/2c03de42a4f01eec69bc56edd6ce9840ed07bb0811690ed73c1fe6ad2c03e5e2', 2, '2024-06-13 08:14:31', NULL, NULL, NULL, NULL),
(276, 20, '100646 1L.pdf', 'pdf', '07d080845a1cad7771321548973c68bd8ca5ff1f83d2ab932903f229f0f86672', 'uploads/07d080845a1cad7771321548973c68bd8ca5ff1f83d2ab932903f229f0f86672', 2, '2024-06-13 08:14:31', NULL, NULL, NULL, NULL),
(275, 20, '100645 1D.pdf', 'pdf', '0e379efe11309275edb8430bda7392c774dc716ec7743b76a0335c2bb49edae9', 'uploads/0e379efe11309275edb8430bda7392c774dc716ec7743b76a0335c2bb49edae9', 2, '2024-06-13 08:14:31', NULL, NULL, NULL, NULL),
(274, 20, '98406 1L.pdf', 'pdf', '6ed53c04626f5874d03e2e3c9d78b30aea5664713b736e3ebf6fe68deb7de2f6', 'uploads/6ed53c04626f5874d03e2e3c9d78b30aea5664713b736e3ebf6fe68deb7de2f6', 2, '2024-06-13 08:14:31', NULL, NULL, NULL, NULL),
(272, 17, 'Men Are From Mars Women Are From Venus_60.pdf', 'pdf', '5181d312065f852ef034a8da52b408e50d08eb33e4ce53b70e751d23b6c317dd', 'uploads/5181d312065f852ef034a8da52b408e50d08eb33e4ce53b70e751d23b6c317dd', 2, '2024-06-12 09:59:53', NULL, NULL, NULL, NULL),
(271, 17, 'Men Are From Mars Women Are From Venus_59.pdf', 'pdf', '2d8fbf2778d8e7f1cb1c0b8666378e4b626195f5c740ecabf09d9e5347ba20be', 'uploads/2d8fbf2778d8e7f1cb1c0b8666378e4b626195f5c740ecabf09d9e5347ba20be', 2, '2024-06-12 09:59:53', NULL, NULL, NULL, NULL),
(270, 17, 'Men Are From Mars Women Are From Venus_58.pdf', 'pdf', '7d2c43d889fc48526f682c455f42a764d129184fd516d52be7236893d84275a3', 'uploads/7d2c43d889fc48526f682c455f42a764d129184fd516d52be7236893d84275a3', 2, '2024-06-12 09:59:53', NULL, NULL, NULL, NULL),
(269, 17, 'Men Are From Mars Women Are From Venus_57.pdf', 'pdf', '9cd8be3c05b43bd4d54755d4db752b45290595cc635799d87fc9237a974ac6c3', 'uploads/9cd8be3c05b43bd4d54755d4db752b45290595cc635799d87fc9237a974ac6c3', 2, '2024-06-12 09:59:53', NULL, NULL, NULL, NULL),
(268, 17, 'Men Are From Mars Women Are From Venus_56.pdf', 'pdf', 'c10209dbdee297b50a1b413b24d232b6b167c9b9813c3a01201d179df08f3de0', 'uploads/c10209dbdee297b50a1b413b24d232b6b167c9b9813c3a01201d179df08f3de0', 2, '2024-06-12 09:59:53', NULL, NULL, NULL, NULL),
(267, 17, 'Men Are From Mars Women Are From Venus_55.pdf', 'pdf', 'b13db2f48442b60541559032413c43de70e8800855acdafa6ab760c7f9ec1e97', 'uploads/b13db2f48442b60541559032413c43de70e8800855acdafa6ab760c7f9ec1e97', 2, '2024-06-12 09:59:53', NULL, NULL, NULL, NULL),
(266, 17, 'Men Are From Mars Women Are From Venus_54.pdf', 'pdf', 'c89106c2daa49c72056a021fb3ff14e2b817738da2a802e443474e68833fa2a9', 'uploads/c89106c2daa49c72056a021fb3ff14e2b817738da2a802e443474e68833fa2a9', 2, '2024-06-12 09:59:53', NULL, NULL, NULL, NULL),
(265, 17, 'Men Are From Mars Women Are From Venus_53.pdf', 'pdf', '9e86d070ca4e2843497d62d778aa09ecc16b0bd4f8e5b092d5fdd5adc1bad139', 'uploads/9e86d070ca4e2843497d62d778aa09ecc16b0bd4f8e5b092d5fdd5adc1bad139', 2, '2024-06-12 09:59:53', NULL, NULL, NULL, NULL),
(264, 17, 'Men Are From Mars Women Are From Venus_52.pdf', 'pdf', 'bb815c0d54b86a5ae1ef5f771243a110e157bd7967d60389655c344323d15934', 'uploads/bb815c0d54b86a5ae1ef5f771243a110e157bd7967d60389655c344323d15934', 2, '2024-06-12 09:59:53', 'valid', '2024-06-12', NULL, NULL),
(262, 16, 'Men Are From Mars Women Are From Venus_50.pdf', 'pdf', '45f8d42818fc74dc7786eaccee9f5e844873006c54b6b207aab1ff35d01574bc', 'uploads/45f8d42818fc74dc7786eaccee9f5e844873006c54b6b207aab1ff35d01574bc', 2, '2020-06-12 09:09:17', NULL, NULL, NULL, NULL),
(261, 16, 'Men Are From Mars Women Are From Venus_49.pdf', 'pdf', 'e92cabf3dd3da6841b66b9d8f979759de117f13326f855b52b25611cb80745ad', 'uploads/e92cabf3dd3da6841b66b9d8f979759de117f13326f855b52b25611cb80745ad', 2, '2024-06-12 09:09:17', NULL, NULL, NULL, NULL),
(260, 16, 'Men Are From Mars Women Are From Venus_48.pdf', 'pdf', '96e5b82eab2e557d3eebe2de572160f38db65e76ac6307577dacacbbdfe1883a', 'uploads/96e5b82eab2e557d3eebe2de572160f38db65e76ac6307577dacacbbdfe1883a', 2, '2024-06-12 09:09:17', NULL, NULL, NULL, NULL),
(259, 16, 'Men Are From Mars Women Are From Venus_47.pdf', 'pdf', '1e267eac5628d73d411ee3ca22cfc4bbd76a700ce337d07edcbf23c7852d5ae8', 'uploads/1e267eac5628d73d411ee3ca22cfc4bbd76a700ce337d07edcbf23c7852d5ae8', 2, '2024-06-12 09:09:17', NULL, NULL, NULL, NULL),
(258, 16, 'Men Are From Mars Women Are From Venus_46.pdf', 'pdf', 'a36370a6e0d1f4b3bf8c9587c60391c376416ea2aa91a02f78cb77724ff77fb7', 'uploads/a36370a6e0d1f4b3bf8c9587c60391c376416ea2aa91a02f78cb77724ff77fb7', 2, '2024-06-12 09:09:17', NULL, NULL, NULL, NULL),
(257, 16, 'Men Are From Mars Women Are From Venus_45.pdf', 'pdf', 'cecc7832189808e8df8b97f1166c11ad95a028127fa7227602ea92988a4d0d1b', 'uploads/cecc7832189808e8df8b97f1166c11ad95a028127fa7227602ea92988a4d0d1b', 2, '2024-06-12 09:09:17', NULL, NULL, NULL, NULL),
(256, 16, 'Men Are From Mars Women Are From Venus_44.pdf', 'pdf', '52151b8fc24fcd272b30279c93a973a06be01c4c71732021bf07bde419cc8f97', 'uploads/52151b8fc24fcd272b30279c93a973a06be01c4c71732021bf07bde419cc8f97', 2, '2024-06-12 09:09:17', NULL, NULL, NULL, NULL),
(255, 16, 'Men Are From Mars Women Are From Venus_43.pdf', 'pdf', '48b3f3338cda2e2f1ca50d3184f69bd998cb09c0e02e1c6aa837617cce0c83ff', 'uploads/48b3f3338cda2e2f1ca50d3184f69bd998cb09c0e02e1c6aa837617cce0c83ff', 2, '2024-06-12 09:09:17', NULL, NULL, NULL, NULL),
(254, 16, 'Men Are From Mars Women Are From Venus_42.pdf', 'pdf', 'f2546f19d518ef7514e5a9969febb2ebbe916fc3dc072c07c31c47fbac333e57', 'uploads/f2546f19d518ef7514e5a9969febb2ebbe916fc3dc072c07c31c47fbac333e57', 2, '2024-06-12 09:09:17', NULL, NULL, NULL, NULL),
(273, 16, 'Men Are From Mars Women Are From Venus_40.pdf', 'pdf', 'a52a22d7b9d10dc508144c45aaf8042e6ef68cbe16bd1049901a3c96e8044bb0', 'uploads/a52a22d7b9d10dc508144c45aaf8042e6ef68cbe16bd1049901a3c96e8044bb0', 2, '2024-06-12 08:57:22', NULL, NULL, NULL, NULL),
(253, 16, 'Men Are From Mars Women Are From Venus_41.pdf', 'pdf', '17cf87eef5bfc838e46085d692e3c4125729b5cf4b61ae101ee181ad282f17a9', 'uploads/17cf87eef5bfc838e46085d692e3c4125729b5cf4b61ae101ee181ad282f17a9', 2, '2024-06-12 09:09:17', NULL, NULL, NULL, NULL),
(251, 16, 'Men Are From Mars Women Are From Venus_39.pdf', 'pdf', '0a4ab8baafc9a7bb0521028324fc60fc164b502b972e835ccffa513299e5e210', 'uploads/0a4ab8baafc9a7bb0521028324fc60fc164b502b972e835ccffa513299e5e210', 2, '2024-06-12 08:57:22', NULL, NULL, NULL, NULL),
(250, 16, 'Men Are From Mars Women Are From Venus_38.pdf', 'pdf', '6d3c3370654eafaaee19fd8d9cc1a45ae6fe905e774f354a8844fcefb58de85c', 'uploads/6d3c3370654eafaaee19fd8d9cc1a45ae6fe905e774f354a8844fcefb58de85c', 2, '2024-06-12 08:57:22', 'valid', '2024-06-27', NULL, NULL),
(249, 16, 'Men Are From Mars Women Are From Venus_37.pdf', 'pdf', 'e5bf80a494668a41c0dc0f596d744fa7727b5f5ef870587f585aee3bf0a746a5', 'uploads/e5bf80a494668a41c0dc0f596d744fa7727b5f5ef870587f585aee3bf0a746a5', 2, '2024-06-12 08:57:22', NULL, NULL, NULL, NULL),
(248, 16, 'Men Are From Mars Women Are From Venus_36.pdf', 'pdf', '7a7fc9100443c0df704cc15c1c2f54ecd5b797c31753a31bcfd1137f1e1ea67f', 'uploads/7a7fc9100443c0df704cc15c1c2f54ecd5b797c31753a31bcfd1137f1e1ea67f', 2, '2024-06-12 08:57:22', NULL, NULL, NULL, NULL),
(246, 16, 'Men Are From Mars Women Are From Venus_34.pdf', 'pdf', 'ab1cbf7a9ab81467845970bfda00494b219367b754ddca415e9e73f7cac72297', 'uploads/ab1cbf7a9ab81467845970bfda00494b219367b754ddca415e9e73f7cac72297', 2, '2024-06-12 08:57:22', NULL, NULL, NULL, NULL),
(247, 16, 'Men Are From Mars Women Are From Venus_35.pdf', 'pdf', 'c933af3ad28307fff07f84aff4e0e5a554cd4a49a58c8d07d070807c263559cd', 'uploads/c933af3ad28307fff07f84aff4e0e5a554cd4a49a58c8d07d070807c263559cd', 2, '2024-06-12 08:57:22', NULL, NULL, NULL, NULL),
(245, 16, 'Men Are From Mars Women Are From Venus_33.pdf', 'pdf', 'fa3032d822c5b6b2c4a7381e9df4f340d449262c2a2b3c07097bd379e0083d1c', 'uploads/fa3032d822c5b6b2c4a7381e9df4f340d449262c2a2b3c07097bd379e0083d1c', 2, '2024-06-12 08:57:22', NULL, NULL, NULL, NULL),
(244, 16, 'Men Are From Mars Women Are From Venus_32.pdf', 'pdf', '1d5420513c065d3f38a54586d98cc39c89cc36a08ad94f5a09dfd4c67940511e', 'uploads/1d5420513c065d3f38a54586d98cc39c89cc36a08ad94f5a09dfd4c67940511e', 2, '2024-06-12 08:57:22', NULL, NULL, NULL, NULL),
(243, 16, 'Men Are From Mars Women Are From Venus_31.pdf', 'pdf', 'df232a16da25737e7d1c48b51e092463b0012489f9eed8d91f2f697c56fea154', 'uploads/df232a16da25737e7d1c48b51e092463b0012489f9eed8d91f2f697c56fea154', 2, '2024-06-12 08:57:22', NULL, NULL, NULL, NULL),
(241, 16, 'Men Are From Mars Women Are From Venus_29.pdf', 'pdf', '7bac66e9e253ef39a533f81be782c5bfee6114b3fc2319405b0e05b8e9ebae70', 'uploads/7bac66e9e253ef39a533f81be782c5bfee6114b3fc2319405b0e05b8e9ebae70', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(242, 16, 'Men Are From Mars Women Are From Venus_30.pdf', 'pdf', '0618671e5fe7aaf72a85713b23de6d66ddbbadf1fa0965c82858e39b2915d28e', 'uploads/0618671e5fe7aaf72a85713b23de6d66ddbbadf1fa0965c82858e39b2915d28e', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(240, 16, 'Men Are From Mars Women Are From Venus_28.pdf', 'pdf', '388017b09a6642b165c7923e504d70f873fd55ed7ac66fbaadce02db346d3c04', 'uploads/388017b09a6642b165c7923e504d70f873fd55ed7ac66fbaadce02db346d3c04', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(238, 16, 'Men Are From Mars Women Are From Venus_26.pdf', 'pdf', '26f5240102ecc37a5f09e8695d2996e7febaeeaba8f162ab71f81d2ac38a82bc', 'uploads/26f5240102ecc37a5f09e8695d2996e7febaeeaba8f162ab71f81d2ac38a82bc', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(239, 16, 'Men Are From Mars Women Are From Venus_27.pdf', 'pdf', '540dbb9d0a0e2759a753c7e8a9a7f8be3ae320f57e1675ec567e62449849f83f', 'uploads/540dbb9d0a0e2759a753c7e8a9a7f8be3ae320f57e1675ec567e62449849f83f', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(236, 16, 'Men Are From Mars Women Are From Venus_24.pdf', 'pdf', '2ba1e8e82720a2bf3a564c89a2cc69449415c3310004c2265405337839249501', 'uploads/2ba1e8e82720a2bf3a564c89a2cc69449415c3310004c2265405337839249501', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(237, 16, 'Men Are From Mars Women Are From Venus_25.pdf', 'pdf', 'd14a7641dfd7b085cf4ecb8665357d4bc23346edaae8b6d361cc622e2a0dc2a9', 'uploads/d14a7641dfd7b085cf4ecb8665357d4bc23346edaae8b6d361cc622e2a0dc2a9', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(235, 16, 'Men Are From Mars Women Are From Venus_23.pdf', 'pdf', 'c291c10ecb6b61b7eb061355b7214f8c523576cc54642c74677a339f59e03928', 'uploads/c291c10ecb6b61b7eb061355b7214f8c523576cc54642c74677a339f59e03928', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(234, 16, 'Men Are From Mars Women Are From Venus_22.pdf', 'pdf', 'd43f71d983f7bbdde72bc4ded24adbe55063cf9ce99765faec03e503f9a2f301', 'uploads/d43f71d983f7bbdde72bc4ded24adbe55063cf9ce99765faec03e503f9a2f301', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(233, 16, 'Men Are From Mars Women Are From Venus_21.pdf', 'pdf', '3ce4dd5d15040337921d3cc9dc76c532212d22b5453ef81bc38497b37ab6ebeb', 'uploads/3ce4dd5d15040337921d3cc9dc76c532212d22b5453ef81bc38497b37ab6ebeb', 2, '2024-06-12 08:56:54', NULL, NULL, NULL, NULL),
(232, 16, 'Men Are From Mars Women Are From Venus_20.pdf', 'pdf', 'c88c20ac1fdd88d6718e4c1057ffff80b716a74776bb9a70b305793d4dff5de6', 'uploads/c88c20ac1fdd88d6718e4c1057ffff80b716a74776bb9a70b305793d4dff5de6', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(230, 16, 'Men Are From Mars Women Are From Venus_18.pdf', 'pdf', 'c36d54eda39ea1e22f1e9fe331b10af2ff7924f8ff5e870da0556e19ca4cb987', 'uploads/c36d54eda39ea1e22f1e9fe331b10af2ff7924f8ff5e870da0556e19ca4cb987', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(231, 16, 'Men Are From Mars Women Are From Venus_19.pdf', 'pdf', 'fb7678ee2bf15b8b40f2f0459631162b579b3c9b8973f863c2244a8f1e929c32', 'uploads/fb7678ee2bf15b8b40f2f0459631162b579b3c9b8973f863c2244a8f1e929c32', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(229, 16, 'Men Are From Mars Women Are From Venus_17.pdf', 'pdf', '01597d8f23a7617e0bf7b69509c14361370c171b3c2473120e5a3a75f68e5bd1', 'uploads/01597d8f23a7617e0bf7b69509c14361370c171b3c2473120e5a3a75f68e5bd1', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(228, 16, 'Men Are From Mars Women Are From Venus_16.pdf', 'pdf', '032a6dc1fab7723bae7e93d4e7508454315d766bb4bd15b6d8204e00a42af477', 'uploads/032a6dc1fab7723bae7e93d4e7508454315d766bb4bd15b6d8204e00a42af477', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(227, 16, 'Men Are From Mars Women Are From Venus_15.pdf', 'pdf', '0d6f067574a5d837f4003532678c78b5ac9ccba4de15b2a67c60e8c2a466c16d', 'uploads/0d6f067574a5d837f4003532678c78b5ac9ccba4de15b2a67c60e8c2a466c16d', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(226, 16, 'Men Are From Mars Women Are From Venus_14.pdf', 'pdf', '6a328020c7087d8fd50dd3281bfde248c9ba9d57cd56dd895e6192c8bc1e46ed', 'uploads/6a328020c7087d8fd50dd3281bfde248c9ba9d57cd56dd895e6192c8bc1e46ed', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(225, 16, 'Men Are From Mars Women Are From Venus_13.pdf', 'pdf', '4d737d970516ec2321c6cfc70dfbb6e7673370004885c1ce565b52acfc6959ad', 'uploads/4d737d970516ec2321c6cfc70dfbb6e7673370004885c1ce565b52acfc6959ad', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(222, 16, 'Men Are From Mars Women Are From Venus_10.pdf', 'pdf', 'cbabd17006f1cfaa4b0ac09046d82c02403c6e2c8fc80cbbed04e5532c8a5d09', 'uploads/cbabd17006f1cfaa4b0ac09046d82c02403c6e2c8fc80cbbed04e5532c8a5d09', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(223, 16, 'Men Are From Mars Women Are From Venus_11.pdf', 'pdf', 'fc70d15a886e869fb012a957449d63a91658870fe9f902d292eedff42d790f5e', 'uploads/fc70d15a886e869fb012a957449d63a91658870fe9f902d292eedff42d790f5e', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(224, 16, 'Men Are From Mars Women Are From Venus_12.pdf', 'pdf', 'c0494961816fd23aff0429bf626cf33ed7c4a97fed959ed091132d42b7ec3438', 'uploads/c0494961816fd23aff0429bf626cf33ed7c4a97fed959ed091132d42b7ec3438', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(220, 16, 'Men Are From Mars Women Are From Venus_8.pdf', 'pdf', '0f5a2f71acb899eac4148d7953fd77de9349e9ae3645f778a4d1ea84806aa97f', 'uploads/0f5a2f71acb899eac4148d7953fd77de9349e9ae3645f778a4d1ea84806aa97f', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(221, 16, 'Men Are From Mars Women Are From Venus_9.pdf', 'pdf', 'd3f66fecf55a305aebabb7cb067b681081a0ad23b8e3ace2d73ca28ce76f1642', 'uploads/d3f66fecf55a305aebabb7cb067b681081a0ad23b8e3ace2d73ca28ce76f1642', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(219, 16, 'Men Are From Mars Women Are From Venus_7.pdf', 'pdf', '9e8b27ce673a3524062041f2526cfa753bfd27b70eb7876d9201794e51fe9a41', 'uploads/9e8b27ce673a3524062041f2526cfa753bfd27b70eb7876d9201794e51fe9a41', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(218, 16, 'Men Are From Mars Women Are From Venus_6.pdf', 'pdf', 'fd02bb7793855a2ddef377f5b3aa8707b155bcab38ebee6b2dce5d3bb71be3e7', 'uploads/fd02bb7793855a2ddef377f5b3aa8707b155bcab38ebee6b2dce5d3bb71be3e7', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(216, 16, 'Men Are From Mars Women Are From Venus_4.pdf', 'pdf', 'f5915ff212b9342294a519dc1550bbb20665f14fc829a0d18eeb636f57559c7d', 'uploads/f5915ff212b9342294a519dc1550bbb20665f14fc829a0d18eeb636f57559c7d', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(217, 16, 'Men Are From Mars Women Are From Venus_5.pdf', 'pdf', '5a7f811d53c23e843ebc669d3b3f0f02c00d0adec794095757190751480ff20b', 'uploads/5a7f811d53c23e843ebc669d3b3f0f02c00d0adec794095757190751480ff20b', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(213, 16, 'Men Are From Mars Women Are From Venus_1.pdf', 'pdf', '7775fbd4371ca1cfae45b2d2a8f7aff1d6184569a48751df7b4223bb8d32642d', 'uploads/7775fbd4371ca1cfae45b2d2a8f7aff1d6184569a48751df7b4223bb8d32642d', 2, '2024-06-12 08:56:06', NULL, NULL, NULL, NULL),
(215, 16, 'Men Are From Mars Women Are From Venus_3.pdf', 'pdf', 'd7e5c22e9bc13f9701b9c4b7cde3562ca02030ff3d49c8f9c94262ce09f412ed', 'uploads/d7e5c22e9bc13f9701b9c4b7cde3562ca02030ff3d49c8f9c94262ce09f412ed', 2, '2024-06-12 08:56:07', NULL, NULL, NULL, NULL),
(214, 16, 'Men Are From Mars Women Are From Venus_2.pdf', 'pdf', 'f481175ddd7389237127f941aec650996ae3f764ca1efe0a38e0b2e7b02a6516', 'uploads/f481175ddd7389237127f941aec650996ae3f764ca1efe0a38e0b2e7b02a6516', 2, '2024-06-12 08:56:06', NULL, NULL, NULL, NULL),
(281, 18, '10 cert.jpg', 'jpg', '1ac3e1d6a073566b4b28d3bbb6c40193ecb1735b7da47fcabd0d1573c33571e8', 'uploads/1ac3e1d6a073566b4b28d3bbb6c40193ecb1735b7da47fcabd0d1573c33571e8', 2, '2024-06-13 09:52:27', NULL, NULL, NULL, NULL),
(282, 18, '10 cert.jpg', 'jpg', 'bd0643a362992ca11a35b2227f7922d8143e7af5888cf595a5b636b441768385', 'uploads/bd0643a362992ca11a35b2227f7922d8143e7af5888cf595a5b636b441768385', 2, '2024-06-13 10:04:26', NULL, '2024-06-13', 'asd', 'dasdas');

-- --------------------------------------------------------

--
-- Table structure for table `file_trash`
--

CREATE TABLE `file_trash` (
  `id` int(11) NOT NULL,
  `folder_id` int(11) DEFAULT NULL,
  `original_file_name` varchar(255) DEFAULT NULL,
  `file_extension` varchar(10) DEFAULT NULL,
  `uploaded_file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `uploaded_by` varchar(255) DEFAULT NULL,
  `uploaded_date` datetime DEFAULT NULL,
  `deleted_by` varchar(255) DEFAULT NULL,
  `deleted_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `file_trash`
--

INSERT INTO `file_trash` (`id`, `folder_id`, `original_file_name`, `file_extension`, `uploaded_file_name`, `file_path`, `uploaded_by`, `uploaded_date`, `deleted_by`, `deleted_date`) VALUES
(38, 17, 'Men Are From Mars Women Are From Venus_51.pdf', 'pdf', '54fa62f02b411280489c4b5ef1dc13c7c9ef0123a0ba96ddf47669fcbafc9d49', 'uploads/54fa62f02b411280489c4b5ef1dc13c7c9ef0123a0ba96ddf47669fcbafc9d49_trashed', '2', '2024-06-12 15:59:53', '2', '2024-06-13 15:06:42');

-- --------------------------------------------------------

--
-- Table structure for table `folders`
--

CREATE TABLE `folders` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `parent_folder_id` int(11) DEFAULT NULL,
  `folder_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `folders`
--

INSERT INTO `folders` (`id`, `department_id`, `parent_folder_id`, `folder_name`, `created_at`) VALUES
(18, 8, 8, 'Page101-150', '2024-06-12 12:39:11'),
(17, 8, 8, 'Page51-100', '2024-06-12 12:38:57'),
(16, 8, 8, 'Page1-50', '2024-06-12 11:54:51'),
(15, 8, NULL, 'BOOKS', '2024-06-12 11:51:37'),
(19, 8, 8, 'Page151-200', '2024-06-12 12:39:25'),
(20, 8, 8, 'Another Files', '2024-06-13 11:14:02');

-- --------------------------------------------------------

--
-- Table structure for table `folder_permissions`
--

CREATE TABLE `folder_permissions` (
  `id` int(11) NOT NULL,
  `Folderid` int(11) NOT NULL,
  `Departmentname` varchar(255) NOT NULL,
  `Departmentid` int(11) NOT NULL,
  `Assignedby` int(11) NOT NULL,
  `AssignedTo` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Lastmodified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Remarks` text DEFAULT NULL,
  `Permission_type` enum('read','read_write','full_permission','view_only','no_access') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `folder_permissions`
--

INSERT INTO `folder_permissions` (`id`, `Folderid`, `Departmentname`, `Departmentid`, `Assignedby`, `AssignedTo`, `Created_at`, `Lastmodified`, `Remarks`, `Permission_type`) VALUES
(36, 11, 'Accounts', 9, 1, 1, '2024-06-27 10:33:37', '2024-06-27 10:33:37', 'Full Permission', 'full_permission'),
(37, 12, 'Accounts', 9, 1, 1, '2024-06-27 10:33:37', '2024-06-27 10:33:37', 'Full Permission', 'full_permission'),
(38, 13, 'Accounts', 9, 1, 1, '2024-06-27 10:33:37', '2024-06-27 10:33:37', 'Full Permission', 'full_permission');

-- --------------------------------------------------------

--
-- Table structure for table `folder_permissionsold`
--

CREATE TABLE `folder_permissionsold` (
  `id` int(11) NOT NULL,
  `Foldername` varchar(255) NOT NULL,
  `Folderid` int(11) NOT NULL,
  `Departmentname` varchar(255) NOT NULL,
  `Departmentid` int(11) NOT NULL,
  `Assignedby` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Lastmodified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Remarks` text DEFAULT NULL,
  `Permission_type` enum('read','read_write','full','view') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `timestamp` timestamp NULL DEFAULT current_timestamp(),
  `description` varchar(255) DEFAULT NULL,
  `admin_id` int(11) NOT NULL,
  `department_id` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `action`, `timestamp`, `description`, `admin_id`, `department_id`) VALUES
(114, 3, 'reset_password', '2024-06-12 12:50:02', 'Reset password for user sulfi', 1, ''),
(113, 3, 'assign_department', '2024-06-12 11:51:56', 'Assigned department 8 with permission: read', 1, ''),
(112, 2, 'assign_department', '2024-06-12 11:51:51', 'Assigned department 8 with permission: full', 1, ''),
(111, NULL, 'create_department', '2024-06-12 11:51:37', 'Created department BOOKS', 1, ''),
(110, 3, 'reset_password', '2024-06-12 11:51:26', 'Reset password for user sulfi', 1, ''),
(109, 2, 'reset_password', '2024-06-12 11:51:19', 'Reset password for user sandy', 1, ''),
(115, 2, 'reset_password', '2024-06-15 21:10:03', 'Reset password for user sandy', 1, ''),
(116, NULL, 'delete_department', '2024-06-19 12:55:28', 'Deleted department fg', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `master_folder`
--

CREATE TABLE `master_folder` (
  `id` int(11) NOT NULL,
  `Foldername` varchar(255) NOT NULL,
  `DepartmentId` int(11) NOT NULL,
  `DepartmentName` varchar(255) NOT NULL,
  `Createdby` int(11) NOT NULL,
  `lastupdatedby` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` tinyint(1) DEFAULT 1,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_on` timestamp NULL DEFAULT NULL,
  `restored_by` int(11) DEFAULT NULL,
  `restored_on` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `master_folder`
--

INSERT INTO `master_folder` (`id`, `Foldername`, `DepartmentId`, `DepartmentName`, `Createdby`, `lastupdatedby`, `created_at`, `updated_at`, `deleted`, `deleted_by`, `deleted_on`, `restored_by`, `restored_on`) VALUES
(11, 'Banks', 9, 'Accounts', 1, 1, '2024-06-27 10:32:56', '2024-06-27 10:32:56', 1, NULL, NULL, NULL, NULL),
(12, 'Projects', 9, 'Accounts', 1, 1, '2024-06-27 10:33:02', '2024-06-27 10:33:02', 1, NULL, NULL, NULL, NULL),
(13, 'Vendors', 9, 'Accounts', 1, 1, '2024-06-27 10:33:20', '2024-06-27 10:33:20', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sub_folders`
--

CREATE TABLE `sub_folders` (
  `id` int(11) NOT NULL,
  `sub_folder_name` varchar(255) NOT NULL,
  `master_folder_name` varchar(255) NOT NULL,
  `master_folder_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `lastmodified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `lastmodifiedby` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `remarks` text DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT 1,
  `is_master_folder` tinyint(1) DEFAULT 0,
  `department_id` int(11) NOT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_on` timestamp NULL DEFAULT NULL,
  `restored_by` int(11) DEFAULT NULL,
  `restored_on` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `sub_folders`
--

INSERT INTO `sub_folders` (`id`, `sub_folder_name`, `master_folder_name`, `master_folder_id`, `created_by`, `lastmodified`, `lastmodifiedby`, `timestamp`, `remarks`, `deleted`, `is_master_folder`, `department_id`, `deleted_by`, `deleted_on`, `restored_by`, `restored_on`) VALUES
(10001, 'Riyad Bank', 'Banks_subfolder', 11, 1, '2024-06-27 10:35:00', 1, '2024-06-27 10:35:00', 'riyad Bank Documents', 1, 0, 9, NULL, NULL, NULL, NULL),
(10002, 'SNB Banks', 'Banks_subfolder', 11, 1, '2024-06-27 10:35:22', 1, '2024-06-27 10:35:22', 'snb bank documents', 1, 0, 9, NULL, NULL, NULL, NULL),
(10003, 'AlRajhi Bank ', 'Banks_subfolder', 11, 1, '2024-06-27 10:35:52', 1, '2024-06-27 10:35:52', 'alrajhi bank Documents', 1, 0, 9, NULL, NULL, NULL, NULL),
(10004, 'SBI', 'Banks_subfolder', 11, 1, '2024-06-27 10:36:10', 1, '2024-06-27 10:36:10', 'state bank of india documnets', 1, 0, 9, NULL, NULL, NULL, NULL),
(10005, 'Balance', 'Riyad Bank_subfolder', 10001, 1, '2024-06-27 10:36:46', 1, '2024-06-27 10:36:46', 'balance sheet data', 1, 0, 9, NULL, NULL, NULL, NULL),
(10006, 'Transactions', 'Riyad Bank_subfolder', 10001, 1, '2024-06-27 10:37:04', 1, '2024-06-27 10:37:04', 'transaction which was done', 1, 0, 9, NULL, NULL, NULL, NULL),
(10007, 'Balance ', 'SNB Banks_subfolder', 10002, 1, '2024-06-27 10:37:19', 1, '2024-06-27 10:37:19', 'Balance  sheet', 1, 0, 9, NULL, NULL, NULL, NULL),
(10008, 'Transactions ', 'SNB Banks_subfolder', 10002, 1, '2024-06-27 10:37:31', 1, '2024-06-27 10:37:31', 'all trasactions', 1, 0, 9, NULL, NULL, NULL, NULL),
(10009, 'Balance', 'AlRajhi Bank _subfolder', 10003, 1, '2024-06-27 10:37:44', 1, '2024-06-27 10:37:44', 'Balance sheet', 1, 0, 9, NULL, NULL, NULL, NULL),
(10010, 'Transactions', 'AlRajhi Bank _subfolder', 10003, 1, '2024-06-27 10:38:00', 1, '2024-06-27 10:38:00', 'transactions data', 1, 0, 9, NULL, NULL, NULL, NULL),
(10011, 'Mutual Funds', 'SBI_subfolder', 10004, 1, '2024-06-27 10:38:24', 1, '2024-06-27 10:38:24', 'mutual funds which applied', 1, 0, 9, NULL, NULL, NULL, NULL),
(10012, 'Stocks ', 'SBI_subfolder', 10004, 1, '2024-06-27 10:38:51', 1, '2024-06-27 10:38:51', 'stocks which purchased', 1, 0, 9, NULL, NULL, NULL, NULL),
(10013, 'Magna', 'Projects_subfolder', 12, 1, '2024-06-27 10:39:04', 1, '2024-06-27 10:39:04', '', 1, 0, 9, NULL, NULL, NULL, NULL),
(10014, 'Trojena', 'Projects_subfolder', 12, 1, '2024-06-27 10:39:11', 1, '2024-06-27 10:39:11', '', 1, 0, 9, NULL, NULL, NULL, NULL),
(10015, 'Oxagon', 'Projects_subfolder', 12, 1, '2024-06-27 10:39:18', 1, '2024-06-27 10:39:18', '', 1, 0, 9, NULL, NULL, NULL, NULL),
(10016, 'Submission', 'Magna_subfolder', 10013, 1, '2024-06-27 10:39:29', 1, '2024-06-27 10:39:29', '', 1, 0, 9, NULL, NULL, NULL, NULL),
(10017, 'Sub-contractor', 'Magna_subfolder', 10013, 1, '2024-06-27 10:39:41', 1, '2024-06-27 10:39:41', '', 1, 0, 9, NULL, NULL, NULL, NULL),
(10018, 'Submission', 'Trojena_subfolder', 10014, 1, '2024-06-27 10:39:55', 1, '2024-06-27 10:39:55', '', 1, 0, 9, NULL, NULL, NULL, NULL),
(10019, 'Sub-Contactor', 'Trojena_subfolder', 10014, 1, '2024-06-27 10:40:07', 1, '2024-06-27 10:40:07', '', 1, 0, 9, NULL, NULL, NULL, NULL),
(10020, 'Crown', 'Vendors_subfolder', 13, 1, '2024-06-27 10:40:18', 1, '2024-06-27 10:40:18', 'Crown-Tonners', 1, 0, 9, NULL, NULL, NULL, NULL),
(10021, 'ABM-Toshiba', 'Vendors_subfolder', 13, 1, '2024-06-27 10:40:30', 1, '2024-06-27 10:40:30', '', 1, 0, 9, NULL, NULL, NULL, NULL),
(10022, 'Xerox', 'Vendors_subfolder', 13, 1, '2024-06-27 10:40:35', 1, '2024-06-27 10:40:35', '', 1, 0, 9, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `uploaded_content`
--

CREATE TABLE `uploaded_content` (
  `id` int(11) NOT NULL,
  `orginalfilename` varchar(255) NOT NULL,
  `filesize` int(11) NOT NULL,
  `filetype` varchar(50) NOT NULL,
  `validation` text DEFAULT NULL,
  `Expirydate` date DEFAULT NULL,
  `extracted_text` longtext DEFAULT NULL,
  `filepath` varchar(255) NOT NULL,
  `folderid` int(11) DEFAULT NULL,
  `is_subfolder` tinyint(1) DEFAULT 0,
  `doc_number` varchar(50) DEFAULT NULL,
  `doc_type` varchar(50) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `uploadedby` int(11) NOT NULL,
  `uploadeddate` timestamp NOT NULL DEFAULT current_timestamp(),
  `delete` tinyint(1) DEFAULT 1,
  `verifiedby` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_on` timestamp NULL DEFAULT NULL,
  `restored_by` int(11) DEFAULT NULL,
  `restored_on` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `status`) VALUES
(1, 'admin', '$2y$10$.HNsCwEhFMzFLXXgfsKDluB8UkepMYopUXcCEh/lhLxGyunnGV9O.', 'admin', 'active'),
(2, 'sandy', '$2y$10$JtysCPMY.h/XyTPtSFNaEOMNBsKF9ngqEkdR3WK7l/LRAD2EOV4NK', 'user', 'active'),
(3, 'sulfi', '$2y$10.BpK1nxzWnXb8ZZRKE3GzlOmcddi7W/.', 'user', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `user_departments`
--

CREATE TABLE `user_departments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `permission` enum('read','read/write','modify','full') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_departments`
--

INSERT INTO `user_departments` (`id`, `user_id`, `department_id`, `permission`) VALUES
(13, 2, 8, 'full'),
(14, 3, 8, 'read');

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ip_address` text NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_sessions`
--

INSERT INTO `user_sessions` (`id`, `user_id`, `session_id`, `last_activity`, `ip_address`, `login_time`) VALUES
(7, 3, 'u4sg5o2go9q5b1s6uq1799lek8', '2024-06-25 13:25:13', '127.0.0.1', '2024-06-25 12:21:02'),
(11, 1, 'jts3ip77riq62j23bkff5n7o6g', '2024-06-27 10:32:27', '::1', '2024-06-27 09:32:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `folder_id` (`folder_id`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `file_trash`
--
ALTER TABLE `file_trash`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `folders`
--
ALTER TABLE `folders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `parent_folder_id` (`parent_folder_id`);

--
-- Indexes for table `folder_permissions`
--
ALTER TABLE `folder_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Folderid` (`Folderid`),
  ADD KEY `Assignedby` (`Assignedby`),
  ADD KEY `AssignedTo` (`AssignedTo`);

--
-- Indexes for table `folder_permissionsold`
--
ALTER TABLE `folder_permissionsold`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Folderid` (`Folderid`),
  ADD KEY `Assignedby` (`Assignedby`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `master_folder`
--
ALTER TABLE `master_folder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_folders`
--
ALTER TABLE `sub_folders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploaded_content`
--
ALTER TABLE `uploaded_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `folderid` (`folderid`),
  ADD KEY `uploadedby` (`uploadedby`),
  ADD KEY `verifiedby` (`verifiedby`),
  ADD KEY `uploaded_content_ibfk_1` (`department_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_departments`
--
ALTER TABLE `user_departments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=283;

--
-- AUTO_INCREMENT for table `file_trash`
--
ALTER TABLE `file_trash`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `folders`
--
ALTER TABLE `folders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `folder_permissions`
--
ALTER TABLE `folder_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `folder_permissionsold`
--
ALTER TABLE `folder_permissionsold`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `master_folder`
--
ALTER TABLE `master_folder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `sub_folders`
--
ALTER TABLE `sub_folders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10023;

--
-- AUTO_INCREMENT for table `uploaded_content`
--
ALTER TABLE `uploaded_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_departments`
--
ALTER TABLE `user_departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `folder_permissions`
--
ALTER TABLE `folder_permissions`
  ADD CONSTRAINT `folder_permissions_ibfk_1` FOREIGN KEY (`Folderid`) REFERENCES `master_folder` (`id`),
  ADD CONSTRAINT `folder_permissions_ibfk_2` FOREIGN KEY (`Assignedby`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `folder_permissions_ibfk_3` FOREIGN KEY (`AssignedTo`) REFERENCES `employees` (`id`);

--
-- Constraints for table `folder_permissionsold`
--
ALTER TABLE `folder_permissionsold`
  ADD CONSTRAINT `folder_permissionsold_ibfk_1` FOREIGN KEY (`Folderid`) REFERENCES `master_folder` (`id`),
  ADD CONSTRAINT `folder_permissionsold_ibfk_2` FOREIGN KEY (`Assignedby`) REFERENCES `employees` (`id`);

--
-- Constraints for table `uploaded_content`
--
ALTER TABLE `uploaded_content`
  ADD CONSTRAINT `uploaded_content_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `uploaded_content_ibfk_2` FOREIGN KEY (`uploadedby`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `uploaded_content_ibfk_3` FOREIGN KEY (`verifiedby`) REFERENCES `employees` (`id`);

--
-- Constraints for table `user_departments`
--
ALTER TABLE `user_departments`
  ADD CONSTRAINT `fk_user_departments_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user_departments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
