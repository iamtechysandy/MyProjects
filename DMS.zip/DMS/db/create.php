<?php
// Database configuration
$servername = "127.0.0.1";
$username = "root";
$password = ""; // Your database password
$dbname = "user_management";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully\n";
} else {
    echo "Error creating database: " . $conn->error;
}

// Select the database
$conn->select_db($dbname);

// SQL dump array to execute commands one by one
$sqls = [
    "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';",
    "START TRANSACTION;",
    "SET time_zone = '+00:00';",
    "/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;",
    "/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;",
    "/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;",
    "/*!40101 SET NAMES utf8mb4 */;",

    "DROP TABLE IF EXISTS `departments`;",
    "CREATE TABLE IF NOT EXISTS `departments` (
      `id` int NOT NULL AUTO_INCREMENT,
      `department_name` varchar(100) NOT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;",
    "INSERT INTO `departments` (`id`, `department_name`) VALUES (8, 'BOOKS');",

    "DROP TABLE IF EXISTS `files`;",
    "CREATE TABLE IF NOT EXISTS `files` (
      `id` int NOT NULL AUTO_INCREMENT,
      `folder_id` int NOT NULL,
      `original_file_name` varchar(255) NOT NULL,
      `file_extension` varchar(50) NOT NULL,
      `uploaded_file_name` varchar(255) NOT NULL,
      `file_path` varchar(255) NOT NULL,
      `uploaded_by` int NOT NULL,
      `uploaded_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
      `validation` varchar(20) DEFAULT NULL,
      `expiry_date` date DEFAULT NULL,
      `doc_number` varchar(255) DEFAULT NULL,
      `description` text,
      PRIMARY KEY (`id`),
      KEY `folder_id` (`folder_id`),
      KEY `uploaded_by` (`uploaded_by`)
    ) ENGINE=MyISAM AUTO_INCREMENT=283 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;",

    "DROP TABLE IF EXISTS `file_trash`;",
    "CREATE TABLE IF NOT EXISTS `file_trash` (
      `id` int NOT NULL AUTO_INCREMENT,
      `folder_id` int DEFAULT NULL,
      `original_file_name` varchar(255) DEFAULT NULL,
      `file_extension` varchar(10) DEFAULT NULL,
      `uploaded_file_name` varchar(255) DEFAULT NULL,
      `file_path` varchar(255) DEFAULT NULL,
      `uploaded_by` varchar(255) DEFAULT NULL,
      `uploaded_date` datetime DEFAULT NULL,
      `deleted_by` varchar(255) DEFAULT NULL,
      `deleted_date` datetime DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;",
    "INSERT INTO `file_trash` (`id`, `folder_id`, `original_file_name`, `file_extension`, `uploaded_file_name`, `file_path`, `uploaded_by`, `uploaded_date`, `deleted_by`, `deleted_date`) VALUES (38, 17, 'Men Are From Mars Women Are From Venus_51.pdf', 'pdf', '54fa62f02b411280489c4b5ef1dc13c7c9ef0123a0ba96ddf47669fcbafc9d49', 'uploads/54fa62f02b411280489c4b5ef1dc13c7c9ef0123a0ba96ddf47669fcbafc9d49_trashed', '2', '2024-06-12 15:59:53', '2', '2024-06-13 15:06:42');",

    "DROP TABLE IF EXISTS `folders`;",
    "CREATE TABLE IF NOT EXISTS `folders` (
      `id` int NOT NULL AUTO_INCREMENT,
      `department_id` int NOT NULL,
      `parent_folder_id` int DEFAULT NULL,
      `folder_name` varchar(255) NOT NULL,
      `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`),
      KEY `department_id` (`department_id`),
      KEY `parent_folder_id` (`parent_folder_id`)
    ) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;",
    "INSERT INTO `folders` (`id`, `department_id`, `parent_folder_id`, `folder_name`, `created_at`) VALUES
      (18, 8, 8, 'Page101-150', '2024-06-12 12:39:11'),
      (17, 8, 8, 'Page51-100', '2024-06-12 12:38:57'),
      (16, 8, 8, 'Page1-50', '2024-06-12 11:54:51'),
      (15, 8, NULL, 'BOOKS', '2024-06-12 11:51:37'),
      (19, 8, 8, 'Page151-200', '2024-06-12 12:39:25'),
      (20, 8, 8, 'Another Files', '2024-06-13 11:14:02');",

    "DROP TABLE IF EXISTS `logs`;",
    "CREATE TABLE IF NOT EXISTS `logs` (
      `id` int NOT NULL AUTO_INCREMENT,
      `user_id` int DEFAULT NULL,
      `action` varchar(255) NOT NULL,
      `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
      `description` varchar(255) DEFAULT NULL,
      `admin_id` int NOT NULL,
      `department_id` text NOT NULL,
      PRIMARY KEY (`id`),
      KEY `user_id` (`user_id`)
    ) ENGINE=MyISAM AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;",
    "INSERT INTO `logs` (`id`, `user_id`, `action`, `timestamp`, `description`, `admin_id`, `department_id`) VALUES
      (114, 3, 'reset_password', '2024-06-12 12:50:02', 'Reset password for user sulfi', 1, ''),
      (113, 3, 'assign_department', '2024-06-12 11:51:56', 'Assigned department 8 with permission: read', 1, ''),
      (112, 2, 'assign_department', '2024-06-12 11:51:51', 'Assigned department 8 with permission: full', 1, ''),
      (111, NULL, 'create_department', '2024-06-12 11:51:37', 'Created department BOOKS', 1, ''),
      (110, 3, 'reset_password', '2024-06-12 11:51:26', 'Reset password for user sulfi', 1, ''),
      (109, 2, 'reset_password', '2024-06-12 11:51:19', 'Reset password for user sandy', 1, '');",

    "DROP TABLE IF EXISTS `users`;",
    "CREATE TABLE IF NOT EXISTS `users` (
      `id` int NOT NULL AUTO_INCREMENT,
      `username` varchar(50) NOT NULL,
      `password` varchar(255) NOT NULL,
      `role` varchar(20) NOT NULL,
      `status` varchar(10) NOT NULL DEFAULT 'active',
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;",
    "INSERT INTO `users` (`id`, `username`, `password`, `role`, `status`) VALUES
      (1, 'admin', '$2y$10$.HNsCwEhFMzFLXXgfsKDluB8UkepMYopUXcCEh/lhLxGyunnGV9O.', 'admin', 'active'),
      (2, 'sandy', '$2y$10$8VxM46LT5zD1uplYN3OZ2.7Ayw.y39zsSIPUJcKEB2JHS7SwAYsp2', 'user', 'active'),
      (3, 'sulfi', '$2y$10$shsRCD35jzdrMeOKY7qWl.BpK1nxzWnXb8ZZRKE3GzlOmcddi7W/.', 'user', 'active');",

    "DROP TABLE IF EXISTS `user_departments`;",
    "CREATE TABLE IF NOT EXISTS `user_departments` (
      `id` int NOT NULL AUTO_INCREMENT,
      `user_id` int NOT NULL,
      `department_id` int NOT NULL,
      `permission` enum('read','read/write','modify','full') NOT NULL,
      PRIMARY KEY (`id`),
      KEY `user_id` (`user_id`),
      KEY `department_id` (`department_id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;",
    "INSERT INTO `user_departments` (`id`, `user_id`, `department_id`, `permission`) VALUES
      (13, 2, 8, 'full'),
      (14, 3, 8, 'read');",

    "ALTER TABLE `user_departments`
      ADD CONSTRAINT `fk_user_departments_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
      ADD CONSTRAINT `fk_user_departments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;",
    "COMMIT;",
    "/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;",
    "/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;",
    "/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;"
];

// Execute the SQL queries one by one
foreach ($sqls as $query) {
    if ($conn->query($query) === TRUE) {
        echo "Query executed successfully: " . $query . "\n";
    } else {
        echo "Error executing query: " . $query . " - " . $conn->error . "\n";
    }
}

// Close connection
$conn->close();
