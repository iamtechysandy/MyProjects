<?php
include 'db.php';

function logAction($adminId, $userId, $action, $description)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO logs (admin_id, user_id, action, description) VALUES (:admin_id, :user_id, :action, :description)");
    $stmt->bindParam(':admin_id', $adminId);
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':action', $action);
    $stmt->bindParam(':description', $description);
    $stmt->execute();
}

function createUser($username, $password, $role)
{
    global $conn;
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (:username, :password, :role)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':role', $role);
    $success = $stmt->execute();
    if ($success) {
        logAction($_SESSION['admin_id'], $conn->lastInsertId(), 'create', "Created user $username with role $role");
    }
    return $success;
}

function disableUser($id)
{
    global $conn;
    $user = getUserById($id);
    $stmt = $conn->prepare("UPDATE users SET status = 'disabled' WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $success = $stmt->execute();
    if ($success) {
        logAction($_SESSION['admin_id'], $id, 'disable', "Disabled user $user[username]");
    }
    return $success;
}

function enableUser($id)
{
    global $conn;
    $user = getUserById($id);
    $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $success = $stmt->execute();
    if ($success) {
        logAction($_SESSION['admin_id'], $id, 'enable', "Enabled user $user[username]");
    }
    return $success;
}

function resetPassword($id, $newPassword)
{
    global $conn;
    $user = getUserById($id);
    $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE users SET password = :password WHERE id = :id");
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':id', $id);
    $success = $stmt->execute();
    if ($success) {
        logAction($_SESSION['admin_id'], $id, 'reset_password', "Reset password for user $user[username]");
    }
    return $success;
}

function changeRole($id, $newRole)
{
    global $conn;
    $user = getUserById($id);
    $stmt = $conn->prepare("UPDATE users SET role = :role WHERE id = :id");
    $stmt->bindParam(':role', $newRole);
    $stmt->bindParam(':id', $id);
    $success = $stmt->execute();
    if ($success) {
        logAction($_SESSION['admin_id'], $id, 'change_role', "Changed role for user $user[username] to $newRole");
    }
    return $success;
}

function getUserById($id)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function createDepartment($departmentName)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO departments (department_name) VALUES (:department_name)");
    $stmt->bindParam(':department_name', $departmentName);
    $success = $stmt->execute();

    if ($success) {
        // Create a parent folder with the department name
        $parentFolderName = $departmentName;
        $stmt = $conn->prepare("INSERT INTO folders (department_id, folder_name) VALUES (:department_id, :folder_name)");
        $stmt->bindParam(':department_id', $conn->lastInsertId()); // Get the last inserted department_id
        $stmt->bindParam(':folder_name', $parentFolderName);
        $stmt->execute();

        logAction($_SESSION['admin_id'], null, 'create_department', "Created department $departmentName");
    }

    return $success;
}


function deleteDepartment($departmentId)
{
    global $conn;
    $department = getDepartmentById($departmentId);
    $stmt = $conn->prepare("DELETE FROM departments WHERE id = :id");
    $stmt->bindParam(':id', $departmentId);
    $success = $stmt->execute();
    if ($success) {
        logAction($_SESSION['admin_id'], null, 'delete_department', "Deleted department $department[department_name]");
    }
    return $success;
}

function getDepartmentById($id)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM departments WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function assignUserToDepartment($userId, $departmentId, $permission)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO user_departments (user_id, department_id, permission) VALUES (:user_id, :department_id, :permission)
                            ON DUPLICATE KEY UPDATE permission = :permission");
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':department_id', $departmentId);
    $stmt->bindParam(':permission', $permission);

    $success = $stmt->execute();

    if ($success) {
        logAction($_SESSION['admin_id'], $userId, 'assign_department', "Assigned department $departmentId with permission: $permission");
    } else {
        // Optionally handle the error in a more user-friendly way
        // $errorInfo = $stmt->errorInfo();
        // echo "Error: " . $errorInfo[2];
    }

    return $success;
}



function getUserDepartments()
{
    global $conn;
    $stmt = $conn->query("
        SELECT 
            ud.user_id,
            ud.department_id,
            ud.permission,
            u.username,
            d.department_name
        FROM user_departments ud
        JOIN users u ON ud.user_id = u.id
        JOIN departments d ON ud.department_id = d.id
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
