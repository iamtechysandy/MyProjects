<?php
session_start();
include 'functions.php';

// Check if admin is already logged in
if (isset($_SESSION['admin_id'])) {
    header("Location: admin.php");
    exit;
}

// Check if there are any admin users
$stmt = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
$adminCount = $stmt->fetchColumn();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($adminCount === 0) {
        // Process form to create admin user
        $username = $_POST['admin_username'];
        $password = $_POST['admin_password'];
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Insert admin user into database
        $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (:username, :password, 'admin')");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->execute();

        // Redirect to admin login page after creating admin user
        header("Location: admin_login.php");
        exit;
    } else {
        // Process admin login
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Check admin credentials
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username AND role = 'admin'");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            header("Location: admin.php");
            exit;
        } else {
            $error = "Invalid username or password";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h2>Admin Login</h2>
        <?php if ($adminCount === 0) : ?>
            <!-- Form to create admin user -->
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="admin_username" class="form-label">Admin Username</label>
                    <input type="text" class="form-control" id="admin_username" name="admin_username" required>
                </div>
                <div class="mb-3">
                    <label for="admin_password" class="form-label">Admin Password</label>
                    <input type="password" class="form-control" id="admin_password" name="admin_password" required>
                </div>
                <button type="submit" class="btn btn-primary">Create Admin User</button>
            </form>
        <?php else : ?>
            <!-- Form for admin login -->
            <?php if (isset($error)) : ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
        <?php endif; ?>
    </div>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-beta3/js/bootstrap.bundle.min.js"></script>
</body>

</html>