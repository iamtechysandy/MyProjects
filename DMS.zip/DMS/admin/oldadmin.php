<?php
session_start();
include 'functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create_user'])) {
        createUser($_POST['username'], $_POST['password'], $_POST['role']);
    } elseif (isset($_POST['disable_user'])) {
        disableUser($_POST['user_id']);
    } elseif (isset($_POST['enable_user'])) {
        enableUser($_POST['user_id']);
    } elseif (isset($_POST['reset_password'])) {
        resetPassword($_POST['user_id'], $_POST['new_password']);
    } elseif (isset($_POST['change_role'])) {
        changeRole($_POST['user_id'], $_POST['new_role']);
    }
}

// Fetch all users for display
$users = $conn->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <a href="logout.php"><i class="bi bi-box-arrow-right" style="font-size: 5rem;"></i></a>

        <h2>Admin Dashboard</h2>

        <div class="mb-4">
            <h4>Create User</h4>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">Role</label>
                    <select class="form-control" id="role" name="role" required>
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" name="create_user">Create User</button>
            </form>
        </div>

        <div class="mb-4">
            <h4>Users</h4>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user) : ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><?php echo $user['username']; ?></td>
                            <td><?php echo $user['role']; ?></td>
                            <td><?php echo $user['status']; ?></td>
                            <td>
                                <form method="POST" action="" style="display: inline-block;">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <?php if ($user['status'] == 'active') : ?>
                                        <button type="submit" class="btn btn-warning" name="disable_user">Disable</button>
                                    <?php else : ?>
                                        <button type="submit" class="btn btn-success" name="enable_user">Enable</button>
                                    <?php endif; ?>
                                </form>
                                <form method="POST" action="" style="display: inline-block;">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <input type="password" class="form-control" name="new_password" placeholder="New Password" required>
                                    <button type="submit" class="btn btn-info" name="reset_password">Reset Password</button>
                                </form>
                                <form method="POST" action="" style="display: inline-block;">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <select class="form-control" name="new_role" required>
                                        <option value="user" <?php echo $user['role'] == 'user' ? 'selected' : ''; ?>>User</option>
                                        <option value="admin" <?php echo $user['role'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                                    </select>
                                    <button type="submit" class="btn btn-secondary" name="change_role">Change Role</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-beta3/js/bootstrap.bundle.min.js"></script>
</body>

</html>