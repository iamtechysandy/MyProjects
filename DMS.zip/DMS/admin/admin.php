<?php
session_start();
include 'functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create_user'])) {
        createUser($_POST['username'], $_POST['password'], $_POST['role']);
    } elseif (isset($_POST['disable_user'])) {
        disableUser($_POST['user_id']);
    } elseif (isset($_POST['enable_user'])) {
        enableUser($_POST['user_id']);
    } elseif (isset($_POST['reset_password'])) {
        resetPassword($_POST['user_id'], $_POST['new_password']);
    } elseif (isset($_POST['change_role'])) {
        changeRole($_POST['user_id'], $_POST['new_role']);
    } elseif (isset($_POST['create_department'])) {
        createDepartment($_POST['department_name']);
    } elseif (isset($_POST['delete_department'])) {
        deleteDepartment($_POST['department_id']);
    }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['assign_user'])) {
        $permissions = isset($_POST['permission']) ? $_POST['permission'] : [];
        assignUserToDepartment($_POST['user_id'], $_POST['department_id'], $permissions);
    }
}

// Fetch all users for display
$users = $conn->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);
$departments = $conn->query("SELECT * FROM departments")->fetchAll(PDO::FETCH_ASSOC);
$stmt = $conn->query("SELECT logs.*, users.username AS user_username, admins.username AS admin_username 
                      FROM logs 
                      LEFT JOIN users ON logs.user_id = users.id 
                      LEFT JOIN users AS admins ON logs.admin_id = admins.id 
                      ORDER BY logs.id DESC");
$userDepartments = getUserDepartments();
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DMS 2.0 -Admin</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="main-body">
        <div class="side-bar">
            <button class="collapse-btn" id="collapse-btn"><i class="bi bi-list"></i></button>
            <div class="side-bar-li active" id="home">
                <i class="bi bi-house-exclamation-fill"></i> <span>Create Users</span>
            </div>
            <div class="side-bar-li" id="customize">
                <i class="bi bi-gear-fill"></i> <span>Users Setting</span>
            </div>
            <div class="side-bar-li" id="employee">
                <i class="bi bi-clipboard-data"></i> <span>Audit Logs</span>
            </div>
            <div class="side-bar-li" id="asset">
                <i class="bi bi-building-fill-gear"></i> <span>Departments</span>
            </div>
            <div class="side-bar-li" id="profile">
                <i class="bi bi-buildings"></i> <span>User Department</span>
            </div>
            <div class="side-bar-li last-li" id="help">
                <i class="bi bi-question-circle-fill"></i> <span>Help</span>
            </div>
            <div class="side-bar-li toggle-switch">
                <input type="checkbox" id="dark-mode-toggle">
                <label for="dark-mode-toggle">Dark Mode</label>


            </div>
            <div class="side-bar-li toggle-switch">
                <a href="logout.php"><i class="bi bi-box-arrow-right" style="font-size: 2rem;"></i></a>


            </div>
        </div>
        <div class="main-content">
            <div class="content active" id="home-content">
                <h2>Admin Dashboard</h2>

                <div class="mb-4">
                    <h4>Create User</h4>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select class="form-control" id="role" name="role" required>
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary" name="create_user">Create User</button>
                    </form>
                </div>
            </div>
            <div class="content" id="customize-content">
                <div class="mb-4">
                    <h4>Users</h4>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username<i class="bi bi-person"></i></th>
                                <th>Role</th>
                                <th>Status<i class="bi bi-option"></i></th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user) : ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo $user['username']; ?></td>
                                    <td><?php echo $user['role']; ?></td>
                                    <td><?php echo $user['status']; ?></td>
                                    <td>
                                        <form method="POST" action="" style="display: inline-block;">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <?php if ($user['status'] == 'active') : ?>
                                                <button type="submit" class="btn btn-warning" name="disable_user">Disable</button>
                                            <?php else : ?>
                                                <button type="submit" class="btn btn-success" name="enable_user">Enable</button>
                                            <?php endif; ?>
                                        </form>
                                        <form method="POST" action="" style="display: inline-block;">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="password" class="form-control" name="new_password" placeholder="New Password" required>
                                            <button type="submit" class="btn btn-info" name="reset_password">Reset Password</button>
                                        </form>
                                        <form method="POST" action="" style="display: inline-block;">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <select class="form-control" name="new_role" required>
                                                <option value="user" <?php echo $user['role'] == 'user' ? 'selected' : ''; ?>>User</option>
                                                <option value="admin" <?php echo $user['role'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                                            </select>
                                            <button type="submit" class="btn btn-secondary" name="change_role">Change Role</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="content" id="employee-content">

                <h2>View Logs</h2>
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Admin</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Description</th>
                            <th>Timestamp <i class="bi bi-calendar2-event"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $index => $log) : ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo $log['admin_username']; ?></td>
                                <td><?php echo $log['user_username']; ?></td>
                                <td><?php echo $log['action']; ?></td>
                                <td><?php echo $log['description']; ?></td>
                                <td><?php echo $log['timestamp']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div>
            <div class="content" id="asset-content">
                <div class="mb-4">
                    <h4>Create Department</h4>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="department_name" class="form-label">Department Name</label>
                            <input type="text" class="form-control" id="department_name" name="department_name" required>
                        </div>
                        <button type="submit" class="btn btn-primary" name="create_department">Create Department</button>
                    </form>
                </div>
                <div class="mb-4">
                    <h4>Departments</h4>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Department Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($departments as $department) : ?>
                                <tr>
                                    <td><?php echo $department['id']; ?></td>
                                    <td><?php echo $department['department_name']; ?></td>
                                    <td>
                                        <form method="POST" action="">
                                            <input type="hidden" name="department_id" value="<?php echo $department['id']; ?>">
                                            <button type="submit" class="btn btn-danger" name="delete_department">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="content" id="profile-content">
                <h2>Assign User to Department</h2>
                <div class="mb-4">
                    <h4>Assign User</h4>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="user_id" class="form-label">User</label>
                            <select class="form-control" id="user_id" name="user_id" required>
                                <?php foreach ($users as $user) : ?>
                                    <option value="<?php echo $user['id']; ?>"><?php echo $user['username']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="department_id" class="form-label">Department</label>
                            <select class="form-control" id="department_id" name="department_id" required>
                                <?php foreach ($departments as $department) : ?>
                                    <option value="<?php echo $department['id']; ?>"><?php echo $department['department_name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="permission" class="form-label">Permission</label>
                            <select class="form-control" id="permission" name="permission" required>
                                <option value="read">Read Only</option>
                                <option value="read/write">Read/Write</option>
                                <option value="full">Full Control</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary" name="assign_user">Assign User</button>
                    </form>
                </div>
                <div class="mb-4">
                    <h4>Assigned Users</h4>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Department</th>
                                <th>Permission</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($userDepartments as $userDepartment) : ?>
                                <tr>
                                    <td><?php echo $userDepartment['username']; ?></td>
                                    <td><?php echo $userDepartment['department_name']; ?></td>
                                    <td><?php echo $userDepartment['permission']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>


            <div class="content" id="help-content">
                <h2>Help</h2>
                <p>Need help? Find it here.</p>
            </div>

        </div>
    </div>


    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-beta3/js/bootstrap.bundle.min.js"></script>

    <script src="../script.js"></script>


</body>

</html>