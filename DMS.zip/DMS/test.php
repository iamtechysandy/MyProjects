<?php

$db = "localhost";
$username = "root";
$password = "";
$dbname = "user_managment";

try {
    $goog = new PDO("mysql:host=$db;dbname=$dbname", $username, $password);
} catch (\Throwable $th) {
    //throw $th;
}
