<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include 'db.php'; // Include your database connection file here

function getUserById($userId)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->bindParam(':id', $userId);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getUserByUsername($username)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function createUserSession($user)
{
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    // You can add more user data to the session if needed
}

function changePassword($userId, $newPassword)
{
    global $conn;
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password = :password WHERE id = :id");
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':id', $userId);
    return $stmt->execute();
}

function getDepartmentsByUserId($userId)
{
    global $conn;
    $stmt = $conn->prepare("
        SELECT d.id, d.department_name, ud.permission
        FROM departments d
        INNER JOIN user_departments ud ON d.id = ud.department_id
        WHERE ud.user_id = :user_id
    ");
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getFolderContents($folderId, $page = 1, $limit = 10)
{
    global $conn;

    // Calculate the offset for pagination
    $offset = ($page - 1) * $limit;

    // Get subfolders
    $stmt = $conn->prepare("
        SELECT id, folder_name 
        FROM folders 
        WHERE parent_folder_id = :folder_id
    ");
    $stmt->bindParam(':folder_id', $folderId, PDO::PARAM_INT);
    $stmt->execute();
    $subfolders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get the total number of files for pagination
    $stmt = $conn->prepare("
        SELECT COUNT(*) AS total_files
        FROM files
        WHERE folder_id = :folder_id
    ");
    $stmt->bindParam(':folder_id', $folderId, PDO::PARAM_INT);
    $stmt->execute();
    $totalFiles = $stmt->fetch(PDO::FETCH_ASSOC)['total_files'];
    $totalPages = ceil($totalFiles / $limit);

    // Get files with pagination
    $stmt = $conn->prepare("
        SELECT f.id, f.original_file_name, f.file_path, f.uploaded_date, f.file_extension, f.uploaded_file_name, 
               u.username AS uploaded_by, f.validation, f.expiry_date
        FROM files f
        INNER JOIN users u ON f.uploaded_by = u.id
        WHERE f.folder_id = :folder_id
        ORDER BY f.uploaded_date DESC
        LIMIT :limit OFFSET :offset
    ");
    $stmt->bindParam(':folder_id', $folderId, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT, PDO::PARAM_INPUT_OUTPUT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $files = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['subfolders' => $subfolders, 'files' => $files, 'totalPages' => $totalPages];
}



function getFolderPath($folderId)
{
    global $conn;
    $path = [];
    while ($folderId !== null) {
        $stmt = $conn->prepare("SELECT id, folder_name, parent_folder_id FROM folders WHERE id = :folder_id");
        $stmt->bindParam(':folder_id', $folderId, PDO::PARAM_INT);
        $stmt->execute();
        $folder = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($folder) {
            array_unshift($path, $folder['folder_name']);
            $folderId = $folder['parent_folder_id'];
        } else {
            $folderId = null;
        }
    }
    return implode('/', $path);
}


function createFolder($parentFolderId, $folderName, $departmentId)
{
    global $conn;
    $stmt = $conn->prepare("INSERT INTO folders (parent_folder_id, folder_name, department_id) VALUES (:parent_folder_id, :folder_name, :department_id)");
    $stmt->bindValue(':parent_folder_id', $parentFolderId !== null ? $parentFolderId : null, PDO::PARAM_INT);
    $stmt->bindParam(':folder_name', $folderName, PDO::PARAM_STR);
    $stmt->bindParam(':department_id', $departmentId, PDO::PARAM_INT);
    return $stmt->execute();
}



function uploadFile($folderId, $originalFileName, $fileExtension, $hashedFileName, $filePath, $userId, $docNumber, $description, $expiryDate)
{
    global $conn;

    $sql = "INSERT INTO files (folder_id, original_file_name, file_extension, uploaded_file_name, file_path, uploaded_by, doc_number, description, expiry_date) 
            VALUES (:folder_id, :original_file_name, :file_extension, :uploaded_file_name, :file_path, :uploaded_by, :doc_number, :description, :expiry_date)";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':folder_id', $folderId);
    $stmt->bindParam(':original_file_name', $originalFileName);
    $stmt->bindParam(':file_extension', $fileExtension);
    $stmt->bindParam(':uploaded_file_name', $hashedFileName);
    $stmt->bindParam(':file_path', $filePath);
    $stmt->bindParam(':uploaded_by', $userId);
    $stmt->bindParam(':doc_number', $docNumber);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':expiry_date', $expiryDate);

    if (!$stmt->execute()) {
        $errorInfo = $stmt->errorInfo();
        echo "<script>
                alert('Failed to save file to database: " . htmlspecialchars($errorInfo[2]) . "');
                window.location.href = window.location.href;
              </script>";
        return false;
    }

    return true;
}




// functions.php

function checkAccess($userId, $folderId, $conn)
{
    $stmt = $conn->prepare("
        SELECT f.parent_folder_id, ud.permission
        FROM folders f
        LEFT JOIN user_departments ud ON f.department_id = ud.department_id AND ud.user_id = :user_id
        WHERE f.id = :folder_id
    ");
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->bindParam(':folder_id', $folderId, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        if ($result['permission'] == 'full') {
            return 'full';
        } elseif ($result['parent_folder_id']) {
            return checkAccess($userId, $result['parent_folder_id'], $conn);
        }
    }

    return null;
}
