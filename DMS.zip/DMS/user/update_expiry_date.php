<?php
include 'db.php'; // Include your database connection file here


// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Decode JSON data from request body
    $data = json_decode(file_get_contents("php://input"));

    // Extract fileId and expiryDate from decoded data
    $fileId = $data->fileId;
    $expiryDate = $data->expiryDate;

    // Update expiry date in the database
    $success = updateExpiryDateInDatabase($fileId, $expiryDate);

    // Send JSON response
    echo json_encode(['success' => $success]);
}

// Function to update expiry date in the database
function updateExpiryDateInDatabase($fileId, $expiryDate)
{
    global $conn; // Assuming $conn is the database connection object

    // Prepare and execute SQL query to update expiry date
    $stmt = $conn->prepare("UPDATE files SET expiry_date = :expiryDate WHERE id = :fileId");
    $stmt->bindParam(':expiryDate', $expiryDate, PDO::PARAM_STR);
    $stmt->bindParam(':fileId', $fileId, PDO::PARAM_INT);
    return $stmt->execute();
}
