CREATE TABLE folders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    parent_id INT DEFAULT NULL,
    user_id INT,
    department_id INT,
    folder_name VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES folders(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (department_id) REFERENCES departments(id)
);

CREATE TABLE files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    folder_id INT,
    user_id INT,
    file_name VARCHAR(255),
    file_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (folder_id) REFERENCES folders(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);


<script>
        $(document).ready(function() {
            $('.folder-link').click(function(event) {
                event.preventDefault();
                var departmentId = $(this).parent().data('department-id');
                var departmentContent = $(this).next('.department-content');
                var subfoldersContainer = departmentContent.find('.subfolders');
                var filesContainer = departmentContent.find('.files');

                $('.department-content').not(departmentContent).slideUp(); // Hide other departments' content
                departmentContent.slideToggle(); // Toggle clicked department content

                if (departmentContent.is(':visible')) {
                    // Fetch subfolders and files via AJAX
                    $.ajax({
                        url: 'fetch_subfolders_files.php',
                        method: 'POST',
                        data: {
                            department_id: departmentId
                        },
                        success: function(response) {
                            var data = JSON.parse(response);
                            subfoldersContainer.html('');
                            filesContainer.html('');

                            // Append subfolders
                            if (data.subfolders.length > 0) {
                                data.subfolders.forEach(function(subfolder) {
                                    subfoldersContainer.append('<div class="subfolder" data-folder-id="' + subfolder.id + '"><i class="bi bi-folder-fill"></i> ' + subfolder.folder_name + '</div>');
                                });
                            } else {
                                subfoldersContainer.append('<p>No subfolders found.</p>');
                            }

                            // Append files
                            if (data.files.length > 0) {
                                data.files.forEach(function(file) {
                                    filesContainer.append('<div class="file" data-file-id="' + file.id + '"><i class="bi bi-file-earmark-fill"></i> ' + file.file_name + '</div>');
                                });
                            } else {
                                filesContainer.append('<p>No files found.</p>');
                            }
                        }
                    });
                }
            });

            // Handle create folder button click
            $('.create-folder-btn').click(function() {
                var departmentId = $(this).closest('.department').data('department-id');
                var folderName = prompt("Enter folder name:");
                if (folderName) {
                    $.ajax({
                        url: 'create_folder.php',
                        method: 'POST',
                        data: {
                            department_id: departmentId,
                            folder_name: folderName
                        },
                        success: function(response) {
                            alert(response);
                        }
                    });
                }
            });

            // Handle file upload
            $('.upload-file-input').change(function() {
                var departmentId = $(this).closest('.department').data('department-id');
                var folderId = $(this).closest('.department-content').find('.subfolder').data('folder-id'); // Adjust this based on where you want to upload the file
                var formData = new FormData();
                formData.append('file', this.files[0]);
                formData.append('folder_id', folderId);

                $.ajax({
                    url: 'upload_file.php',
                    method: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        alert(response);
                    }
                });
            });
        });
    </script>