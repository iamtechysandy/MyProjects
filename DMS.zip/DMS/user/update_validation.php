<?php
include 'db.php'; // Include your database connection file here


// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Decode JSON data from request body
    $data = json_decode(file_get_contents("php://input"));

    // Extract fileId and validation from decoded data
    $fileId = $data->fileId;
    $validation = $data->validation;

    // Update validation in the database
    $success = updateValidationInDatabase($fileId, $validation);

    // Send JSON response
    echo json_encode(['success' => $success]);
}

// Function to update validation in the database
function updateValidationInDatabase($fileId, $validation)
{
    global $conn; // Assuming $conn is the database connection object

    // Prepare and execute SQL query to update validation
    $stmt = $conn->prepare("UPDATE files SET validation = :validation WHERE id = :fileId");
    $stmt->bindParam(':validation', $validation, PDO::PARAM_STR);
    $stmt->bindParam(':fileId', $fileId, PDO::PARAM_INT);
    return $stmt->execute();
}
