<?php
include 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $departmentId = $_POST['department_id'];

    $subfolders = getSubfoldersByDepartmentId($departmentId);
    $files = []; // If you want to fetch files at the department level, you can modify this

    echo json_encode([
        'subfolders' => $subfolders,
        'files' => $files
    ]);
}
