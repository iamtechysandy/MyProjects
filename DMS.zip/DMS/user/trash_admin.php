<?php
session_start();
include 'db.php';

// Check if the user is logged in as admin
if (!isset($_SESSION['admin_id'])) {
    // Redirect to admin login page
    header("Location: admin.php");
    exit;
}

// Fetch all files from file_trash table
$stmt = $conn->prepare("
    SELECT ft.id, ft.original_file_name, ft.file_extension, ft.uploaded_file_name, ft.file_path, f.folder_name, u1.username AS uploaded_by, ft.uploaded_by AS uploaded_by_id, ft.uploaded_date, u2.username AS deleted_by, ft.deleted_date, ft.folder_id
    FROM file_trash ft
    LEFT JOIN folders f ON ft.folder_id = f.id
    LEFT JOIN users u1 ON ft.uploaded_by = u1.id
    LEFT JOIN users u2 ON ft.deleted_by = u2.id
");
$stmt->execute();
$trashFiles = $stmt->fetchAll();

// Function to restore file
function restoreFile($fileId, $originalFileName, $fileExtension, $uploadedFileName, $filePath, $folderId, $uploadedBy, $uploadedDate, $conn)
{
    // Remove _trashed from file name
    $newFileName = str_replace('_trashed', '', $uploadedFileName);
    $newFilePath = str_replace('_trashed', '', $filePath);

    // Rename the file on the filesystem
    rename($filePath, $newFilePath);

    // Insert the file back into the files table
    $stmt = $conn->prepare("
        INSERT INTO files (folder_id, original_file_name, file_extension, uploaded_file_name, file_path, uploaded_by, uploaded_date)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$folderId, $originalFileName, $fileExtension, $newFileName, $newFilePath, $uploadedBy, $uploadedDate]);

    // Remove the file from the file_trash table
    $stmt = $conn->prepare("DELETE FROM file_trash WHERE id = ?");
    $stmt->execute([$fileId]);
}

// Check if restore button is clicked
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['restore'])) {
    $fileId = $_POST['file_id'];
    $originalFileName = $_POST['original_file_name'];
    $fileExtension = $_POST['file_extension'];
    $uploadedFileName = $_POST['uploaded_file_name'];
    $filePath = $_POST['file_path'];
    $folderId = $_POST['folder_id'];
    $uploadedBy = $_POST['uploaded_by_id'];
    $uploadedDate = $_POST['uploaded_date'];

    restoreFile($fileId, $originalFileName, $fileExtension, $uploadedFileName, $filePath, $folderId, $uploadedBy, $uploadedDate, $conn);

    // Set success message in session
    $_SESSION['success_message'] = "File restored successfully!";

    // Redirect to refresh the page after restoring the file
    header("Location: trash_admin.php");
    exit;
}


function getFolderPath($folderId, $conn)
{
    // Initialize an empty array to store folder names
    $folderNames = [];

    // Fetch the folder details for the given folder_id
    $stmt = $conn->prepare("SELECT folder_name, parent_folder_id FROM folders WHERE id = ?");
    $stmt->execute([$folderId]);
    $folder = $stmt->fetch();

    // Check if the folder exists
    if ($folder) {
        // Add the current folder name to the folder names array
        $folderNames[] = $folder['folder_name'];

        // Check if the folder has a parent folder
        while ($folder['parent_folder_id'] !== null) {
            // Fetch the details of the parent folder
            $stmt = $conn->prepare("SELECT folder_name, parent_folder_id FROM folders WHERE id = ?");
            $stmt->execute([$folder['parent_folder_id']]);
            $folder = $stmt->fetch();

            // Add the parent folder name to the folder names array
            if ($folder) {
                $folderNames[] = $folder['folder_name'];
            } else {
                // If the parent folder does not exist, exit the loop
                break;
            }
        }
    }

    // Reverse the folder names array to get the path in correct order (parent folder first)
    $folderNames = array_reverse($folderNames);

    // Join the folder names with slashes to form the full path
    $folderPath = implode('/', $folderNames);

    return $folderPath;
}



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trash - Admin</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: transparent;
        }
    </style>
</head>

<body>


    <div class="container mt-5">
        <h1 class="text-left">
            <a href="logoutad.php" class="logout-icon">

                <i class="bi bi-box-arrow-right"></i>
            </a>
        </h1>
        <?php if (isset($_SESSION['success_message'])) : ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['success_message'];
                unset($_SESSION['success_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Original Name</th>
                    <th>Folder Name</th>
                    <th>Uploaded By</th>
                    <th>Uploaded Date</th>
                    <th>Deleted By</th>
                    <th>Deleted Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($trashFiles as $file) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($file['original_file_name']); ?></td>
                        <td><?php echo htmlspecialchars(getFolderPath($file['folder_id'], $conn)); ?></td>
                        <td><?php echo htmlspecialchars($file['uploaded_by']); ?></td>
                        <td><?php echo htmlspecialchars($file['uploaded_date']); ?></td>
                        <td><?php echo htmlspecialchars($file['deleted_by']); ?></td>
                        <td><?php echo htmlspecialchars($file['deleted_date']); ?></td>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="file_id" value="<?php echo $file['id']; ?>">
                                <input type="hidden" name="original_file_name" value="<?php echo $file['original_file_name']; ?>">
                                <input type="hidden" name="file_extension" value="<?php echo $file['file_extension']; ?>">
                                <input type="hidden" name="uploaded_file_name" value="<?php echo $file['uploaded_file_name']; ?>">
                                <input type="hidden" name="file_path" value="<?php echo $file['file_path']; ?>">
                                <input type="hidden" name="folder_id" value="<?php echo $file['folder_id']; ?>">
                                <input type="hidden" name="uploaded_by_id" value="<?php echo $file['uploaded_by_id']; ?>">
                                <input type="hidden" name="uploaded_date" value="<?php echo $file['uploaded_date']; ?>">
                                <button type="submit" name="restore" class="btn btn-success">
                                    <i class="bi bi-arrow-clockwise"></i> Restore
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>