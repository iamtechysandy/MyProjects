function showContextMenu(event, folderId, folderName) {
    event.preventDefault();
    const contextMenu = document.getElementById('contextMenu');
    contextMenu.style.top = event.clientY + 'px';
    contextMenu.style.left = event.clientX + 'px';
    contextMenu.style.display = 'block';

    document.getElementById('editContextButton').onclick = function() {
        document.getElementById('editFolderId').value = folderId;
        document.getElementById('editFolderName').value = folderName;
        document.getElementById('editModal').style.display = 'block';
        contextMenu.style.display = 'none';
    };

    document.addEventListener('click', function() {
        contextMenu.style.display = 'none';
    }, {
        once: true
    });
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

document.getElementById('editFolderForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const folderId = document.getElementById('editFolderId').value;
    const folderName = document.getElementById('editFolderName').value;

    // Send the AJAX request to update the folder name
    fetch('update_folder_name.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                folder_id: folderId,
                folder_name: folderName
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Failed to update folder name.');
            }
        });
});