<?php
session_start();
include 'functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$loggedInUserId = $_SESSION['user_id'];
function searchFiles($searchTerm, $fileType, $startDate, $endDate, $loggedInUserId)
{
    global $conn;

    // Prepare the search query
    $query = "SELECT f.original_file_name, f.file_extension, f.uploaded_date, u.username AS uploaded_by, d.department_name, fo.folder_name 
              FROM files f 
              JOIN users u ON f.uploaded_by = u.id 
              JOIN folders fo ON f.folder_id = fo.id 
              JOIN departments d ON fo.department_id = d.id 
              WHERE (:searchTerm IS NULL OR f.original_file_name LIKE :searchTerm) 
              AND (:fileType IS NULL OR f.file_extension = :fileType) 
              AND (:startDate IS NULL OR f.uploaded_date >= :startDate) 
              AND (:endDate IS NULL OR f.uploaded_date <= :endDate)";

    // Additional conditions based on user permissions
    if ($loggedInUserId !== null) {
        $query .= " AND (fo.id IN (
                        SELECT folder_id 
                        FROM user_folders 
                        WHERE user_id = :loggedInUserId
                    ) 
                    OR f.uploaded_by = :loggedInUserId)";
    }

    // Prepare the query
    $stmt = $conn->prepare($query);

    // Bind parameters
    $stmt->bindValue(':searchTerm', '%' . $searchTerm . '%', PDO::PARAM_STR);
    $stmt->bindValue(':fileType', $fileType, PDO::PARAM_STR);
    $stmt->bindValue(':startDate', $startDate, PDO::PARAM_STR);
    $stmt->bindValue(':endDate', $endDate, PDO::PARAM_STR);

    // Bind additional parameter if user is logged in
    if ($loggedInUserId !== null) {
        $stmt->bindValue(':loggedInUserId', $loggedInUserId, PDO::PARAM_INT);
    }

    // Execute the query
    $stmt->execute();

    // Fetch and return the results
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$results = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get search term from the form
    $searchTerm = $_POST['search_term'];

    // Perform the search
    $results = searchFiles($searchTerm);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Files</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Add your custom CSS styles here */
    </style>
</head>

<body>
    <div class="container mt-5">
        <h1 class="mb-4">Search Files</h1>
        <form method="post" action="search.php">
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="search_term" placeholder="Enter search term..." required>
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </form>

        <?php if (!empty($results)) : ?>
            <h2 class="mt-4">Search Results</h2>
            <ul class="list-group">
                <?php foreach ($results as $result) : ?>
                    <li class="list-group-item">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <span><?php echo htmlspecialchars($result['original_file_name']); ?> (<?php echo htmlspecialchars($result['file_extension']); ?>)</span><br>
                                <small>Uploaded by: <?php echo htmlspecialchars($result['uploaded_by']); ?> on <?php echo htmlspecialchars($result['uploaded_date']); ?></small><br>
                            </div>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>