<?php
include 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $departmentId = $_POST['department_id'];
    $folderName = $_POST['folder_name'];

    if (createSubfolder($departmentId, $folderName)) {
        echo "Folder created successfully.";
    } else {
        echo "Failed to create folder.";
    }
}
