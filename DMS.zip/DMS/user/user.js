document.addEventListener("DOMContentLoaded", function() {
    const backButton = document.getElementById('backButton');

    // Function to save the current URL to session storage
    function saveCurrentUrl() {
        const currentUrl = window.location.href;
        sessionStorage.setItem('previousUrl', currentUrl);
    }

    // Function to load the previous URL from session storage and navigate to it
    function loadPreviousUrl() {
        const previousUrl = sessionStorage.getItem('previousUrl');
        if (previousUrl) {
            window.location.href = previousUrl;
        }
    }

    // Attach event listener to the back button
    backButton.addEventListener('click', function() {
        loadPreviousUrl();
    });

    // Call saveCurrentUrl function when navigating to a new URL
    // You need to call this function whenever a link is clicked
    document.querySelectorAll('a').forEach(function(link) {
        link.addEventListener('click', function() {
            saveCurrentUrl();
        });
    });
});

// Buttons for folder
document.addEventListener("DOMContentLoaded", function() {
    const showFormButton = document.getElementById('showFormButton');
    const hideFormButton = document.getElementById('hideFormButton');
    const createFolderContainer = document.getElementById('createFolderContainer');

    // Show the form and hide the showFormButton
    showFormButton.addEventListener('click', function() {
        const bsCollapse = new bootstrap.Collapse(createFolderContainer, {
            toggle: true
        });
        showFormButton.style.display = 'none';
    });

    // Hide the form and show the showFormButton
    hideFormButton.addEventListener('click', function() {
        const bsCollapse = new bootstrap.Collapse(createFolderContainer, {
            toggle: true
        });
        showFormButton.style.display = 'inline-block';
    });
});

$(document).ready(function() {
    $('.folder-link').click(function(event) {
        event.preventDefault();
        var departmentId = $(this).parent().data('department-id');
        var departmentContent = $(this).next('.department-content');
        var subfoldersContainer = departmentContent.find('.subfolders');
        var filesContainer = departmentContent.find('.files');

        $('.department-content').not(departmentContent).slideUp(); // Hide other departments' content
        departmentContent.slideToggle(); // Toggle clicked department content

        if (departmentContent.is(':visible')) {
            // Fetch subfolders and files via AJAX
            $.ajax({
                url: 'fetch_subfolders_files.php',
                method: 'POST',
                data: {
                    department_id: departmentId
                },
                success: function(response) {
                    var data = JSON.parse(response);
                    subfoldersContainer.html('');
                    filesContainer.html('');

                    // Append subfolders
                    if (data.subfolders.length > 0) {
                        data.subfolders.forEach(function(subfolder) {
                            subfoldersContainer.append('<div class="subfolder" data-folder-id="' + subfolder.id + '"><i class="bi bi-folder-fill"></i> ' + subfolder.folder_name + '</div>');
                        });
                    } else {
                        subfoldersContainer.append('<p>No subfolders found.</p>');
                    }

                    // Append files
                    if (data.files.length > 0) {
                        data.files.forEach(function(file) {
                            filesContainer.append('<div class="file" data-file-id="' + file.id + '"><i class="bi bi-file-earmark-fill"></i> ' + file.file_name + '</div>');
                        });
                    } else {
                        filesContainer.append('<p>No files found.</p>');
                    }
                }
            });
        }
    });

    // Handle create folder button click
    $('.create-folder-btn').click(function() {
        var departmentId = $(this).closest('.department').data('department-id');
        var folderName = prompt("Enter folder name:");
        if (folderName) {
            $.ajax({
                url: 'create_folder.php',
                method: 'POST',
                data: {
                    department_id: departmentId,
                    folder_name: folderName
                },
                success: function(response) {
                    alert(response);
                }
            });
        }
    });

    // Handle file upload
    $('.upload-file-input').change(function() {
        var departmentId = $(this).closest('.department').data('department-id');
        var folderId = $(this).closest('.department-content').find('.subfolder').data('folder-id'); // Adjust this based on where you want to upload the file
        var formData = new FormData();
        formData.append('file', this.files[0]);
        formData.append('folder_id', folderId);

        $.ajax({
            url: 'upload_file.php',
            method: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                alert(response);
            }
        });
    });
});
document.addEventListener("DOMContentLoaded", function() {
    // Check if there's a hash fragment in the URL
    var hash = window.location.hash;
    if (hash) {
        // Scroll to the element with the matching ID
        var element = document.querySelector(hash);
        if (element) {
            element.scrollIntoView({
                behavior: 'smooth'
            });
        }
    }
});


//upload drag and drop 




//Next prev

document.addEventListener('DOMContentLoaded', function() {
    const tableContainer = document.getElementById('table-container');
    const prevPageButton = document.getElementById('prevPage');
    const nextPageButton = document.getElementById('nextPage');

    function saveScrollPosition() {
        sessionStorage.setItem('scrollPosition', tableContainer.scrollTop);
    }

    function restoreScrollPosition() {
        const scrollPosition = sessionStorage.getItem('scrollPosition');
        if (scrollPosition !== null) {
            tableContainer.scrollTop = scrollPosition;
        }
    }

    prevPageButton.addEventListener('click', saveScrollPosition);
    nextPageButton.addEventListener('click', saveScrollPosition);

    restoreScrollPosition();
});


//Another Js


function togglePasswordVisibility(fieldId) {
    const field = document.getElementById(fieldId);
    const toggleIcon = document.getElementById(fieldId + '_toggle');
    if (field.type === 'password') {
        field.type = 'text';
        toggleIcon.classList.remove('bi-eye-slash');
        toggleIcon.classList.add('bi-eye');
    } else {
        field.type = 'password';
        toggleIcon.classList.remove('bi-eye');
        toggleIcon.classList.add('bi-eye-slash');
    }
}