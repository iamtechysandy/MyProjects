<?php
session_start();
include 'functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $folderId = $input['folder_id'];
    $folderName = $input['folder_name'];

    if (updateFolderName($folderId, $folderName)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update folder name.']);
    }
    exit;
}

function updateFolderName($folderId, $folderName)
{
    // Add your database connection logic here
    // Example:
    try {
        $pdo = new PDO('mysql:host=localhost;dbname=user_management', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $query = "UPDATE folders SET folder_name = :folder_name WHERE id = :folder_id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':folder_name', $folderName, PDO::PARAM_STR);
        $stmt->bindParam(':folder_id', $folderId, PDO::PARAM_INT);

        return $stmt->execute();
    } catch (PDOException $e) {
        error_log('Database error: ' . $e->getMessage());
        return false;
    }
}
