<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include 'db.php'; // Include your database connection file here

// Function to check if the user is an admin
function isAdmin($userId, $conn)
{
    $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    return $user && $user['role'] === 'admin';
}

// Function to get folder path
function getFolderPath($folderId, $conn)
{
    $stmt = $conn->prepare("SELECT folder_name, parent_folder_id FROM folders WHERE id = ?");
    $stmt->execute([$folderId]);
    $folder = $stmt->fetch();

    if (!$folder) {
        return '';
    }

    $folderPath = $folder['folder_name'];
    $parentFolderId = $folder['parent_folder_id'];

    while ($parentFolderId !== null) {
        $stmt = $conn->prepare("SELECT folder_name, parent_folder_id FROM folders WHERE id = ?");
        $stmt->execute([$parentFolderId]);
        $folder = $stmt->fetch();

        if (!$folder) {
            break;
        }

        $folderPath = $folder['folder_name'] . '/' . $folderPath;
        $parentFolderId = $folder['parent_folder_id'];
    }

    return $folderPath;
}

// Function to check if user has full permission
function userHasFullPermission($userId, $folderId, $conn)
{
    while ($folderId !== null) {
        $stmt = $conn->prepare("SELECT parent_folder_id, department_id FROM folders WHERE id = ?");
        $stmt->execute([$folderId]);
        $folder = $stmt->fetch();

        if ($folder) {
            $stmt = $conn->prepare("
                SELECT permission FROM user_departments
                WHERE user_id = ? AND department_id = ?
            ");
            $stmt->execute([$userId, $folder['department_id']]);
            $userDept = $stmt->fetch();

            if ($userDept && $userDept['permission'] === 'full') {
                return true;
            }

            $folderId = $folder['parent_folder_id'];
        } else {
            $folderId = null;
        }
    }

    return false;
}

// Function to restore file
function restoreFile($fileId, $originalFileName, $fileExtension, $uploadedFileName, $filePath, $folderId, $uploadedBy, $uploadedDate, $conn)
{
    // Remove _trashed from file name
    $newFileName = str_replace('_trashed', '', $uploadedFileName);
    $newFilePath = str_replace('_trashed', '', $filePath);

    // Rename the file on the filesystem
    rename($filePath, $newFilePath);

    // Insert the file back into the files table
    $stmt = $conn->prepare("
        INSERT INTO files (folder_id, original_file_name, file_extension, uploaded_file_name, file_path, uploaded_by, uploaded_date)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$folderId, $originalFileName, $fileExtension, $newFileName, $newFilePath, $uploadedBy, $uploadedDate]);

    // Remove the file from the file_trash table
    $stmt = $conn->prepare("DELETE FROM file_trash WHERE id = ?");
    $stmt->execute([$fileId]);
}

$loggedInUserId = $_SESSION['user_id'];
$isAdmin = isAdmin($loggedInUserId, $conn);

// Fetch trash files with full folder path and user details
$query = "
    SELECT ft.id, ft.original_file_name, ft.file_extension, ft.uploaded_file_name, ft.file_path, f.folder_name, u1.username AS uploaded_by, ft.uploaded_by AS uploaded_by_id, ft.uploaded_date, u2.username AS deleted_by, ft.deleted_date, ft.folder_id
    FROM file_trash ft
    LEFT JOIN folders f ON ft.folder_id = f.id
    LEFT JOIN users u1 ON ft.uploaded_by = u1.id
    LEFT JOIN users u2 ON ft.deleted_by = u2.id
";

if (!$isAdmin) {
    $query .= " WHERE ft.folder_id IN (
        SELECT DISTINCT f.id
        FROM folders f
        JOIN user_departments ud ON f.department_id = ud.department_id
        WHERE ud.user_id = ? AND ud.permission = 'full'
    )";
    $stmt = $conn->prepare($query);
    $stmt->execute([$loggedInUserId]);
} else {
    $stmt = $conn->prepare($query);
    $stmt->execute();
}

$trashFiles = $stmt->fetchAll();

// Check if restore button is clicked
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['restore'])) {
    $fileId = $_POST['file_id'];
    $originalFileName = $_POST['original_file_name'];
    $fileExtension = $_POST['file_extension'];
    $uploadedFileName = $_POST['uploaded_file_name'];
    $filePath = $_POST['file_path'];
    $folderId = $_POST['folder_id'];
    $uploadedBy = $_POST['uploaded_by_id'];
    $uploadedDate = $_POST['uploaded_date'];

    if (!$isAdmin && !userHasFullPermission($loggedInUserId, $folderId, $conn)) {
        $_SESSION['error_message'] = "You do not have permission to restore this file.";
        header("Location: trash.php");
        exit;
    }

    restoreFile($fileId, $originalFileName, $fileExtension, $uploadedFileName, $filePath, $folderId, $uploadedBy, $uploadedDate, $conn);

    $_SESSION['success_message'] = "File restored successfully!";
    header("Location: trash.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DMS 2.0 - User</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-5">

        <?php if (isset($_SESSION['success_message'])) : ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['success_message'];
                unset($_SESSION['success_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])) : ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error_message'];
                unset($_SESSION['error_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Original Name</th>
                    <th>Folder Path</th>
                    <th>Uploaded By</th>
                    <th>Uploaded Date</th>
                    <th>Deleted By</th>
                    <th>Deleted Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($trashFiles as $file) : ?>
                    <?php $hasFullPermission = $isAdmin || userHasFullPermission($loggedInUserId, $file['folder_id'], $conn); ?>
                    <tr>
                        <td><?php echo htmlspecialchars($file['original_file_name']); ?></td>
                        <td><?php echo htmlspecialchars(getFolderPath($file['folder_id'], $conn)); ?></td>
                        <td><?php echo htmlspecialchars($file['uploaded_by']); ?></td>
                        <td><?php echo htmlspecialchars($file['uploaded_date']); ?></td>
                        <td><?php echo htmlspecialchars($file['deleted_by']); ?></td>
                        <td><?php echo htmlspecialchars($file['deleted_date']); ?></td>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="file_id" value="<?php echo $file['id']; ?>">
                                <input type="hidden" name="original_file_name" value="<?php echo $file['original_file_name']; ?>">
                                <input type="hidden" name="file_extension" value="<?php echo $file['file_extension']; ?>">
                                <input type="hidden" name="uploaded_file_name" value="<?php echo $file['uploaded_file_name']; ?>">
                                <input type="hidden" name="file_path" value="<?php echo $file['file_path']; ?>">
                                <input type="hidden" name="folder_id" value="<?php echo $file['folder_id']; ?>">
                                <input type="hidden" name="uploaded_by_id" value="<?php echo $file['uploaded_by_id']; ?>">
                                <input type="hidden" name="uploaded_date" value="<?php echo $file['uploaded_date']; ?>">
                                <button type="submit" name="restore" class="btn btn-success" <?php echo !$hasFullPermission ? 'disabled' : ''; ?>>
                                    <i class="bi bi-arrow-clockwise"></i> Restore
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../script.js"></script>
</body>

</html>