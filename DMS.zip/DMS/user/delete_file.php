<?php
session_start();
include 'functions.php'; // Your database configuration file

function generateTrashedFileName($originalFileName)
{
    return $originalFileName . '_trashed';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['file_id'])) {
    $fileId = $_POST['file_id'];
    $folderId = $_POST['folder_id'];
    $filePath = $_POST['file_path'];
    $uploadedFileName = $_POST['uploaded_file_name'];
    $userId = $_SESSION['user_id']; // Assume you have user sessions to get user ID

    try {
        // Fetch the file details from the database
        $stmt = $conn->prepare("SELECT * FROM files WHERE id = ?");
        $stmt->execute([$fileId]);
        $file = $stmt->fetch();

        if ($file) {
            // Move the file data to the file_trash table
            $stmt = $conn->prepare("INSERT INTO file_trash (folder_id, original_file_name, file_extension, uploaded_file_name, file_path, uploaded_by, uploaded_date, deleted_by, deleted_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$folderId, $file['original_file_name'], $file['file_extension'], $uploadedFileName, $file['file_path'], $file['uploaded_by'], $file['uploaded_date'], $userId]);

            // Rename the file
            $newFilePath = pathinfo($filePath, PATHINFO_DIRNAME) . '/' . generateTrashedFileName(pathinfo($filePath, PATHINFO_BASENAME));
            if (file_exists($filePath)) {
                if (rename($filePath, $newFilePath)) {
                    // Update the file path in the file_trash table
                    $stmt = $conn->prepare("UPDATE file_trash SET file_path = ? WHERE uploaded_file_name = ?");
                    $stmt->execute([$newFilePath, $uploadedFileName]);

                    // Delete the file record from the files table
                    $stmt = $conn->prepare("DELETE FROM files WHERE id = ?");
                    $stmt->execute([$fileId]);

                    header("Location: home.php?folder_id=" . $folderId);
                    exit();
                } else {
                    throw new Exception("Failed to rename the file.");
                }
            } else {
                throw new Exception("File not found: $filePath");
            }
        } else {
            throw new Exception("File not found in the database.");
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}
