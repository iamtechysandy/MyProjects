<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];

// Fetch the user's departments
$userDepartmentsStmt = $conn->prepare("SELECT department_id FROM user_departments WHERE user_id = ?");
$userDepartmentsStmt->execute([$userId]);
$userDepartments = $userDepartmentsStmt->fetchAll(PDO::FETCH_COLUMN);

// Ensure the user has access to departments
if (empty($userDepartments)) {
    $error = 'No access to any department.';
} else {
    // Fetch all folder IDs related to user's departments, including subfolders
    $placeholders = implode(',', array_fill(0, count($userDepartments), '?'));
    $foldersStmt = $conn->prepare("
        WITH RECURSIVE folder_tree AS (
            SELECT id, parent_folder_id
            FROM folders
            WHERE department_id IN ($placeholders)
            UNION ALL
            SELECT f.id, f.parent_folder_id
            FROM folders f
            INNER JOIN folder_tree ft ON ft.id = f.parent_folder_id
        )
        SELECT id FROM folder_tree
    ");
    $foldersStmt->execute($userDepartments);
    $folderIds = $foldersStmt->fetchAll(PDO::FETCH_COLUMN);

    // If no folders found, set an error message
    if (empty($folderIds)) {
        $error = 'No folders found for your departments.';
    } else {
        // Build the base query for files
        $query = "
            SELECT f.id, f.original_file_name, f.file_extension, f.uploaded_file_name, f.file_path, fd.folder_name, u.username AS uploaded_by, f.uploaded_date, f.validation, f.expiry_date
            FROM files f
            LEFT JOIN folders fd ON f.folder_id = fd.id
            LEFT JOIN users u ON f.uploaded_by = u.id
            WHERE f.folder_id IN (" . implode(',', array_fill(0, count($folderIds), '?')) . ")
        ";

        // Array to hold query parameters
        $params = $folderIds;

        // Check if search parameters are set and append to query
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            if (isset($_GET['search']) && !empty($_GET['search'])) {
                $search = '%' . $_GET['search'] . '%';
                $query .= " AND f.original_file_name LIKE ?";
                $params[] = $search;
            }

            if (isset($_GET['start_date']) && !empty($_GET['start_date']) && isset($_GET['end_date']) && !empty($_GET['end_date'])) {
                $start_date = $_GET['start_date'];
                $end_date = $_GET['end_date'];
                $query .= " AND f.uploaded_date BETWEEN ? AND ?";
                $params[] = $start_date;
                $params[] = $end_date;
            }

            if (isset($_GET['file_type']) && !empty($_GET['file_type'])) {
                $file_type = $_GET['file_type'];
                $query .= " AND f.file_extension = ?";
                $params[] = $file_type;
            }

            $stmt = $conn->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Search</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.2/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <div class="container mt-5">

        <form method="GET" action="">
            <div class="row mb-3">
                <label for="search" class="col-sm-2 col-form-label">
                    <i class="bi bi-search"></i> Search
                </label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="search" name="search" placeholder="Enter file name">
                </div>
                <label for="start_date" class="col-sm-2 col-form-label">
                    <i class="bi bi-calendar"></i> Start Date
                </label>
                <div class="col-sm-2">
                    <input type="date" class="form-control" id="start_date" name="start_date">
                </div>
                <label for="end_date" class="col-sm-1 col-form-label">
                    <i class="bi bi-calendar"></i> End Date
                </label>
                <div class="col-sm-1">
                    <input type="date" class="form-control" id="end_date" name="end_date">
                </div>
                <label for="file_type" class="col-sm-1 col-form-label">
                    <i class="bi bi-file-earmark"></i> File Type
                </label>
                <div class="col-sm-1">
                    <input type="text" class="form-control" id="file_type" name="file_type" placeholder="e.g., pdf, docx, xlsx">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-sm-10 offset-sm-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i> Search
                    </button>
                    <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#helpModal">
                        <i class="bi bi-question-circle"></i> Help
                    </button>
                </div>
            </div>
        </form>



        <div class="mt-3">
            <h3>Results</h3>
            <div class="files">

                <div id="table-container" class="table-container">
                    <table class="table table-hover table-responsive">
                        <thead>
                            <tr class="table-active">
                                <th>File Name</th>
                                <th>Uploaded by</th>
                                <th>Folder</th>
                                <th>Uploaded Date</th>

                                <th>Validation</th>
                                <th>Expiry Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (isset($results) && is_array($results) && !empty($results)) : ?>
                                <?php foreach ($results as $file) : ?>
                                    <tr>
                                        <td>
                                            <?php
                                            $fileExtension = strtolower($file['file_extension']);
                                            if ($fileExtension == 'zip' || $fileExtension == 'rar') {
                                                echo '<i class="bi bi-file-' . $fileExtension . '" style="font-size: 1.5rem;"></i> ' . htmlspecialchars($file['original_file_name']);
                                            } else {
                                                echo '<i class="bi bi-filetype-' . $fileExtension . '" style="font-size: 1.5rem;"></i> ' . htmlspecialchars($file['original_file_name']);
                                            }
                                            ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($file['uploaded_by']); ?></td>
                                        <td><?php echo htmlspecialchars($file['folder_name']); ?></td>
                                        <td><?php echo htmlspecialchars($file['uploaded_date']); ?></td>
                                        <td>
                                            <select class="form-select validation-select" name="validation" data-file-id="<?php echo $file['id']; ?>" <?php echo $file['validation'] ? 'disabled' : ''; ?> disabled>
                                                <option value="NA" <?php echo $file['validation'] === 'NA' ? 'selected' : ''; ?>>N/A</option>
                                                <option value="valid" <?php echo $file['validation'] === 'valid' ? 'selected' : ''; ?>>Valid</option>
                                                <option value="invalid" <?php echo $file['validation'] === 'invalid' ? 'selected' : ''; ?>>Invalid</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="date" class="form-control expiry-input" name="expiry" data-file-id="<?php echo $file['id']; ?>" <?php echo $file['validation'] ? 'disabled' : ''; ?> value="<?php echo $file['expiry_date']; ?>" disabled>
                                        </td>
                                        <td>
                                            <?php
                                            $viewLink = '';
                                            if ($fileExtension == 'pdf') {
                                                $viewLink = $file['file_path'];
                                            } elseif (in_array($fileExtension, ['doc', 'docx', 'xls', 'xlsx'])) {
                                                $viewLink = "https://view.officeapps.live.com/op/view.aspx?src=" . urlencode($file['file_path']);
                                            }
                                            ?>
                                            <?php if ($viewLink) : ?>
                                                <a href="<?php echo $viewLink; ?>" target="_blank" class="btn btn-primary" title="View">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                            <?php endif; ?>
                                            <a href="<?php echo $file['file_path']; ?>" download="<?php echo $file['original_file_name']; ?>" class="btn btn-success" title="Download">
                                                <i class="bi bi-download"></i>
                                            </a>
                                            <form method="post" action="delete_file.php" style="display:inline;">
                                                <input type="hidden" name="file_id" value="<?php echo $file['id']; ?>">
                                                <input type="hidden" name="file_path" value="<?php echo $file['file_path']; ?>">
                                                <input type="hidden" name="uploaded_file_name" value="<?php echo $file['uploaded_file_name']; ?>">
                                                <button type="submit" class="btn btn-danger" title="Delete" disabled>
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="6">No files found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="helpModal" tabindex="-1" aria-labelledby="helpModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="helpModalLabel">Search Help</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Use the following guidelines to search for files:</p>
                    <ul>
                        <li><strong>Filename:</strong> Enter part or all of the file name to search for specific files.</li>
                        <li><strong>Date Range:</strong> Select a start and end date to find files uploaded within that period.</li>
                        <li><strong>File Type:</strong> Select the type of file you are looking for, such as PDF, Excel, etc.</li>
                    </ul>
                    <li><mark>It will search Only for folder which you have access.</mark></li>
                    <p>If you leave the filename blank, the search will include all files within the specified date range and file type.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>