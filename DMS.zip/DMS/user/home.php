<?php
session_start();
include 'functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user = getUserById($_SESSION['user_id']);
$departments = getDepartmentsByUserId($_SESSION['user_id']);

// Check if a folder is being viewed
$folderId = isset($_GET['folder_id']) ? (int)$_GET['folder_id'] : null;
$folderContents = $folderId ? getFolderContents($folderId) : null;
$folderPath = $folderId ? getFolderPath($folderId) : null;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Validate current password
    if (!password_verify($currentPassword, $user['password'])) {
        $error = "Current password is incorrect.";
    } elseif ($newPassword !== $confirmPassword) {
        $error = "New password and confirm password do not match.";
    } else {
        // Update password
        changePassword($_SESSION['user_id'], $newPassword);
        $success = "Password updated successfully.";
    }
}

// Handle folder creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_folder'])) {
    $parentFolderId = $_POST['parent_folder_id'];
    $folderName = $_POST['folder_name'];
    $departmentId = isset($_GET['folder_id']) ? $_GET['folder_id'] : null; // Retrieve department ID from URL parameter
    createFolder($parentFolderId, $folderName, $departmentId);
    header("Location: home.php?folder_id=$parentFolderId");
    exit;
}

function generateHashedFileName($originalFileName)
{
    $timestamp = time();
    $randomString = uniqid();
    $hashedName = hash('sha256', $originalFileName . $timestamp . $randomString);
    return $hashedName;
}

$loggedInUserId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file_upload'])) {
    $folderId = $_POST['folder_id'];
    $uploadDir = 'uploads/';
    $files = $_FILES['file_upload'];

    for ($i = 0; $i < count($files['name']); $i++) {
        $originalFileName = $files['name'][$i];
        $fileExtension = pathinfo($files['name'][$i], PATHINFO_EXTENSION);
        $hashedFileName = generateHashedFileName($originalFileName);
        $fileTmpName = $files['tmp_name'][$i];

        $docNumber = $_POST["doc_number_$i"];
        $description = $_POST["description_$i"];
        $expiryDate = $_POST["expiry_date_$i"];

        if (move_uploaded_file($fileTmpName, $uploadDir . $hashedFileName)) {
            if (!uploadFile($folderId, $originalFileName, $fileExtension, $hashedFileName, $uploadDir . $hashedFileName, $loggedInUserId, $docNumber, $description, $expiryDate)) {
                echo "<script>
                        alert('Failed to save file to database.');
                        window.location.href = window.location.href;
                      </script>";
                exit;
            }
        } else {
            echo "<script>
                    alert('Failed to upload file: $originalFileName.');
                    window.location.href = window.location.href;
                  </script>";
            exit;
        }
    }

    echo "<script>
            document.getElementById('loader').style.display = 'none';
            alert('Files uploaded successfully.');
            window.location.href = window.location.href;
          </script>";
}


$page = isset($_GET['page']) ? intval($_GET['page']) : 1;

// Get the folder contents with pagination
$folderContents = getFolderContents($folderId, $page);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DMS 2.0 -User</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="user.css">
    <style>
        /* Loader CSS */
        #loader {
            display: none;
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            border: 16px solid #f3f3f3;
            border-radius: 50%;
            border-top: 16px solid blue;
            border-right: 16px solid green;
            border-bottom: 16px solid red;
            border-left: 16px solid pink;
            width: 120px;
            height: 120px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .folder-icons {
            transition: transform 0.2s;
        }

        .folder-icons:hover {
            transform: scale(1.05);
        }

        .folder-name {
            font-size: 0.9rem;
            font-weight: 500;
        }

        .folder {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            background-color: #f8f9fa;
            transition: background-color 0.2s, box-shadow 0.2s;
        }

        .folder:hover {
            background-color: #e9ecef;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>

</head>

<body>

    <div class="main-body">
        <div class="side-bar">
            <button class="collapse-btn" id="collapse-btn"><i class="bi bi-list"></i></button>
            <div class="side-bar-li active" id="home">
                <i class="bi bi-house-exclamation-fill"></i> <span>Home</span>
            </div>
            <div class="side-bar-li" id="profile">
                <i class="bi bi-person-fill"></i> <span><?php echo htmlspecialchars($user['username']); ?></span>
            </div>
            <div class="side-bar-li last-li" id="search">
                <i class="bi bi-search"></i> <span>Search</span>
            </div>
            <div class="side-bar-li last-li" id="trash">
                <i class="bi bi-trash"></i> <span>Trash</span>
            </div>
            <div class="side-bar-li last-li" id="help">
                <i class="bi bi-question-circle-fill"></i> <span>Help</span>
            </div>
            <div class="side-bar-li toggle-switch">
                <input type="checkbox" id="dark-mode-toggle">
                <label for="dark-mode-toggle">Dark Mode</label>
            </div>
            <div class="side-bar-li">
                <a href="logout.php"><i class="bi bi-box-arrow-right" style="font-size: 2rem;"></i></a>
            </div>
        </div>
        <div class="main-content">
            <div class="content active" id="home-content">
                <?php if ($folderId && $folderContents) : ?>
                    <h3><?php echo htmlspecialchars($folderPath); ?></h3>
                    <div class="breadcrumb">
                        <a href="home.php">Home</a> / <?php echo htmlspecialchars($folderPath); ?>
                    </div>
                    <div class="folders">
                        <button id="backButton" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-return-left"></i>
                        </button>

                        <div class="container">
                            <div class="row">
                                <?php foreach ($folderContents['subfolders'] as $index => $subfolder) : ?>
                                    <div class="col-3 col-md-4 col-lg-2 mb-3 folder" data-folder-id="<?php echo $subfolder['id']; ?>" oncontextmenu="showContextMenu(event, <?php echo $subfolder['id']; ?>, '<?php echo htmlspecialchars($subfolder['folder_name']); ?>')">
                                        <a href="home.php?folder_id=<?php echo $subfolder['id']; ?>" class="text-decoration-none folder-icons d-flex flex-column align-items-center text-center">
                                            <i class="bi bi-folder" style="font-size: 2rem;"></i>
                                            <div class="folder-name text-truncate w-100"><?php echo htmlspecialchars($subfolder['folder_name']); ?></div>
                                        </a>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php if ($departments[0]['permission'] !== 'full') : ?>
                        <div id="contextMenu" class="dropdown-menu">
                            <button id="editContextButton" class="dropdown-item btn-danger" disabled>
                                <i class="bi bi-pencil-square"></i> No Rights
                            </button>
                        </div>
                    <?php else : ?>
                        <div id="contextMenu" class="dropdown-menu">
                            <button id="editContextButton" class="dropdown-item">
                                <i class="bi bi-pencil-square"></i> Edit
                            </button>
                        </div>
                    <?php endif; ?>
                    <!-- Edit Modal -->
                    <div id="editModal" style="display:none;">
                        <div class="modal-content p-3">
                            <div class="modal-header">
                                <h2 class="modal-title">Edit Folder Name</h2>
                                <button type="button" class="btn-close" aria-label="Close" onclick="closeEditModal()"></button>
                            </div>
                            <div class="modal-body">
                                <form id="editFolderForm" method="POST" class="d-flex align-items-center justify-content-between">
                                    <input type="hidden" name="folder_id" id="editFolderId">
                                    <div class="flex-grow-1 me-2" style="flex-basis: 50%;">
                                        <input class="form-control" type="text" name="folder_name" id="editFolderName" required>
                                    </div>
                                    <div class="d-flex">
                                        <button type="submit" class="btn btn-primary me-2">
                                            <i class="bi bi-save"></i> Save
                                        </button>
                                        <button type="button" class="btn btn-secondary" onclick="closeEditModal()">
                                            <i class="bi bi-x-circle"></i> Cancel
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                    <?php if ($departments[0]['permission'] === 'full') : ?>
                        <!-- Show everything for users with full permission -->
                        <!-- Folder Creation Form -->
                        <div class="container mt-5">

                            <!-- Create Folder Button -->
                            <button id="showFormButton" class="btn btn-primary mb-3">
                                <i class="bi bi-folder-plus"></i> Create Folder
                            </button>

                            <!-- Form to Create Folder, initially collapsed -->
                            <div id="createFolderContainer" class="collapse">
                                <form id="createFolderForm" method="post" action="home.php?folder_id=<?php echo $folderId; ?>">
                                    <input type="hidden" name="parent_folder_id" value="<?php echo $folderId; ?>">

                                    <div class="mb-3">
                                        <label for="folder_name" class="form-label"><i class="bi bi-folder-plus"></i> New Folder Name</label>
                                        <input type="text" class="form-control" id="folder_name" name="folder_name" placeholder="New Folder Name" required>
                                    </div>

                                    <button type="submit" name="create_folder" class="btn btn-primary">
                                        <i class="bi bi-folder2"></i> Create Folder
                                    </button>
                                    <!-- Collapse Button -->
                                    <button type="button" id="hideFormButton" class="btn btn-secondary mt-2">
                                        <i class="bi bi-x-circle"></i> Cancel
                                    </button>
                                </form>
                            </div>


                        </div>
                        <div class="container mt-5">
                            <div id="loader" style="display: none;">Loading...</div>
                            <form id="uploadForm" method="post" action="home.php?folder_id=<?php echo $folderId; ?>" enctype="multipart/form-data">
                                <input type="hidden" name="form_type" value="upload_file">
                                <input type="hidden" name="folder_id" value="<?php echo $folderId; ?>">

                                <div class="mb-3">
                                    <label for="file_upload" class="form-label"><i class="bi bi-upload"></i> Select Files to Upload</label>
                                    <div class="drop-zone" id="dropZone">
                                        Drag and drop files here or click to select files <i class="bi bi-upload"></i>
                                    </div>
                                    <input type="file" class="form-control" id="file_upload" name="file_upload[]" multiple hidden>
                                    <div class="file-names" id="fileNames"></div>
                                </div>

                                <div id="metadataFields"></div>

                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-file-earmark-arrow-up"></i> Upload Files
                                </button>
                            </form>
                        </div>

                        <script>
                            document.getElementById('file_upload').addEventListener('change', function(event) {
                                const files = event.target.files;
                                const metadataFields = document.getElementById('metadataFields');
                                metadataFields.innerHTML = '';

                                for (let i = 0; i < files.length; i++) {
                                    const file = files[i];
                                    const fieldSet = document.createElement('fieldset');
                                    fieldSet.innerHTML = `
                <legend>Metadata for ${file.name}</legend>
                <div class="mb-3">
                    <label for="doc_number_${i}" class="form-label">Document Number</label>
                    <input type="text" class="form-control" name="doc_number_${i}" id="doc_number_${i}" required>
                </div>
                <div class="mb-3">
                    <label for="description_${i}" class="form-label">Description</label>
                    <textarea class="form-control" name="description_${i}" id="description_${i}" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="expiry_date_${i}" class="form-label">Date of Expiry</label>
                    <input type="date" class="form-control" name="expiry_date_${i}" id="expiry_date_${i}" required>
                </div>
            `;
                                    metadataFields.appendChild(fieldSet);
                                }
                            });

                            document.getElementById('uploadForm').addEventListener('submit', function() {
                                document.getElementById('loader').style.display = 'block';
                            });
                        </script>


                    <?php elseif ($departments[0]['permission'] === 'read/write') : ?>
                        <!-- Show only file upload form for users with read/write permission -->
                        <!-- File Upload Form -->
                        <div class="container mt-5 cbg-my">
                            <form method="post" action="home.php?folder_id=<?php echo $folderId; ?>" enctype="multipart/form-data">
                                <input name="folder_id" value="<?php echo $folderId; ?>" placeholder="<?php echo $folderId; ?>">

                                <div class="mb-3">
                                    <label for="file_upload" class="form-label"><i class="bi bi-upload"></i> Select File to Upload</label>
                                    <input type="file" class="form-control" id="file_upload" name="file_upload" required>
                                </div>

                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-file-earmark-arrow-up"></i> Upload File
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>

                <?php else : ?>
                    <h3>Your Departments</h3>
                    <div class="departments">
                        <?php foreach ($departments as $department) : ?>
                            <div class="department" data-department-id="<?php echo $department['id']; ?>">
                                <a href="home.php?folder_id=<?php echo $department['id']; ?>">
                                    <i class="bi bi-folder2" style="font-size: 5rem;"></i><br> <?php echo htmlspecialchars($department['department_name']); ?>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <!-- Context Menu -->






                <div class="files">
                    <div id="table-container" class="table-container">
                        <table class="table table-hover table-responsive">
                            <thead>
                                <tr class="table-active">
                                    <th>File Name</th>
                                    <th>Uploaded by</th>
                                    <th>Uploaded Date</th>
                                    <th>Validation</th>
                                    <th>Expiry Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (isset($folderContents['files']) && is_array($folderContents['files'])) : ?>
                                    <?php foreach ($folderContents['files'] as $file) : ?>
                                        <tr>
                                            <td>
                                                <?php
                                                $fileExtension = strtolower($file['file_extension']);
                                                if ($fileExtension == 'zip' || $fileExtension == 'rar') {
                                                    echo '<i class="bi bi-file-' . $fileExtension . '" style="font-size: 1.5rem;"></i> ' . htmlspecialchars($file['original_file_name']);
                                                } else {
                                                    echo '<i class="bi bi-filetype-' . $fileExtension . '" style="font-size: 1.5rem;"></i> ' . htmlspecialchars($file['original_file_name']);
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php echo htmlspecialchars($file['uploaded_by']); ?>
                                            </td>
                                            <td>
                                                <?php echo htmlspecialchars($file['uploaded_date']); ?>
                                            </td>
                                            <?php if ($departments[0]['permission'] !== 'full') : ?>
                                                <td><?php echo $file['validation']; ?></td>
                                                <td><?php echo $file['expiry_date']; ?></td>
                                            <?php else : ?>
                                                <td>
                                                    <select class="form-select validation-select" name="validation" data-file-id="<?php echo $file['id']; ?>" <?php echo $file['validation'] ? 'disabled' : ''; ?>>
                                                        <option value="NA" <?php echo $file['validation'] === 'NA' ? 'selected' : ''; ?>>N/A</option>
                                                        <option value="valid" <?php echo $file['validation'] === 'valid' ? 'selected' : ''; ?>>Valid</option>
                                                        <option value="invalid" <?php echo $file['validation'] === 'invalid' ? 'selected' : ''; ?>>Invalid</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="date" class="form-control expiry-input" name="expiry" data-file-id="<?php echo $file['id']; ?>" <?php echo $file['validation'] ? 'disabled' : ''; ?> value="<?php echo $file['expiry_date']; ?>">
                                                </td>
                                            <?php endif; ?>
                                            <td>
                                                <?php
                                                $viewLink = '';
                                                if ($fileExtension == 'pdf') {
                                                    $viewLink = $file['file_path'];
                                                } elseif (in_array($fileExtension, ['doc', 'docx', 'xls', 'xlsx'])) {
                                                    $viewLink = "https://view.officeapps.live.com/op/view.aspx?src=" . urlencode($file['file_path']);
                                                }
                                                ?>
                                                <?php if ($viewLink) : ?>
                                                    <a href="<?php echo $viewLink; ?>" target="_blank" class="btn btn-primary" title="View">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <a href="<?php echo $file['file_path']; ?>" download="<?php echo $file['original_file_name']; ?>" class="btn btn-success" title="Download">
                                                    <i class="bi bi-download"></i>
                                                </a>
                                                <?php if ($departments[0]['permission'] === 'full') : ?>
                                                    <form method="post" action="delete_file.php" style="display:inline;">
                                                        <input type="hidden" name="file_id" value="<?php echo $file['id']; ?>">
                                                        <input type="hidden" name="folder_id" value="<?php echo $folderId; ?>">
                                                        <input type="hidden" name="file_path" value="<?php echo $file['file_path']; ?>">
                                                        <input type="hidden" name="uploaded_file_name" value="<?php echo $file['uploaded_file_name']; ?>">
                                                        <button type="submit" class="btn btn-danger"><i class="bi bi-trash"></i> </button>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="6">No files found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div id="pagination-container" class="pagination" style="text-align: center; display: flex; justify-content: center; align-items: center; gap: 10px; padding: 10px; background-color: #f9f9f9; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
                    <button id="prevPage" class="btn btn-secondary" style="padding: 5px 10px; <?php if ($page <= 1) echo 'opacity: 0.5; cursor: not-allowed;' ?>" <?php if ($page <= 1) echo 'disabled'; ?>>Previous</button>
                    <span style="font-size: 16px; font-weight: bold;">Page <?php echo $page; ?> of <?php echo $folderContents['totalPages']; ?></span>
                    <button id="nextPage" class="btn btn-secondary" style="padding: 5px 10px; <?php if ($page >= $folderContents['totalPages']) echo 'opacity: 0.5; cursor: not-allowed;' ?>" <?php if ($page >= $folderContents['totalPages']) echo 'disabled'; ?>>Next</button>
                </div>


            </div>
            <div class="content" id="profile-content">
                <h2>Profile</h2>
                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($success)) : ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                <form method="post" action="">
                    <input type="hidden" name="form_type" value="change_password">
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Current Password</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="current_password" name="current_password" required style="border-color: #007bff;">
                            <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('current_password')">
                                <i class="bi bi-eye-slash" id="current_password_toggle"></i>
                            </button>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="new_password" name="new_password" required style="border-color: #007bff;">
                            <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('new_password')">
                                <i class="bi bi-eye-slash" id="new_password_toggle"></i>
                            </button>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm New Password</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required style="border-color: #007bff;">
                            <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('confirm_password')">
                                <i class="bi bi-eye-slash" id="confirm_password_toggle"></i>
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" name="change_password">Change Password</button>
                </form>
            </div>
            <div class="content" id="trash-content">
                <h1 class="text-center">Trash <i class="bi bi-trash"></i></h1>
                <iframe class="ifram-trash" src="trash.php" frameborder="0" style="height: 70vh;width: 100%;"></iframe>
            </div>
            <div class="content" id="search-content">
                <h1 class="text-center">Search <i class="bi bi-search"></i></h1>
                <iframe class="ifram-trash" src="search.php" frameborder="0" style="height: 70vh;width: 100%;"></iframe>
            </div>
            <div class="content" id="help-content">
                <div class="container">
                    <h1 class="text-center">Help - Document Management System</h1>
                    <hr>

                    <div class="feature-section">
                        <h3>Overview</h3>
                        <p>Welcome to our Document Management System. This guide will help you understand how to upload, validate, and manage your documents efficiently.</p>
                    </div>

                    <div class="feature-section">
                        <h3>Uploading Documents</h3>
                        <p>To upload a document, follow these steps:</p>
                        <ol>
                            <li>Navigate to the <strong>Upload</strong> section.</li>
                            <li>Click the <strong>Choose File</strong> button and select the document you want to upload.</li>
                            <li>Click the <strong>Upload</strong> button to upload your document to the system.</li>
                        </ol>
                        <img src="../img/upload.png" alt="Upload Example">
                    </div>

                    <div class="feature-section">
                        <h3>Validating Documents</h3>
                        <p>To validate a document:</p>
                        <ol>
                            <li>Navigate to the <strong>Files</strong> section where all uploaded documents are listed.</li>
                            <li>Locate the document you want to validate and select an option from the <strong>Validation</strong> dropdown (NA, Valid, Invalid).</li>
                            <li>If applicable, set an <strong>Expiry Date</strong> for the document.</li>
                            <li>Click the <strong>Edit</strong> button to make the fields editable, and save changes when done.</li>
                        </ol>
                        <img src="../img/valid.png" alt="Validation Example">
                    </div>

                    <div class="feature-section">
                        <h3>Viewing and Downloading Documents</h3>
                        <p>To view or download a document:</p>
                        <ol>
                            <li>Navigate to the <strong>Files</strong> section.</li>
                            <li>Find the document you want to view or download.</li>
                            <li>Click the <strong>View</strong> button (<i class="bi bi-eye"></i>) to view the document.</li>
                            <li>Click the <strong>Download</strong> button (<i class="bi bi-download"></i>) to download the document.</li>
                        </ol>
                        <img src="../img/view.png" alt="View and Download Example">
                    </div>

                    <div class="feature-section">
                        <h3>Deleting Documents</h3>
                        <p>To delete a document:</p>
                        <ol>
                            <li>Navigate to the <strong>Files</strong> section.</li>
                            <li>Locate the document you want to delete.</li>
                            <li>Click the <strong>Delete</strong> button (<i class="bi bi-trash"></i>).</li>
                            <li>Confirm the deletion when prompted.</li>
                        </ol>
                        <img src="../img/delete.png" alt="Delete Example">
                    </div>

                    <div class="feature-section">
                        <h3>Checking Document Expiry</h3>
                        <p>Our system automatically highlights documents based on their expiry status:</p>
                        <ul>
                            <li>Documents expiring in less than 15 days are highlighted in <span class="bg-warning p-1">yellow</span>.</li>
                            <li>Expired documents are highlighted in <span class="bg-danger p-1">red</span>.</li>
                        </ul>
                        <img src="../img/expire.png" alt="Expiry Status Example">
                    </div>
                    <div class="feature-section">
                        <h3>Trash and Recovery</h3>
                        <p>If you accidentally delete a document, you can recover it from the Trash:</p>
                        <ol>
                            <li>Navigate to the <strong>Trash</strong> section.</li>
                            <li>Find the document you want to recover.</li>
                            <li>Click the <strong>Recover</strong> button (<i class="bi bi-arrow-counterclockwise"></i>) next to the document.</li>
                            <li>The document will be restored to its original location.</li>
                        </ol>
                        <p>To permanently delete a document from the Trash:</p>
                        <ol>
                            <li>Navigate to the <strong>Trash</strong> section.</li>
                            <li>Find the document you want to permanently delete.</li>
                            <li>Click the <strong>Permanently Delete</strong> button (<i class="bi bi-x-circle"></i>) next to the document.</li>
                            <li>Confirm the deletion when prompted.</li>
                        </ol>
                        <img src="../img/trash.png" alt="Trash and Recovery Example">
                    </div>
                    <hr>
                    <p class="text-center">If you need further assistance, please contact our support team.</p>
                </div>




            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="ajax_cus.js"></script>
        <script>
            function showLoader() {
                document.getElementById('loader').style.display = 'block';
            }
        </script>
        <script src="../script.js"></script>
        <script src="user.js"></script>
</body>
<script>
    document.getElementById('prevPage').addEventListener('click', function() {
        const currentPage = <?php echo $page; ?>;
        if (currentPage > 1) {
            window.location.href = 'home.php?folder_id=<?php echo $folderId; ?>&page=' + (currentPage - 1);
        }
    });

    document.getElementById('nextPage').addEventListener('click', function() {
        const currentPage = <?php echo $page; ?>;
        const totalPages = <?php echo $folderContents['totalPages']; ?>;
        if (currentPage < totalPages) {
            window.location.href = 'home.php?folder_id=<?php echo $folderId; ?>&page=' + (currentPage + 1);
        }
    });

    document.addEventListener('DOMContentLoaded', function() {
        const validationSelects = document.querySelectorAll('.validation-select');
        const expiryInputs = document.querySelectorAll('.expiry-input');

        validationSelects.forEach(select => {
            select.addEventListener('change', function() {
                const fileId = this.dataset.fileId;
                const validation = this.value;

                updateValidationInDatabase(fileId, validation);
            });
        });

        expiryInputs.forEach(input => {
            input.addEventListener('change', function() {
                const fileId = this.dataset.fileId;
                const expiryDate = this.value;

                updateExpiryDateInDatabase(fileId, expiryDate);
            });
        });

        function updateValidationInDatabase(fileId, validation) {
            fetch('update_validation.php', {
                    method: 'POST',
                    body: JSON.stringify({
                        fileId,
                        validation
                    }),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log(data);
                })
                .catch(error => console.error('Error:', error));
        }

        function updateExpiryDateInDatabase(fileId, expiryDate) {
            fetch('update_expiry_date.php', {
                    method: 'POST',
                    body: JSON.stringify({
                        fileId,
                        expiryDate
                    }),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log(data);
                    location.reload(); // Reload the page after successful database operation
                })
                .catch(error => console.error('Error:', error));
        }

        // Update expiration status dynamically
        function updateExpirationStatus() {
            expiryInputs.forEach(input => {
                const fileId = input.dataset.fileId;
                const expiryDate = new Date(input.value);
                const currentDate = new Date();
                const daysRemaining = Math.ceil((expiryDate - currentDate) / (1000 * 60 * 60 * 24));

                if (daysRemaining < 0) {
                    input.classList.remove('bg-warning');
                    input.classList.add('bg-danger');
                } else if (daysRemaining <= 15) {
                    input.classList.add('bg-warning');
                } else {
                    input.classList.remove('bg-warning', 'bg-danger');
                }
            });
        }

        // Call the function initially
        updateExpirationStatus();

        // Set interval to update expiration status periodically
        setInterval(updateExpirationStatus, 60000); // Update every minute
    });
</script>


</html>