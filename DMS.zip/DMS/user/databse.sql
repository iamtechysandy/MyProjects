-- Create database if not exists
CREATE DATABASE IF NOT EXISTS `user_management` CHARACTER SET utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
USE `user_management`;

-- Create `departments` table
DROP TABLE IF EXISTS `departments`;
CREATE TABLE IF NOT EXISTS `departments` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Insert data into `departments`
INSERT INTO `departments` (`id`, `department_name`) VALUES
(1, 'Accounts'),
(2, 'HR'),
(3, 'IT');

-- Create `users` table
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) NOT NULL,
  `status` VARCHAR(10) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Insert data into `users`
INSERT INTO `users` (`id`, `username`, `password`, `role`, `status`) VALUES
(1, 'admin', '$2y$10$.HNsCwEhFMzFLXXgfsKDluB8UkepMYopUXcCEh/lhLxGyunnGV9O.', 'admin', 'active'),
(2, 'sandy', '$2y$10$JXhg7cb0Iu7xNoDniWOCVOYtnfHCzfhtnWvti4UVtPxo39jIV0faS', 'user', 'active'),
(3, 'sulfi', '$2y$10$TjW0sBxOeeSfV8T8iSehQu0HH/xEtx99L7SXUyi8rM87UCp8IyTKy', 'user', 'active');

-- Create `folders` table
DROP TABLE IF EXISTS `folders`;
CREATE TABLE IF NOT EXISTS `folders` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `department_id` INT NOT NULL,
  `parent_folder_id` INT DEFAULT NULL,
  `folder_name` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `department_id` (`department_id`),
  KEY `parent_folder_id` (`parent_folder_id`),
  CONSTRAINT `fk_folders_department` FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_folders_parent` FOREIGN KEY (`parent_folder_id`) REFERENCES `folders`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Insert data into `folders`
INSERT INTO `folders` (`id`, `department_id`, `parent_folder_id`, `folder_name`, `created_at`) VALUES
(1, 1, NULL, 'Finance', '2024-06-06 06:00:00'),
(2, 2, NULL, 'Recruitment', '2024-06-06 06:30:00'),
(3, 3, NULL, 'Development', '2024-06-06 07:00:00');

-- Create `files` table
DROP TABLE IF EXISTS `files`;
CREATE TABLE IF NOT EXISTS `files` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `folder_id` INT NOT NULL,
  `original_file_name` VARCHAR(255) NOT NULL,
  `file_extension` VARCHAR(10) NOT NULL,
  `uploaded_file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `uploaded_by` INT NOT NULL,
  `uploaded_date` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `folder_id` (`folder_id`),
  KEY `uploaded_by` (`uploaded_by`),
  CONSTRAINT `fk_files_folder` FOREIGN KEY (`folder_id`) REFERENCES `folders`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_files_user` FOREIGN KEY (`uploaded_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Insert data into `files`
INSERT INTO `files` (`id`, `folder_id`, `original_file_name`, `file_extension`, `uploaded_file_name`, `file_path`, `uploaded_by`, `uploaded_date`) VALUES
(1, 2, 'Daily_Attendance_Details (4).pdf', 'pdf', 'd364b07dfb752a4f72137d1854cf6640d352e7188adab5b4d28a48cb0a47a8a5', 'uploads/d364b07dfb752a4f72137d1854cf6640d352e7188adab5b4d28a48cb0a47a8a5', 2, '2024-06-06 06:26:56'),
(2, 2, 'date.xlsx', 'xlsx', 'ea60199a2b22d3d7e8050b0b99924cd4484b5a5e4843c53335a53f7894278490', 'uploads/ea60199a2b22d3d7e8050b0b99924cd4484b5a5e4843c53335a53f7894278490', 2, '2024-06-06 06:38:55');

-- Create `logs` table
DROP TABLE IF EXISTS `logs`;
CREATE TABLE IF NOT EXISTS `logs` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT DEFAULT NULL,
  `action` VARCHAR(255) NOT NULL,
  `timestamp` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `description` VARCHAR(255) DEFAULT NULL,
  `admin_id` INT NOT NULL,
  `department_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_logs_admin` FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_logs_department` FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Insert data into `logs`
INSERT INTO `logs` (`id`, `user_id`, `action`, `timestamp`, `description`, `admin_id`, `department_id`) VALUES
(92, 2, 'assign_department', '2024-06-06 06:26:24', 'Assigned department 2 with permission: read', 1, 2),
(91, 3, 'assign_department', '2024-06-06 06:26:19', 'Assigned department 2 with permission: full', 1, 2),
(90, 2, 'assign_department', '2024-06-06 06:26:14', 'Assigned department 1 with permission: full', 1, 1),
(88, NULL, 'create_department', '2024-06-06 06:26:04', 'Created department HR', 1, 2),
(89, NULL, 'create_department', '2024-06-06 06:26:07', 'Created department IT', 1, 3),
(87, NULL, 'create_department', '2024-06-06 06:25:58', 'Created department Accounts', 1, 1),
(86, 3, 'create', '2024-06-06 06:25:50', 'Created user sulfi with role user', 1, 0),
(85, 2, 'create', '2024-06-06 06:25:44', 'Created user sandy with role user', 1, 0);

-- Create `user_departments` table
DROP TABLE IF EXISTS `user_departments`;
CREATE TABLE IF NOT EXISTS `user_departments` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `department_id` INT NOT NULL,
  `permission` ENUM('read','read/write','modify','full') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `fk_user_departments_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_departments_department` FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Insert data into `user_departments`
INSERT INTO `user_departments` (`id`, `user_id`, `department_id`, `permission`) VALUES
(1, 2, 1, 'full'),
(2, 3, 2, 'full');
