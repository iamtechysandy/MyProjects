<?php
include 'functions.php';

$loggedInUserId = $_SESSION['user_id'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $folderId = $_POST['folder_id'];
    $fileName = $_FILES['file_upload']['name'];
    $fileTmpName = $_FILES['file_upload']['tmp_name'];
    $uploadDir = 'uploads/'; // Set your upload directory

    if (move_uploaded_file($fileTmpName, $uploadDir . $fileName)) {
        if (uploadFile($folderId, $fileName, $uploadDir . $fileName, $loggedInUserId)) {
            echo "File uploaded successfully.";
        } else {
            echo "Failed to save file to database.";
        }
    } else {
        echo "Failed to upload file.";
    }
}
