<?php
session_start();
include 'db.php'; // Include your database connection file here

$userId = $_SESSION['user_id'];

// Fetch the user's departments
$userDepartmentsStmt = $conn->prepare("SELECT department_id FROM user_departments WHERE user_id = ?");
$userDepartmentsStmt->execute([$userId]);
$userDepartments = $userDepartmentsStmt->fetchAll(PDO::FETCH_COLUMN);

// Ensure the user has access to departments
if (empty($userDepartments)) {
    $error = 'No access to any department.';
} else {
    // Fetch all folder IDs related to user's departments, including subfolders
    $placeholders = implode(',', array_fill(0, count($userDepartments), '?'));
    $foldersStmt = $conn->prepare("
        WITH RECURSIVE folder_tree AS (
            SELECT id, parent_folder_id
            FROM folders
            WHERE department_id IN ($placeholders)
            UNION ALL
            SELECT f.id, f.parent_folder_id
            FROM folders f
            INNER JOIN folder_tree ft ON ft.id = f.parent_folder_id
        )
        SELECT id FROM folder_tree
    ");
    $foldersStmt->execute($userDepartments);
    $folderIds = $foldersStmt->fetchAll(PDO::FETCH_COLUMN);

    // If no folders found, set an error message
    if (empty($folderIds)) {
        $error = 'No folders found for your departments.';
    } else {
        // Build the base query for files
        $query = "
            SELECT f.id, f.original_file_name, f.file_extension, f.uploaded_file_name, f.file_path, fd.folder_name, u.username AS uploaded_by, f.uploaded_date
            FROM files f
            LEFT JOIN folders fd ON f.folder_id = fd.id
            LEFT JOIN users u ON f.uploaded_by = u.id
            WHERE f.folder_id IN (" . implode(',', array_fill(0, count($folderIds), '?')) . ")
        ";

        // Array to hold query parameters
        $params = $folderIds;

        // Check if search parameters are set and append to query
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            if (isset($_GET['search']) && !empty($_GET['search'])) {
                $search = '%' . $_GET['search'] . '%';
                $query .= " AND f.original_file_name LIKE ?";
                $params[] = $search;
            }

            if (isset($_GET['start_date']) && !empty($_GET['start_date']) && isset($_GET['end_date']) && !empty($_GET['end_date'])) {
                $start_date = $_GET['start_date'];
                $end_date = $_GET['end_date'];
                $query .= " AND f.uploaded_date BETWEEN ? AND ?";
                $params[] = $start_date;
                $params[] = $end_date;
            }

            if (isset($_GET['file_type']) && !empty($_GET['file_type'])) {
                $file_type = $_GET['file_type'];
                $query .= " AND f.file_extension = ?";
                $params[] = $file_type;
            }

            $stmt = $conn->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Search</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h2>Search Documents</h2>
        <form method="GET" action="">
            <div class="mb-3">
                <label for="search" class="form-label">Search</label>
                <input type="text" class="form-control" id="search" name="search" placeholder="Enter file name">
            </div>
            <div class="mb-3">
                <label for="start_date" class="form-label">Start Date</label>
                <input type="date" class="form-control" id="start_date" name="start_date">
            </div>
            <div class="mb-3">
                <label for="end_date" class="form-label">End Date</label>
                <input type="date" class="form-control" id="end_date" name="end_date">
            </div>
            <div class="mb-3">
                <label for="file_type" class="form-label">File Type</label>
                <input type="text" class="form-control" id="file_type" name="file_type" placeholder="e.g., pdf, docx, xlsx">
            </div>
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
        <div class="mt-3">
            <h3>Results</h3>
            <ul class="list-group">
                <?php if (isset($error)) { ?>
                    <li class="list-group-item text-danger"><?php echo $error; ?></li>
                <?php } elseif (!empty($results)) { ?>
                    <?php foreach ($results as $result) { ?>
                        <li class="list-group-item">
                            <strong><?php echo htmlspecialchars($result['original_file_name']); ?></strong> (<?php echo htmlspecialchars($result['file_extension']); ?>)<br>
                            Uploaded by: <?php echo htmlspecialchars($result['uploaded_by']); ?> on <?php echo htmlspecialchars($result['uploaded_date']); ?><br>
                            Folder: <?php echo htmlspecialchars($result['folder_name']); ?>
                        </li>
                    <?php } ?>
                <?php } else { ?>
                    <li class="list-group-item">No results found.</li>
                <?php } ?>
            </ul>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>