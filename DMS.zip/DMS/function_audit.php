<?php
function logAudit($conn, $userId, $action, $description, $ipAddress)
{
    try {
        $stmt = $conn->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, timestamp) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bindParam(1, $userId);
        $stmt->bindParam(2, $action);
        $stmt->bindParam(3, $description);
        $stmt->bindParam(4, $ipAddress);
        if (!$stmt->execute()) {
            error_log('Audit log insertion failed: ' . $stmt->errorInfo()[2]);
        }
    } catch (PDOException $e) {
        error_log('Audit log insertion failed: ' . $e->getMessage());
    }
}
