<?php
require 'db.php';

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];
$docNumber = $data['docNumber'];
$expiryDate = $data['expiryDate'];
$docType = $data['docType'];
$validation = $data['validation'];
$validatedBy = $_SESSION['user_id'];

$sql = "UPDATE uploaded_content SET doc_number = :docNumber, Expirydate = :expiryDate, doc_type = :docType, validation = :validation, verifiedby = :validatedBy WHERE id = :id";
$stmt = $conn->prepare($sql);
$result = $stmt->execute(['docNumber' => $docNumber, 'expiryDate' => $expiryDate, 'docType' => $docType, 'validation' => $validation, 'validatedBy' => $validatedBy, 'id' => $id]);

echo json_encode(['success' => $result]);
