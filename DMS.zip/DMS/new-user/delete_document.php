<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require 'db.php';

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];
$loggedInUserId = $_SESSION['user_id'];

$sql = "UPDATE uploaded_content SET `delete` = 0, `deleted_by` = :deletedBy, `deleted_on` = NOW() WHERE id = :id";
$stmt = $conn->prepare($sql);
$result = $stmt->execute(['id' => $id, 'deletedBy' => $loggedInUserId]);

echo json_encode(['success' => $result]);
