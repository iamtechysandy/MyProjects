<?php
require 'db.php';

function getFolderDetails($folderId)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM master_folder WHERE id = :id AND is_master_folder = 1");
    $stmt->bindParam(':id', $folderId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getSubFolderDetails($subFolderId)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM sub_folders WHERE id = :id AND is_master_folder = 0");
    $stmt->bindParam(':id', $subFolderId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getFolderPermissionType($userId, $masterFolderId)
{
    global $conn;
    $stmt = $conn->prepare("SELECT Permission_type FROM folder_permissions WHERE AssignedTo = :userId AND Folderid = :folderId");
    $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
    $stmt->bindParam(':folderId', $masterFolderId, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['Permission_type'] : null;
}

function fetchFolderContents($folderId, $isSubFolder)
{
    global $conn;
    if ($isSubFolder) {
        $stmt = $conn->prepare("SELECT * FROM uploaded_content WHERE folderid = :folderId AND is_subfolder = 1 AND `delete` = 1");
        $stmt->bindParam(':folderId', $folderId, PDO::PARAM_INT);
    } else {
        $stmt = $conn->prepare("SELECT * FROM uploaded_content WHERE folderid = :folderId AND is_subfolder = 0 AND `delete` = 1");
        $stmt->bindParam(':folderId', $folderId, PDO::PARAM_INT);
    }
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function encryptFileName($fileName)
{
    return hash('sha256', $fileName . time());
}

function uploadFile($folderId, $originalFileName, $fileSize, $fileType, $encryptedFileName, $filePath, $isSubFolder, $docNumber, $docType, $remarks, $expiryDate, $uploadedBy)
{
    global $conn;
    $sql = "INSERT INTO uploaded_content (orginalfilename, filesize, filetype, filepath, folderid, is_subfolder, doc_number, doc_type, remarks, expirydate, uploadedby, uploadeddate) 
            VALUES (:orginalfilename, :filesize, :filetype, :filepath, :folderid, :is_subfolder, :doc_number, :doc_type, :remarks, :expirydate, :uploadedby, NOW())";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        'orginalfilename' => $originalFileName,
        'filesize' => $fileSize,
        'filetype' => $fileType,
        'filepath' => $filePath,
        'folderid' => $folderId,
        'is_subfolder' => $isSubFolder,
        'doc_number' => $docNumber,
        'doc_type' => $docType,
        'remarks' => $remarks,
        'expirydate' => $expiryDate,
        'uploadedby' => $uploadedBy
    ]);
}
