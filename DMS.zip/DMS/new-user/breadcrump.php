<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require 'db.php';

$folderId = isset($_GET['fid']) ? decryptParameter($_GET['fid']) : '';

if (!$folderId) {
    die('Invalid folder ID');
}

function buildBreadcrumb($conn, $folderId)
{
    $breadcrumb = [];

    while ($folderId) {
        // Check in sub_folders
        $sql = "SELECT id, sub_folder_name AS folder_name, master_folder_id AS parent_id FROM sub_folders WHERE id = :folderId";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['folderId' => $folderId]);
        $folder = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($folder) {
            $breadcrumb[] = $folder;
            $folderId = $folder['parent_id'];
        } else {
            // Check in master_folder
            $sql = "SELECT id, Foldername AS folder_name, NULL AS parent_id FROM master_folder WHERE id = :folderId";
            $stmt = $conn->prepare($sql);
            $stmt->execute(['folderId' => $folderId]);
            $folder = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($folder) {
                $breadcrumb[] = $folder;
                break; // Master folder found, end the loop
            } else {
                break; // Folder not found in both tables, end the loop
            }
        }
    }

    return array_reverse($breadcrumb);
}

$breadcrumb = buildBreadcrumb($conn, $folderId);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enhanced Breadcrumb</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <style>
        .breadcrumb-container {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .breadcrumb-item a {
            text-decoration: none;
            color: #007bff;
        }

        .breadcrumb-item a:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .breadcrumb-item+.breadcrumb-item::before {
            content: ">";
            color: #6c757d;
        }

        .breadcrumb-item.active {
            color: #6c757d;
        }

        .breadcrumb-icon {
            margin-right: 5px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <nav aria-label="breadcrumb" class="breadcrumb-container">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="folders.php">
                        <i class="bi bi-house-door breadcrumb-icon"></i>Home
                    </a>
                </li>
                <?php foreach ($breadcrumb as $index => $item) : ?>
                    <?php if ($index === count($breadcrumb) - 1) : ?>
                        <li class="breadcrumb-item active" aria-current="page">
                            <i class="bi bi-folder breadcrumb-icon"></i>
                            <?php echo htmlspecialchars($item['folder_name']); ?>
                        </li>
                    <?php else : ?>
                        <li class="breadcrumb-item">
                            <a href="folder_content.php?fid=<?php echo encryptParameter($item['id']); ?>">
                                <i class="bi bi-folder breadcrumb-icon"></i>
                                <?php echo htmlspecialchars($item['folder_name']); ?>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ol>
        </nav>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>