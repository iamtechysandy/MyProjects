<?php
session_start();
include 'db.php';
include 'functions.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $userId = $input['userId'];
    $permissions = $input['permissions'];
    $remarks = $input['remarks'];
    $assignedBy = $_SESSION['user_id']; // Assuming this is the logged-in user's ID

    try {
        $conn->beginTransaction();

        // Process each permission sent in the request
        foreach ($permissions as $permission) {
            $folderId = $permission['folderId'];
            $permissionType = $permission['permission'];

            // Check if permission already exists for this folder and user
            $sqlCheck = "SELECT id FROM folder_permissions WHERE Folderid = :folderId AND AssignedTo = :userId";
            $stmtCheck = $conn->prepare($sqlCheck);
            $stmtCheck->bindParam(':folderId', $folderId, PDO::PARAM_INT);
            $stmtCheck->bindParam(':userId', $userId, PDO::PARAM_INT);
            $stmtCheck->execute();
            $existingPermissionId = $stmtCheck->fetchColumn();

            if ($existingPermissionId) {
                // Update existing permission
                $sqlUpdate = "UPDATE folder_permissions 
                              SET Permission_type = :permissionType, Remarks = :remarks, Lastmodified = NOW()
                              WHERE id = :permissionId";
                $stmtUpdate = $conn->prepare($sqlUpdate);
                $stmtUpdate->bindParam(':permissionType', $permissionType);
                $stmtUpdate->bindParam(':remarks', $remarks);
                $stmtUpdate->bindParam(':permissionId', $existingPermissionId, PDO::PARAM_INT);
                $stmtUpdate->execute();
            } else {
                // Insert new permission
                $sqlInsert = "INSERT INTO folder_permissions (Folderid, Departmentname, Departmentid, Assignedby, AssignedTo, Remarks, Permission_type, Created_at, Lastmodified)
                              SELECT mf.id AS Folderid, mf.DepartmentName, mf.DepartmentId, :assignedBy, :userId, :remarks, :permissionType, NOW(), NOW()
                              FROM master_folder mf
                              WHERE mf.id = :folderId";
                $stmtInsert = $conn->prepare($sqlInsert);
                $stmtInsert->bindParam(':assignedBy', $assignedBy, PDO::PARAM_INT);
                $stmtInsert->bindParam(':userId', $userId, PDO::PARAM_INT);
                $stmtInsert->bindParam(':remarks', $remarks);
                $stmtInsert->bindParam(':permissionType', $permissionType);
                $stmtInsert->bindParam(':folderId', $folderId, PDO::PARAM_INT);
                $stmtInsert->execute();
            }
        }

        $conn->commit();
        $response['success'] = true;
        $response['message'] = 'Permissions saved successfully';
    } catch (PDOException $e) {
        $conn->rollBack();
        $response['message'] = 'Database error: ' . $e->getMessage();
    } catch (Exception $e) {
        $conn->rollBack();
        $response['message'] = 'Error: ' . $e->getMessage();
    }

    echo json_encode($response);
} else {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
}
