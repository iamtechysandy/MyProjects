<?php
session_start();
include 'db.php';
include 'functions.php';

header('Content-Type: application/json');

$response = ['folders' => [], 'permissions' => []];

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $userId = $_GET['userId'];

    // Fetch folders
    $sqlFolders = "SELECT id, Foldername FROM master_folder";
    $stmtFolders = $conn->prepare($sqlFolders);
    $stmtFolders->execute();
    $response['folders'] = $stmtFolders->fetchAll(PDO::FETCH_ASSOC);

    // Fetch existing permissions for the selected user
    $sqlPermissions = "SELECT Folderid, Permission_type FROM folder_permissions WHERE AssignedTo = :userId";
    $stmtPermissions = $conn->prepare($sqlPermissions);
    $stmtPermissions->bindParam(':userId', $userId, PDO::PARAM_INT);
    $stmtPermissions->execute();
    $response['permissions'] = $stmtPermissions->fetchAll(PDO::FETCH_ASSOC);
}

echo json_encode($response);
