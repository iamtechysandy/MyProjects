<?php
session_start();
include 'functions.php';

// Ensure the request is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $employeeId = $input['id'];
    $newPassword = $input['password'];

    if (resetEmployeePassword($employeeId, $newPassword)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
} else {
    header("HTTP/1.1 405 Method Not Allowed");
}
