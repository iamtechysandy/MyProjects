<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Files</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">

    <?php
    require 'session_check.php';
    require 'db.php';
    require 'folder_functions.php'; // Include the folder functions file

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    // Check if user is logged in
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['department_id'])) {
        header("Location: login.php");
        exit();
    }

    $loggedInUserId = $_SESSION['user_id'];
    $departmentId = $_SESSION['department_id'];
    $userAccessCode = getAccessCode($loggedInUserId);
    $userPermissions = translateAccessCode($userAccessCode);

    // Check if the user has HOD, Full-Department-control, or Admin-permission
    if (!in_array('HOD', $userPermissions) && !in_array('Full-Department-control', $userPermissions) && !in_array('Admin-permission', $userPermissions) && !in_array('Power-user', $userPermissions)) {
        die('
        <div class="container d-flex vh-100">
            <div class="row justify-content-center align-self-center w-100">
                <div class="col-md-6">
                    <div class="alert alert-danger text-center" role="alert">
                        <h4 class="alert-heading">Access Denied!</h4>
                        <p>It looks like you do not have sufficient permissions to perform a <strong>Global Search</strong>. Please contact your IT Administrator to obtain Global Search access.</p>
                        <hr>
                        <p class="mb-0">If you have folder-specific permissions, you can still perform searches within those folders. For more information, please refer to the FAQ.</p>
                    </div>
                </div>
            </div>
        </div>
        ');
    }



    // Handle search query
    $searchQuery = isset($_GET['search']) ? trim($_GET['search']) : '';
    $docNumber = isset($_GET['doc_number']) ? trim($_GET['doc_number']) : '';
    $docSeries = isset($_GET['doc_series']) ? trim($_GET['doc_series']) : '';
    $uploadedBy = isset($_GET['uploaded_by']) ? trim($_GET['uploaded_by']) : '';
    $uploadDateStart = isset($_GET['upload_date_start']) ? $_GET['upload_date_start'] : '';
    $uploadDateEnd = isset($_GET['upload_date_end']) ? $_GET['upload_date_end'] : '';

    function fetchFolderName($conn, $folderId)
    {
        $sql = "SELECT Foldername as name FROM master_folder WHERE id = :folderId AND deleted = 1";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['folderId' => $folderId]);
        $folder = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$folder) {
            $sql = "SELECT sub_folder_name as name FROM sub_folders WHERE id = :folderId AND deleted = 1";
            $stmt = $conn->prepare($sql);
            $stmt->execute(['folderId' => $folderId]);
            $folder = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        return $folder ? $folder['name'] : 'Unknown Folder';
    }

    function fetchSearchResults($conn, $departmentId, $searchQuery, $docNumber, $docSeries, $uploadedBy, $uploadDateStart, $uploadDateEnd)
    {
        $sql = "SELECT uc.*, e.fullname as uploaded_by_name
            FROM uploaded_content uc
            JOIN employees e ON uc.uploadedby = e.id
            WHERE uc.department_id = :departmentId 
              AND uc.`delete` = 1";

        $params = [
            'departmentId' => $departmentId
        ];

        if ($searchQuery) {
            $sql .= " AND LOWER(uc.orginalfilename) LIKE LOWER(:searchQuery)";
            $params['searchQuery'] = '%' . $searchQuery . '%';
        }
        if ($docNumber) {
            $sql .= " AND LOWER(uc.doc_number) LIKE LOWER(:docNumber)";
            $params['docNumber'] = '%' . $docNumber . '%';
        }
        if ($docSeries) {
            $sql .= " AND LOWER(uc.doc_series) LIKE LOWER(:docSeries)";
            $params['docSeries'] = '%' . $docSeries . '%';
        }
        if ($uploadedBy) {
            $sql .= " AND LOWER(e.fullname) LIKE LOWER(:uploadedBy)";
            $params['uploadedBy'] = '%' . $uploadedBy . '%';
        }
        if ($uploadDateStart && $uploadDateEnd) {
            $sql .= " AND uc.uploadeddate BETWEEN :uploadDateStart AND :uploadDateEnd";
            $params['uploadDateStart'] = $uploadDateStart;
            $params['uploadDateEnd'] = $uploadDateEnd;
        }

        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch folder names for each result
        foreach ($results as &$result) {
            $result['folder_name'] = fetchFolderName($conn, $result['folderid']);
        }

        return $results;
    }

    $results = [];
    if ($searchQuery || $docNumber || $docSeries || $uploadedBy || ($uploadDateStart && $uploadDateEnd)) {
        $results = fetchSearchResults($conn, $departmentId, $searchQuery, $docNumber, $docSeries, $uploadedBy, $uploadDateStart, $uploadDateEnd);
    }

    ?>


    <style>
        .search-form {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .results-table {
            margin-top: 20px;
        }

        .results-table th,
        .results-table td {
            text-align: center;
        }

        .clear-button {
            margin-left: 10px;
        }

        .folder-link {
            text-decoration: none;
            color: #007bff;
        }

        .folder-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h2>Search Files</h2>
        <form method="GET" action="search.php" class="search-form">
            <div class="row mb-3">
                <div class="col-md-6 mb-3">
                    <label for="search" class="form-label">Search</label>
                    <input type="text" class="form-control" id="search" name="search" value="<?php echo htmlspecialchars($searchQuery); ?>" placeholder="Original Filename">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="doc_number" class="form-label">Document Number</label>
                    <input type="text" class="form-control" id="doc_number" name="doc_number" value="<?php echo htmlspecialchars($docNumber); ?>" placeholder="Search by document number">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="doc_series" class="form-label">Document Series</label>
                    <input type="text" class="form-control" id="doc_series" name="doc_series" value="<?php echo htmlspecialchars($docSeries); ?>" placeholder="Search by document series">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="uploaded_by" class="form-label">Uploaded By</label>
                    <input type="text" class="form-control" id="uploaded_by" name="uploaded_by" value="<?php echo htmlspecialchars($uploadedBy); ?>" placeholder="Search by uploader">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6 mb-3">
                    <label for="upload_date_start" class="form-label">Uploaded Between</label>
                    <input type="date" class="form-control" id="upload_date_start" name="upload_date_start" value="<?php echo htmlspecialchars($uploadDateStart); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="upload_date_end" class="form-label">And</label>
                    <input type="date" class="form-control" id="upload_date_end" name="upload_date_end" value="<?php echo htmlspecialchars($uploadDateEnd); ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Search</button>
            <button type="button" class="btn btn-secondary clear-button" onclick="clearSearch()">Clear</button>
        </form>

        <?php if ($results) : ?>
            <h3 class="mt-5">Search Results</h3>
            <div class="table-responsive results-table">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Document Number</th>
                            <th>Original Filename</th>
                            <th>File Size</th>
                            <th>File Type</th>
                            <th>Document Type</th>
                            <th>Expiry Date</th>
                            <th>Uploaded Date</th>
                            <th>Uploaded By</th>
                            <th>Folder Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $result) : ?>
                            <tr>
                                <td><?php echo htmlspecialchars($result['doc_number']); ?></td>
                                <td><?php echo htmlspecialchars($result['orginalfilename']); ?></td>
                                <td><?php echo formatSizeUnits($result['filesize']); ?></td>
                                <td><?php echo htmlspecialchars($result['filetype']); ?></td>
                                <td><?php echo htmlspecialchars($result['doc_type']); ?></td>
                                <td><?php echo htmlspecialchars($result['Expirydate']); ?></td>
                                <td><?php echo htmlspecialchars($result['uploadeddate']); ?></td>
                                <td><?php echo htmlspecialchars($result['uploaded_by_name']); ?></td>
                                <td>
                                    <a href="folder_content.php?fid=<?php echo encryptParameter($result['folderid']); ?>" class="folder-link" title="Open Folder"><?php echo htmlspecialchars($result['folder_name']); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function clearSearch() {
            document.getElementById('search').value = '';
            document.getElementById('doc_number').value = '';
            document.getElementById('doc_series').value = '';
            document.getElementById('uploaded_by').value = '';
            document.getElementById('upload_date_start').value = '';
            document.getElementById('upload_date_end').value = '';
            document.querySelector('form').submit();
        }
    </script>
</body>

</html>