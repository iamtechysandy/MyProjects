<?php
session_start();
require 'db.php';

function generateHashedFileName($originalFileName)
{
    return hash('sha256', $originalFileName . time());
}

function decryptParameter($param)
{
    return base64_decode(urldecode($param));
}

function encryptParameter($param)
{
    return urlencode(base64_encode($param));
}

// Fetch department ID and upload limits of the logged-in user
function getUserUploadLimits($conn, $userId)
{
    $sql = "SELECT department_id, max_upload_size, max_file_uploads FROM employees WHERE id = :userId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Function to suppress warnings
function suppressWarnings()
{
    set_error_handler(function ($errno, $errstr, $errfile, $errline) {
        if (!(error_reporting() & $errno)) {
            return false;
        }
        if (stripos($errstr, 'Maximum number of allowable file uploads') !== false) {
            return true;
        }
        return false;
    });
}

suppressWarnings();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['files'])) {
    // Get user upload limits
    $loggedInUserId = $_SESSION['user_id'];
    $userLimits = getUserUploadLimits($conn, $loggedInUserId);
    $departmentId = $userLimits['department_id'];
    $maxUploadSize = $userLimits['max_upload_size'] * 1024 * 1024; // Convert MB to bytes
    $maxFileUploads = $userLimits['max_file_uploads'];

    // Validate file count and size before uploading
    $totalSize = 0;
    $totalFiles = count($_FILES['files']['name']);

    foreach ($_FILES['files']['size'] as $size) {
        $totalSize += $size;
    }

    if ($totalFiles > $maxFileUploads) {
        $errorMsg = "You don't have permission to upload $totalFiles files. Maximum allowed is $maxFileUploads files.";
    } elseif ($totalSize > $maxUploadSize) {
        $totalSizeMB = round($totalSize / (1024 * 1024), 2); // Convert bytes to MB
        $maxUploadSizeMB = round($maxUploadSize / (1024 * 1024), 2); // Convert bytes to MB
        $errorMsg = "Total size of files is $totalSizeMB MB. Maximum allowed is $maxUploadSizeMB MB.";
    } else {
        // Set the max_file_uploads directive
        ini_set('max_file_uploads', $maxFileUploads);

        $folderId = $_POST['folder_id'];
        $isSubfolder = $_POST['is_subfolder'];
        $docNumber = $_POST['doc_number'];
        $remarks = $_POST['remarks'];
        $expiryDate = $_POST['expiry_date'];
        $docType = $_POST['doc_type'];
        $docSeries = $_POST['doc_series'];
        $uploadedBy = $_SESSION['user_id'];

        $uploadDir = 'uploads/';
        preg_match('/(\D+)(\d+)/', $docNumber, $matches);
        $docPrefix = $matches[1];
        $docNumberBase = intval($matches[2]);

        foreach ($_FILES['files']['name'] as $index => $originalFileName) {
            $fileSize = $_FILES['files']['size'][$index];
            $fileType = pathinfo($originalFileName, PATHINFO_EXTENSION);
            $hashedFileName = generateHashedFileName($originalFileName);
            $filePath = $uploadDir . $hashedFileName;
            $docNumber = $docPrefix . ($docNumberBase + $index);

            if (move_uploaded_file($_FILES['files']['tmp_name'][$index], $filePath)) {
                $sql = "INSERT INTO uploaded_content 
                        (orginalfilename, filesize, filetype, filepath, folderid, is_subfolder, doc_number, doc_type, remarks, Expirydate, uploadedby, uploadeddate, `delete`, department_id) 
                        VALUES (:originalFileName, :fileSize, :fileType, :filePath, :folderId, :isSubfolder, :docNumber, :docType, :remarks, :expiryDate, :uploadedBy, NOW(), 1, :departmentId)";
                $stmt = $conn->prepare($sql);
                $stmt->execute([
                    'originalFileName' => $originalFileName,
                    'fileSize' => $fileSize,
                    'fileType' => $fileType,
                    'filePath' => $filePath,
                    'folderId' => $folderId,
                    'isSubfolder' => $isSubfolder,
                    'docNumber' => $docNumber,
                    'docType' => $docType,
                    'remarks' => $remarks,
                    'expiryDate' => $expiryDate,
                    'uploadedBy' => $uploadedBy,
                    'departmentId' => $departmentId
                ]);
            } else {
                $errorMsg = "Failed to upload file: " . $originalFileName;
                break;
            }
        }
        if (!isset($errorMsg)) {
            header('Location: folder_content.php?fid=' . encryptParameter($folderId) . '&success=bulk');
            exit;
        }
    }
}

restore_error_handler(); // Restore the default error handler after execution

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bulk Upload Documents</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h3>Bulk Upload Documents</h3>
        <?php if (isset($errorMsg)) : ?>
            <div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($errorMsg); ?></div>
        <?php endif; ?>

    </div>
</body>

</html>