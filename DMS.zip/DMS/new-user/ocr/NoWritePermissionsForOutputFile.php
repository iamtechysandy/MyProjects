<?php

namespace thiagoalessio\TesseractOCR;

class NoWritePermissionsForOutputFile extends TesseractOcrException
{
}
