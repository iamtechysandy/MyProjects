<?php
require '../session_check.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require 'db.php';

$departmentId = $_SESSION['department_id'];
$employeeId = $_SESSION['user_id'];

function fetchUploadedContents($conn, $departmentId)
{
    $sql = "SELECT * FROM uploaded_content WHERE department_id = :departmentId AND (`filetype` = 'pdf' OR `filetype` IN ('jpeg', 'jpg', 'png')) AND extracted_text IS NULL";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['departmentId' => $departmentId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function formatSizeUnits($bytes)
{
    if ($bytes >= 1048576) {
        $size = number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        $size = number_format($bytes / 1024, 2) . ' KB';
    } else {
        $size = $bytes . ' bytes';
    }

    return $size;
}

$uploadedContents = fetchUploadedContents($conn, $departmentId);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OCR Processing</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <style>
        .table-container {
            max-height: 400px;
            overflow-y: auto;
        }

        .blur {
            filter: blur(4px);
        }

        .loader-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            display: none;
        }

        .loader-icon {
            font-size: 50px;
            color: #007bff;
        }

        .loader-text {
            font-size: 20px;
            margin-top: 10px;
            color: #007bff;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h2>OCR Processing</h2>
        <form id="ocrForm" method="POST" action="run_ocr.php">
            <div class="table-responsive table-container">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th><input type="checkbox" id="selectAll"></th>
                            <th>File Name</th>
                            <th>File Type</th>
                            <th>File Size</th>
                            <th>Document Number</th>
                            <th>View</th>
                            <th>Download</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($uploadedContents as $content) : ?>
                            <tr data-id="<?php echo $content['id']; ?>">
                                <td><input type="checkbox" name="content_ids[]" value="<?php echo $content['id']; ?>"></td>
                                <td><?php echo htmlspecialchars($content['orginalfilename']); ?></td>
                                <td><?php echo htmlspecialchars($content['filetype']); ?></td>
                                <td><?php echo htmlspecialchars(formatSizeUnits($content['filesize'])); ?></td>
                                <td><?php echo htmlspecialchars($content['doc_number']); ?></td>
                                <td>
                                    <a href="../<?php echo htmlspecialchars($content['filepath']); ?>" class="btn btn-primary" title="View" target="_blank">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </td>
                                <td>
                                    <a href="../<?php echo htmlspecialchars($content['filepath']); ?>" download="<?php echo htmlspecialchars($content['orginalfilename']); ?>" class="btn btn-success" title="Download">
                                        <i class="bi bi-download"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Run OCR</button>
        </form>
        <div id="messages" class="mt-3"></div>
    </div>

    <div class="loader-overlay" id="loader">
        <i class="bi bi-arrow-repeat loader-icon"></i>
        <span class="loader-text">Running OCR, please wait...</span>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#selectAll').click(function() {
                $('input[name="content_ids[]"]').prop('checked', this.checked);
            });

            $('#ocrForm').submit(function(e) {
                e.preventDefault();

                var form = $(this);
                var formData = form.serialize();
                $('.table-container, h2, button').addClass('blur');
                $('#loader').show();

                $.ajax({
                    url: form.attr('action'),
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        $('#loader').hide();
                        $('.table-container, h2, button').removeClass('blur');
                        var data = JSON.parse(response);
                        $('#messages').html('<div class="alert alert-success">' + data.message + '</div>');

                        if (data.errors.length > 0) {
                            data.errors.forEach(function(error) {
                                $('#messages').append('<div class="alert alert-warning">' + error + '</div>');
                            });
                        }
                    }
                });
            });
        });
    </script>
</body>

</html>