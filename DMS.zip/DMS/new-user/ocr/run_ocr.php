<?php
session_start();
require 'db.php';
require 'TesseractOCR.php';
require 'Command.php';
require 'Option.php';
require 'FriendlyErrors.php';
require 'Process.php';
require 'TesseractOcrException.php';
require 'TesseractNotFoundException.php';
require 'UnsuccessfulCommandException.php';
require 'FeatureNotAvailableException.php';
require 'ImageNotFoundException.php';
require 'NoWritePermissionsForOutputFile.php';

use thiagoalessio\TesseractOCR\TesseractOCR;

$magickPath = '"C:\\Program Files\\ImageMagick-7.1.1-Q16-HDRI\\magick.exe"';
$tempDir = realpath(__DIR__ . '/../temp');

function convertPdfToImages($pdfPath, $tempDir, $magickPath)
{
    if (!file_exists($pdfPath)) {
        throw new Exception("PDF file not found: $pdfPath");
    }

    $imageBasePath = $tempDir . '/ocr_' . uniqid() . '_%d.png';
    $command = "$magickPath -density 300 \"$pdfPath\" \"$imageBasePath\"";
    error_log("Running command: $command");
    exec($command . " 2>&1", $output, $return_var);
    error_log("Command output: " . implode("\n", $output));
    if ($return_var !== 0) {
        throw new Exception('PDF to image conversion failed: ' . implode("\n", $output));
    }

    // Find all generated image files
    $images = glob(str_replace('%d', '*', $imageBasePath));
    if (!$images) {
        throw new Exception('No images generated from PDF');
    }

    return $images;
}

function runOcrOnImages($images)
{
    $text = '';

    foreach ($images as $imagePath) {
        try {
            $ocr = new TesseractOCR($imagePath);
            $ocr->lang('eng', 'ara');
            $text .= $ocr->run() . "\n";
            unlink($imagePath); // Clean up temporary image file
        } catch (Exception $e) {
            if (file_exists($imagePath)) {
                unlink($imagePath); // Clean up in case of partial failure
            }
            throw $e;
        }
    }

    return $text;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['content_ids'])) {
    $contentIds = $_POST['content_ids'];
    $errors = [];
    $successCount = 0;

    foreach ($contentIds as $id) {
        $stmt = $conn->prepare("SELECT * FROM uploaded_content WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $content = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($content) {
            $filePath = realpath(__DIR__ . '/../' . $content['filepath']);
            $fileExtension = strtolower(pathinfo($content['orginalfilename'], PATHINFO_EXTENSION));

            try {
                if ($fileExtension === 'pdf') {
                    $images = convertPdfToImages($filePath, $tempDir, $magickPath);
                    $extractedText = runOcrOnImages($images);
                } elseif (in_array($fileExtension, ['jpeg', 'jpg', 'png'])) {
                    $ocr = new TesseractOCR($filePath);
                    $ocr->lang('eng', 'ara');
                    $extractedText = $ocr->run();
                } else {
                    continue; // Skip files that are not PDFs or images
                }

                // Log the extracted text and image path for debugging
                error_log('Extracted Text: ' . $extractedText);

                $updateStmt = $conn->prepare("UPDATE uploaded_content SET extracted_text = :extractedText WHERE id = :id");
                $updateStmt->execute([
                    'extractedText' => $extractedText,
                    'id' => $id
                ]);

                $successCount++;
            } catch (Exception $e) {
                $errors[] = 'OCR extraction failed for file ' . $content['orginalfilename'] . ': ' . $e->getMessage();
            }
        }
    }

    $response = [
        'status' => 'success',
        'message' => "$successCount files processed successfully.",
        'errors' => $errors
    ];

    echo json_encode($response);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
