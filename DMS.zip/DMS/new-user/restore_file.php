<?php
session_start();
require 'db.php';

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];
    $userId = $_SESSION['user_id'];

    // Update the delete status to restore the file
    $sql = "UPDATE uploaded_content SET `delete` = 1, restored_by = :userId, restored_on = NOW() WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $userId, 'id' => $id]);

    // Redirect back to the folder_content.php page with a success message
    header('Location: ' . $_SERVER['HTTP_REFERER'] . '?success=File restored to its original location.');
    exit;
}
