<?php
// Assuming you have a function to get the logged-in user's ID
$loggedInUserId = getLoggedInUserId();

// Assuming you have a database connection established
// Replace with your database connection code

$sql = "SELECT Folderid, Foldername, Permission_type FROM folder_permissions WHERE Assignedto = :userId";
$stmt = $pdo->prepare($sql);
$stmt->execute(['userId' => $loggedInUserId]);
$folders = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($folders);
