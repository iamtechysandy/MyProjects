<?php
session_start();
require 'db.php';

function generateHashedFileName($originalFileName)
{
    return hash('sha256', $originalFileName . time());
}

function decryptParameter($param)
{
    return base64_decode(urldecode($param));
}

function encryptParameter($param)
{
    return urlencode(base64_encode($param));
}

// Fetch department ID of the logged-in user
function getDepartmentIdByUserId($conn, $userId)
{
    $sql = "SELECT department_id FROM employees WHERE id = :userId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $userId]);
    return $stmt->fetchColumn();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $folderId = $_POST['folder_id'];
    $isSubfolder = $_POST['is_subfolder'];
    $loggedInUserId = $_SESSION['user_id'];
    $departmentId = getDepartmentIdByUserId($conn, $loggedInUserId);
    $docNumber = $_POST['doc_number'];
    $remarks = $_POST['remarks'];
    $expiryDate = $_POST['expiry_date'];
    $docType = $_POST['doc_type'];
    $docSeries = $_POST['doc_series'];
    $uploadedBy = $_SESSION['user_id'];

    $originalFileName = $_FILES['file']['name'];
    $fileSize = $_FILES['file']['size'];
    $fileType = pathinfo($originalFileName, PATHINFO_EXTENSION);
    $hashedFileName = generateHashedFileName($originalFileName);

    $uploadDir = 'uploads/';
    $filePath = $uploadDir . $hashedFileName;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $filePath)) {
        $sql = "INSERT INTO uploaded_content 
                (orginalfilename, filesize, filetype, filepath, folderid, is_subfolder, doc_number, doc_type, remarks, Expirydate, uploadedby, uploadeddate, `delete`, department_id) 
                VALUES (:originalFileName, :fileSize, :fileType, :filePath, :folderId, :isSubfolder, :docNumber, :docType, :remarks, :expiryDate, :uploadedBy, NOW(), 1, :departmentId)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            'originalFileName' => $originalFileName,
            'fileSize' => $fileSize,
            'fileType' => $fileType,
            'filePath' => $filePath,
            'folderId' => $folderId,
            'isSubfolder' => $isSubfolder,
            'docNumber' => $docNumber,
            'docType' => $docType,
            'remarks' => $remarks,
            'expiryDate' => $expiryDate,
            'uploadedBy' => $uploadedBy,
            'departmentId' => $departmentId
        ]);

        header('Location: folder_content.php?fid=' . encryptParameter($folderId) . '&success=' . $docNumber);
        exit;
    } else {
        echo "Failed to upload file.";
    }
}
