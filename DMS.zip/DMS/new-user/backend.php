<?php
// Include the database connection file
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Query to fetch folders based on user permissions
$stmt = $conn->prepare("SELECT * FROM folder_permissions WHERE AssignedTo = :user_id AND Permission_type IN ('full_permission', 'read', 'read_write', 'view_only', 'no_access')");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$folder_per1 = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($folder_per1);
