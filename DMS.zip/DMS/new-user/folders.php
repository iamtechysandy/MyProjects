<?php
require 'session_check.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require 'db.php';

function decryptParameter($param)
{
    return base64_decode(urldecode($param));
}

function encryptParameter($param)
{
    return urlencode(base64_encode($param));
}

function fetchAccessibleFolders($conn, $userId)
{
    $sql = "SELECT fp.Folderid, mf.Foldername, fp.Permission_type 
            FROM folder_permissions fp
            JOIN master_folder mf ON fp.Folderid = mf.id
            WHERE fp.AssignedTo = :userId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $userId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$loggedInUserId = $_SESSION['user_id'];
$folders = fetchAccessibleFolders($conn, $loggedInUserId);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accessible Folders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../style.css">
    <style>
        .folder-item {
            display: inline-block;
            text-align: center;
            margin: 10px;
            width: 150px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .folder-icon {
            font-size: 48px;
            color: #007bff;
        }

        .no-access {
            opacity: 0.5;
            pointer-events: none;
        }
    </style>
</head>

<body>
    <div class="container mt-5">

        <div id="foldersListContainer">
            <?php foreach ($folders as $folder) : ?>
                <div class="folder-item <?php echo $folder['Permission_type'] === 'no_access' ? 'no-access' : 'clickable'; ?>" data-fid="<?php echo encryptParameter($folder['Folderid']); ?>">
                    <span class="folder-icon bi bi-folder"></span>
                    <div><?php echo htmlspecialchars($folder['Foldername']); ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.clickable').forEach(function(element) {
            element.addEventListener('click', function() {
                var folderId = this.getAttribute('data-fid');
                window.location.href = 'folder_content.php?fid=' + folderId;
            });
        });
    </script>
</body>

</html>