<?php
require 'db.php'; // Make sure to include your database connection file

/**
 * Decrypts a parameter using base64 decoding.
 *
 * @param string $param The parameter to decrypt.
 * @return string The decrypted parameter.
 */
function decryptParameter($param)
{
    return base64_decode(urldecode($param));
}

/**
 * Encrypts a parameter using base64 encoding.
 *
 * @param string $param The parameter to encrypt.
 * @return string The encrypted parameter.
 */
function encryptParameter($param)
{
    return urlencode(base64_encode($param));
}

/**
 * Fetches the details of a folder.
 *
 * @param PDO $conn The PDO connection object.
 * @param int $folderId The ID of the folder.
 * @return array The folder details.
 */
function fetchFolderDetails($conn, $folderId)
{
    $sql = "SELECT * FROM master_folder WHERE id = :folderId AND deleted = 1";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['folderId' => $folderId]);
    $folder = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$folder) {
        $sql = "SELECT * FROM sub_folders WHERE id = :folderId AND deleted = 1";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['folderId' => $folderId]);
        $folder = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    return $folder;
}

/**
 * Gets the master folder ID.
 *
 * @param PDO $conn The PDO connection object.
 * @param int $folderId The ID of the folder.
 * @param bool $isSubfolder Whether the folder is a subfolder.
 * @return int The master folder ID.
 */
function getMasterFolderId($conn, $folderId, $isSubfolder)
{
    if ($isSubfolder) {
        $sql = "SELECT master_folder_id FROM sub_folders WHERE id = :folderId";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['folderId' => $folderId]);
        $parentId = $stmt->fetchColumn();

        $sql = "SELECT COUNT(*) FROM master_folder WHERE id = :parentId";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['parentId' => $parentId]);
        if ($stmt->fetchColumn() > 0) {
            return $parentId;
        }

        return getMasterFolderId($conn, $parentId, true);
    }

    return $folderId;
}

/**
 * Fetches the subfolders of a folder.
 *
 * @param PDO $conn The PDO connection object.
 * @param int $folderId The ID of the folder.
 * @param bool $isSubfolder Whether the folder is a subfolder.
 * @return array The subfolder details.
 */
function fetchSubfolders($conn, $folderId, $isSubfolder)
{
    $sql = "SELECT * FROM sub_folders WHERE master_folder_id = :folderId AND deleted = 1";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['folderId' => $folderId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Fetches the uploaded contents of a folder.
 *
 * @param PDO $conn The PDO connection object.
 * @param int $folderId The ID of the folder.
 * @param string $searchQuery The search query for filtering results.
 * @param int $limit The number of results to fetch.
 * @param int $offset The offset for pagination.
 * @return array The uploaded contents.
 */
function fetchUploadedContents($conn, $folderId, $searchQuery = '', $limit = 10, $offset = 0)
{
    $sql = "SELECT * FROM uploaded_content WHERE folderid = :folderId AND `delete` = 1";
    $params = ['folderId' => $folderId];

    if ($searchQuery) {
        $sql .= " AND (doc_number LIKE :searchQuery OR orginalfilename LIKE :searchQuery OR doc_type LIKE :searchQuery)";
        $params['searchQuery'] = '%' . $searchQuery . '%';
    }

    $sql .= " LIMIT :limit OFFSET :offset";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':folderId', $folderId, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);

    if ($searchQuery) {
        $stmt->bindParam(':searchQuery', $params['searchQuery'], PDO::PARAM_STR);
    }

    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Counts the uploaded contents of a folder.
 *
 * @param PDO $conn The PDO connection object.
 * @param int $folderId The ID of the folder.
 * @param string $searchQuery The search query for filtering results.
 * @return int The count of uploaded contents.
 */
function countUploadedContents($conn, $folderId, $searchQuery = '')
{
    $sql = "SELECT COUNT(*) FROM uploaded_content WHERE folderid = :folderId AND `delete` = 1";
    $params = ['folderId' => $folderId];

    if ($searchQuery) {
        $sql .= " AND (doc_number LIKE :searchQuery OR orginalfilename LIKE :searchQuery OR doc_type LIKE :searchQuery)";
        $params['searchQuery'] = '%' . $searchQuery . '%';
    }

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn();
}

/**
 * Gets the user's upload limits.
 *
 * @param PDO $conn The PDO connection object.
 * @param int $userId The ID of the user.
 * @return array The user's upload limits.
 */
function getUserUploadLimits($conn, $userId)
{
    $sql = "SELECT department_id, max_upload_size, max_file_uploads FROM employees WHERE id = :userId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Gets the employee name by ID.
 *
 * @param PDO $conn The PDO connection object.
 * @param int $id The ID of the employee.
 * @return string The employee's name.
 */
function getEmployeeNameById($conn, $id)
{
    $sql = "SELECT fullname FROM employees WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $id]);
    return $stmt->fetchColumn();
}

/**
 * Gets the access code of a user.
 *
 * @param int $userId The ID of the user.
 * @return int|null The access code, or null if not found.
 */
function getAccessCode($userId)
{
    global $conn;

    try {
        $sql = "SELECT accesscode FROM employees WHERE id = :userId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return (int) $result['accesscode'];
        } else {
            return null; // User not found or access code not set
        }
    } catch (PDOException $e) {
        // Handle database error
        exit('Database error: ' . $e->getMessage());
    }
}

// Define permission codes
define('PERMISSION_HOD', 1);
define('PERMISSION_FULL_DEPT_CONTROL', 2);
define('PERMISSION_CREATE_FOLDERS', 4);
define('PERMISSION_FOLDERS_FULL', 8);
define('PERMISSION_READ_OPTION', 16);
define('PERMISSION_READ_DOWNLOAD', 32);
define('PERMISSION_UPLOAD_READ_DOWNLOAD', 64);
define('PERMISSION_ADMIN', 128);
define('PERMISSION_POWER_USER', 256);

/**
 * Function to calculate access code based on selected permissions.
 *
 * @param array $permissions An array of permission names.
 * @return int The calculated access code.
 */
function calculateAccessCode($permissions)
{
    // Map permission names to corresponding numeric values
    $mappedPermissions = [
        'HOD' => PERMISSION_HOD,
        'Full-Department-control' => PERMISSION_FULL_DEPT_CONTROL,
        'Create-Folders' => PERMISSION_CREATE_FOLDERS,
        'Folders-full-permission' => PERMISSION_FOLDERS_FULL,
        'Read-Option' => PERMISSION_READ_OPTION,
        'Read/Download' => PERMISSION_READ_DOWNLOAD,
        'Upload/Read/Download' => PERMISSION_UPLOAD_READ_DOWNLOAD,
        'Admin-permission' => PERMISSION_ADMIN,
        'Power-user' => PERMISSION_POWER_USER,
    ];

    $accessCode = 0;
    foreach ($permissions as $permission) {
        if (isset($mappedPermissions[$permission])) {
            $accessCode |= $mappedPermissions[$permission];
        } else {
            // Handle unrecognized permissions
        }
    }

    return $accessCode;
}

/**
 * Function to translate access code into an array of permission names.
 *
 * @param int $accessCode The access code to translate.
 * @return array An array of permission names.
 */
function translateAccessCode($accessCode)
{
    // Map numeric values to corresponding permission names
    $mappedPermissions = [
        PERMISSION_HOD => 'HOD',
        PERMISSION_FULL_DEPT_CONTROL => 'Full-Department-control',
        PERMISSION_CREATE_FOLDERS => 'Create-Folders',
        PERMISSION_FOLDERS_FULL => 'Folders-full-permission',
        PERMISSION_READ_OPTION => 'Read-Option',
        PERMISSION_READ_DOWNLOAD => 'Read/Download',
        PERMISSION_UPLOAD_READ_DOWNLOAD => 'Upload/Read/Download',
        PERMISSION_ADMIN => 'Admin-permission',
        PERMISSION_POWER_USER => 'Power-user',
    ];

    $permissions = [];
    foreach ($mappedPermissions as $value => $permission) {
        if ($accessCode & $value) {
            $permissions[] = $permission;
        }
    }

    return $permissions;
}

/**
 * Formats file size units (bytes) into KB, MB, or bytes.
 *
 * @param int $bytes The size in bytes.
 * @return string The formatted size.
 */
function formatSizeUnits($bytes)
{
    if ($bytes >= 1048576) {
        $size = number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        $size = number_format($bytes / 1024, 2) . ' KB';
    } else {
        $size = $bytes . ' bytes';
    }

    return $size;
}
