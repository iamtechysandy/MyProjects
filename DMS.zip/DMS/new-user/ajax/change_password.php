<?php
session_start();
require '../db.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    $loggedInUserId = $_SESSION['user_id'];

    // Validate current password
    $sql = "SELECT password FROM employees WHERE id = :userId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $loggedInUserId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($currentPassword, $user['password'])) {
        if ($newPassword === $confirmPassword) {
            $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            // Update the password
            $sql = "UPDATE employees SET password = :newPassword WHERE id = :userId";
            $stmt = $conn->prepare($sql);
            $stmt->execute(['newPassword' => $hashedNewPassword, 'userId' => $loggedInUserId]);

            $response['success'] = true;
            $response['message'] = 'Password updated successfully.';
        } else {
            $response['message'] = 'New password and confirm password do not match.';
        }
    } else {
        $response['message'] = 'Current password is incorrect.';
    }
} else {
    $response['message'] = 'Invalid request method.';
}

echo json_encode($response);
