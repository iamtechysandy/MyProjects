document.querySelectorAll(".clickable").forEach(function (element) {
  element.addEventListener("click", function () {
    var folderId = this.getAttribute("data-fid");
    window.location.href = "folder_content.php?fid=" + folderId;
  });
});

document.getElementById("backButton").addEventListener("click", function () {
  window.history.back();
});

// Tooltip initialization
var tooltipTriggerList = [].slice.call(
  document.querySelectorAll('[data-bs-toggle="tooltip"]')
);
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl);
});

let contextMenu = document.getElementById("contextMenu");
let renameModal = new bootstrap.Modal(document.getElementById("renameModal"));
let updateRemarksModal = new bootstrap.Modal(
  document.getElementById("updateRemarksModal")
);
let currentFolderId;
let isSubfolder;

document.querySelectorAll(".folder-item").forEach(function (element) {
  element.addEventListener("contextmenu", function (event) {
    event.preventDefault();
    currentFolderId = element.getAttribute("data-fid");
    isSubfolder = element.closest(".clickable") ? 1 : 0;
    contextMenu.style.display = "block";
    contextMenu.style.left = event.pageX + "px";
    contextMenu.style.top = event.pageY + "px";
  });
});

document.addEventListener("click", function () {
  contextMenu.style.display = "none";
});

document
  .getElementById("renameContextButton")
  .addEventListener("click", function () {
    document.getElementById("renameFolderId").value = currentFolderId;
    document.getElementById("isSubfolder").value = isSubfolder;
    renameModal.show();
  });

document
  .getElementById("updateRemarksContextButton")
  .addEventListener("click", function () {
    document.getElementById("remarksFolderId").value = currentFolderId;
    document.getElementById("remarksIsSubfolder").value = isSubfolder;
    updateRemarksModal.show();
  });

document
  .getElementById("deleteContextButton")
  .addEventListener("click", function () {
    if (confirm("Are you sure you want to delete this folder?")) {
      var form = document.createElement("form");
      form.method = "POST";
      form.style.display = "none";

      var folderIdInput = document.createElement("input");
      folderIdInput.name = "folderId";
      folderIdInput.value = currentFolderId;
      form.appendChild(folderIdInput);

      var actionInput = document.createElement("input");
      actionInput.name = "action";
      actionInput.value = "delete";
      form.appendChild(actionInput);

      var isSubfolderInput = document.createElement("input");
      isSubfolderInput.name = "isSubfolder";
      isSubfolderInput.value = isSubfolder;
      form.appendChild(isSubfolderInput);

      document.body.appendChild(form);
      form.submit();
    }
  });

document.querySelectorAll(".delete-button").forEach((button) => {
  button.addEventListener("click", function () {
    const id = this.getAttribute("data-id");
    fetch("delete_document.php", {
      method: "POST",
      body: JSON.stringify({
        id: id,
      }),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          location.reload();
        } else {
          alert("Failed to delete document");
        }
      })
      .catch((error) => console.error("Error:", error));
  });
});

document.querySelectorAll(".edit-button").forEach((button) => {
  button.addEventListener("click", function () {
    const row = this.closest("tr");
    const docNumberCell = row.querySelector(".doc-number");
    const docTypeCell = row.querySelector(".doc-type");
    const expiryDateCell = row.querySelector(".expiry-date");
    const validationCell = row.querySelector(".validation");

    if (this.textContent === "Edit") {
      const docNumber = docNumberCell.innerText;
      const docType = docTypeCell.innerText;
      const expiryDate = expiryDateCell.innerText;
      const validation = validationCell.innerText;

      docNumberCell.innerHTML = `<input type="text" class="form-control" value="${docNumber}">`;
      docTypeCell.innerHTML = `
        <select class="form-select">
            <option value="invoice" ${
              docType === "invoice" ? "selected" : ""
            }>Invoice</option>
            <option value="purchase_order" ${
              docType === "purchase_order" ? "selected" : ""
            }>Purchase Order</option>
            <option value="general_document" ${
              docType === "general_document" ? "selected" : ""
            }>General Document</option>
        </select>
    `;
      expiryDateCell.innerHTML = `<input type="date" class="form-control" value="${expiryDate}">`;
      validationCell.innerHTML = `
        <select class="form-select">
            <option value="Not Verified" ${
              validation === "Not Verified" ? "selected" : ""
            }>Not Verified</option>
            <option value="Valid" ${
              validation === "Valid" ? "selected" : ""
            }>Valid</option>
            <option value="Not Valid" ${
              validation === "Not Valid" ? "selected" : ""
            }>Not Valid</option>
        </select>
    `;

      this.textContent = "Save";
      this.classList.remove("btn-primary");
      this.classList.add("btn-success");
    } else if (this.textContent === "Save") {
      const id = row.getAttribute("data-id");
      const docNumber = docNumberCell.querySelector("input").value;
      const docType = docTypeCell.querySelector("select").value;
      const expiryDate = expiryDateCell.querySelector("input").value;
      const validation = validationCell.querySelector("select").value;

      fetch("update_document.php", {
        method: "POST",
        body: JSON.stringify({
          id: id,
          docNumber: docNumber,
          expiryDate: expiryDate,
          docType: docType,
          validation: validation,
        }),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            docNumberCell.innerHTML = docNumber;
            docTypeCell.innerHTML = docType;
            expiryDateCell.innerHTML = expiryDate;
            validationCell.innerHTML = validation;

            this.textContent = "Edit";
            this.classList.remove("btn-success");
            this.classList.add("btn-primary");
            window.location.reload();
          } else {
            alert("Failed to update document");
          }
        })
        .catch((error) => console.error("Error:", error));
    }
  });
});


document.getElementById('clearSearch').addEventListener('click', function() {
    document.getElementById('searchInput').value = '';
    window.location.href = 'folder_content.php?fid=<?php echo htmlspecialchars($_GET['fid']); ?>';
});

document.addEventListener('DOMContentLoaded', () => {
    const headers = document.querySelectorAll('th[data-sort]');
    headers.forEach(header => {
        header.addEventListener('click', () => {
            const tableBody = document.getElementById('tableBody');
            if (!tableBody) return;

            const rows = Array.from(tableBody.querySelectorAll('tr'));
            const sortKey = header.getAttribute('data-sort');
            const order = header.dataset.order = -(header.dataset.order || -1);

            rows.sort((a, b) => {
                const aElement = a.querySelector(`.${sortKey}`);
                const bElement = b.querySelector(`.${sortKey}`);
                if (!aElement || !bElement) return 0;

                const aText = aElement.textContent.trim();
                const bText = bElement.textContent.trim();
                return aText > bText ? order : aText < bText ? -order : 0;
            });

            while (tableBody.firstChild) tableBody.removeChild(tableBody.firstChild);
            rows.forEach((row, index) => {
                row.querySelector('.sr-no').textContent = index + 1;
                tableBody.appendChild(row);
            });
        });
    });
});