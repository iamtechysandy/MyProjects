<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$loggedInUserId = $_SESSION['user_id'];

function getDepartmentIdByUserId($conn, $userId)
{
    $sql = "SELECT department_id FROM employees WHERE id = :userId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $userId]);
    return $stmt->fetchColumn();
}

$departmentId = getDepartmentIdByUserId($conn, $loggedInUserId);

function fetchDeletedItems($conn, $departmentId)
{
    $sql = "SELECT * FROM master_folder WHERE DepartmentId = :departmentId AND deleted = 0";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['departmentId' => $departmentId]);
    $deletedMasterFolders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $sql = "SELECT * FROM sub_folders WHERE department_id = :departmentId AND deleted = 0";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['departmentId' => $departmentId]);
    $deletedSubFolders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $sql = "SELECT * FROM uploaded_content WHERE department_id = :departmentId AND `delete` = 0";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['departmentId' => $departmentId]);
    $deletedFiles = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return [
        'master_folders' => $deletedMasterFolders,
        'sub_folders' => $deletedSubFolders,
        'files' => $deletedFiles
    ];
}

$deletedItems = fetchDeletedItems($conn, $departmentId);

function restoreItem($conn, $id, $type, $userId)
{
    $now = date('Y-m-d H:i:s');
    switch ($type) {
        case 'master_folder':
            $sql = "UPDATE master_folder SET deleted = 1, restored_by = :userId, restored_on = :now WHERE id = :id";
            break;
        case 'sub_folder':
            $sql = "UPDATE sub_folders SET deleted = 1, restored_by = :userId, restored_on = :now WHERE id = :id";
            break;
        case 'file':
            $sql = "UPDATE uploaded_content SET `delete` = 1, restored_by = :userId, restored_on = :now WHERE id = :id";
            break;
    }
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $id, 'userId' => $userId, 'now' => $now]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['restore_id'], $_POST['type'])) {
    $restoreId = $_POST['restore_id'];
    $type = $_POST['type'];
    restoreItem($conn, $restoreId, $type, $loggedInUserId);
    header("Location: trash.php");
    exit;
}

function getEmployeeNameById($conn, $id)
{
    $sql = "SELECT fullname FROM employees WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $id]);
    return $stmt->fetchColumn();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trash</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h3>Deleted Master Folders</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Folder Name</th>
                    <th>Deleted By</th>
                    <th>Deleted On</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($deletedItems['master_folders'])) : ?>
                    <?php foreach ($deletedItems['master_folders'] as $folder) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($folder['Foldername']); ?></td>
                            <td><?php echo htmlspecialchars($folder['deleted_by']); ?></td>
                            <td><?php echo htmlspecialchars($folder['deleted_on']); ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="restore_id" value="<?php echo $folder['id']; ?>">
                                    <input type="hidden" name="type" value="master_folder">
                                    <button type="submit" class="btn btn-primary">Restore</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="4">No deleted master folders found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <h3 class="mt-5">Deleted Sub Folders</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Sub Folder Name</th>
                    <th>Master Folder Name</th>
                    <th>Deleted By</th>
                    <th>Deleted On</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($deletedItems['sub_folders'])) : ?>
                    <?php foreach ($deletedItems['sub_folders'] as $subFolder) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($subFolder['sub_folder_name']); ?></td>
                            <td><?php echo htmlspecialchars($subFolder['master_folder_name']); ?></td>
                            <td><?php echo htmlspecialchars($subFolder['deleted_by']); ?></td>
                            <td><?php echo htmlspecialchars($subFolder['deleted_on']); ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="restore_id" value="<?php echo $subFolder['id']; ?>">
                                    <input type="hidden" name="type" value="sub_folder">
                                    <button type="submit" class="btn btn-primary">Restore</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="5">No deleted sub folders found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <h3 class="mt-5">Deleted Files</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>File Name</th>
                    <th>Folder Type</th>
                    <th>Folder Name</th>
                    <th>Deleted By</th>
                    <th>Deleted On</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($deletedItems['files'])) : ?>
                    <?php foreach ($deletedItems['files'] as $file) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($file['orginalfilename']); ?></td>
                            <td><?php echo htmlspecialchars($file['is_subfolder'] ? 'Sub Folder' : 'Master Folder'); ?></td>
                            <td><?php echo htmlspecialchars($file['folderid']); // Fetch and display the folder name 
                                ?></td>
                            <td><?php echo htmlspecialchars(getEmployeeNameById($conn, $file['deleted_by'])); ?></td>
                            <td><?php echo htmlspecialchars($file['deleted_on']); ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="restore_id" value="<?php echo $file['id']; ?>">
                                    <input type="hidden" name="type" value="file">
                                    <button type="submit" class="btn btn-primary">Restore</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="6">No deleted files found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            </