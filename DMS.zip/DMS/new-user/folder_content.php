<?php
include 'session_check.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require 'db.php';

function decryptParameter($param)
{
    return base64_decode(urldecode($param));
}

function encryptParameter($param)
{
    return urlencode(base64_encode($param));
}

$loggedInUserId = $_SESSION['user_id'];
$user_id = $_SESSION['user_id'];
$folderId = isset($_GET['fid']) ? decryptParameter($_GET['fid']) : '';
$folderPath = 'Home';

if (!$folderId) {
    die('Invalid folder ID');
}

function fetchFolderDetails($conn, $folderId)
{
    $sql = "SELECT * FROM master_folder WHERE id = :folderId AND deleted = 1";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['folderId' => $folderId]);
    $folder = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$folder) {
        $sql = "SELECT * FROM sub_folders WHERE id = :folderId AND deleted = 1";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['folderId' => $folderId]);
        $folder = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    return $folder;
}

function getMasterFolderId($conn, $folderId, $isSubfolder)
{
    if ($isSubfolder) {
        $sql = "SELECT master_folder_id FROM sub_folders WHERE id = :folderId";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['folderId' => $folderId]);
        $parentId = $stmt->fetchColumn();

        $sql = "SELECT COUNT(*) FROM master_folder WHERE id = :parentId";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['parentId' => $parentId]);
        if ($stmt->fetchColumn() > 0) {
            return $parentId;
        }

        return getMasterFolderId($conn, $parentId, true);
    }

    return $folderId;
}
$folder = fetchFolderDetails($conn, $folderId);
$isSubfolder = isset($folder['master_folder_id']) && !$folder['is_master_folder'];

if (!$folder) {
    die('Folder not found');
}

$masterFolderId = getMasterFolderId($conn, $folderId, $isSubfolder);

function fetchSubfolders($conn, $folderId, $isSubfolder)
{
    $sql = "SELECT * FROM sub_folders WHERE master_folder_id = :folderId AND deleted = 1";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['folderId' => $folderId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$subfolders = fetchSubfolders($conn, $folderId, $isSubfolder);

function fetchUploadedContents($conn, $folderId, $isSubfolder, $searchQuery = '', $limit = 10, $offset = 0)
{
    $sql = "SELECT * FROM uploaded_content WHERE folderid = :folderId AND is_subfolder = :isSubfolder AND `delete` = 1";
    $params = ['folderId' => $folderId, 'isSubfolder' => $isSubfolder];

    if ($searchQuery) {
        $sql .= " AND (doc_number LIKE :searchQuery OR orginalfilename LIKE :searchQuery OR doc_type LIKE :searchQuery)";
        $params['searchQuery'] = '%' . $searchQuery . '%';
    }

    $sql .= " LIMIT :limit OFFSET :offset";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':folderId', $folderId, PDO::PARAM_INT);
    $stmt->bindParam(':isSubfolder', $isSubfolder, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);

    if ($searchQuery) {
        $stmt->bindParam(':searchQuery', $params['searchQuery'], PDO::PARAM_STR);
    }

    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function countUploadedContents($conn, $folderId, $isSubfolder, $searchQuery = '')
{
    $sql = "SELECT COUNT(*) FROM uploaded_content WHERE folderid = :folderId AND is_subfolder = :isSubfolder AND `delete` = 1";
    $params = ['folderId' => $folderId, 'isSubfolder' => $isSubfolder];

    if ($searchQuery) {
        $sql .= " AND (doc_number LIKE :searchQuery OR orginalfilename LIKE :searchQuery OR doc_type LIKE :searchQuery)";
        $params['searchQuery'] = '%' . $searchQuery . '%';
    }

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn();
}

$searchQuery = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$resultsPerPage = 100;
$offset = ($page - 1) * $resultsPerPage;

$totalResults = countUploadedContents($conn, $folderId, $isSubfolder, $searchQuery);
$totalPages = ceil($totalResults / $resultsPerPage);
$uploadedContents = fetchUploadedContents($conn, $folderId, $isSubfolder, $searchQuery, $resultsPerPage, $offset);

function getUserPermissionType($conn, $userId, $masterFolderId)
{
    $sql = "SELECT Permission_type FROM folder_permissions WHERE AssignedTo = :userId AND Folderid = :masterFolderId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $userId, 'masterFolderId' => $masterFolderId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['Permission_type'] : 'no_access';
}

$permissionType = getUserPermissionType($conn, $loggedInUserId, $masterFolderId);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['subfolderName']) && $permissionType === 'full_permission') {
    $subfolderName = $_POST['subfolderName'];
    $remarks = $_POST['remarks']; // Get the remarks from the form
    $parentFolderName = $isSubfolder ? $folder['sub_folder_name'] : $folder['Foldername'];
    $masterFolderName = $parentFolderName . '_subfolder';

    $suffix = 1;
    while (true) {
        $sql = "SELECT COUNT(*) FROM sub_folders WHERE sub_folder_name = :subfolderName AND master_folder_id = :folderId";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['subfolderName' => $masterFolderName, 'folderId' => $folderId]);
        $count = $stmt->fetchColumn();
        if ($count == 0) {
            break;
        }
        $masterFolderName = $parentFolderName . '_subfolder' . $suffix++;
    }

    // Function to fetch the department ID of the logged-in user
    function getDepartmentIdByUserId($conn, $userId)
    {
        $sql = "SELECT department_id FROM employees WHERE id = :userId";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['userId' => $userId]);
        return $stmt->fetchColumn();
    }

    $departmentId = getDepartmentIdByUserId($conn, $loggedInUserId);

    // Insert the new subfolder with the department ID
    $sql = "INSERT INTO sub_folders (sub_folder_name, master_folder_name, master_folder_id, created_by, lastmodified, lastmodifiedby, timestamp, remarks, deleted, is_master_folder, department_id) 
        VALUES (:subfolderName, :masterFolderName, :folderId, :createdBy, NOW(), :lastModifiedBy, NOW(), :remarks, 1, 0, :department_id)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        'subfolderName' => $subfolderName,
        'masterFolderName' => $masterFolderName,
        'folderId' => $folderId,
        'createdBy' => $loggedInUserId,
        'lastModifiedBy' => $loggedInUserId,
        'remarks' => $remarks,
        'department_id' => $departmentId // Store the department ID
    ]);

    header('Location: folder_content.php?fid=' . encryptParameter($folderId));
    exit;
}

function updateFolderName($conn, $folderId, $newName, $isSubfolder, $userId)
{
    if ($isSubfolder) {
        $sql = "UPDATE sub_folders SET sub_folder_name = :newName, lastmodifiedby = :userId WHERE id = :folderId";
    } else {
        $sql = "UPDATE master_folder SET Foldername = :newName, lastmodifiedby = :userId WHERE id = :folderId";
    }
    $stmt = $conn->prepare($sql);
    $stmt->execute(['newName' => $newName, 'userId' => $userId, 'folderId' => $folderId]);
}

function deleteFolder($conn, $folderId, $isSubfolder, $userId)
{
    if ($isSubfolder) {
        $sql = "UPDATE sub_folders SET deleted = 0, lastmodifiedby = :userId WHERE id = :folderId";
    } else {
        $sql = "UPDATE master_folder SET deleted = 0, lastmodifiedby = :userId WHERE id = :folderId";
    }
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $userId, 'folderId' => $folderId]);
}

function updateFolderRemarks($conn, $folderId, $remarks, $isSubfolder, $userId)
{
    if ($isSubfolder) {
        $sql = "UPDATE sub_folders SET remarks = :remarks, lastmodifiedby = :userId WHERE id = :folderId";
    } else {
        $sql = "UPDATE master_folder SET remarks = :remarks, lastmodifiedby = :userId WHERE id = :folderId";
    }
    $stmt = $conn->prepare($sql);
    $stmt->execute(['remarks' => $remarks, 'userId' => $userId, 'folderId' => $folderId]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $targetFolderId = decryptParameter($_POST['folderId']);
    $newName = isset($_POST['newName']) ? $_POST['newName'] : '';
    $remarks = isset($_POST['newRemarks']) ? $_POST['newRemarks'] : '';

    if ($action === 'rename') {
        updateFolderName($conn, $targetFolderId, $newName, $_POST['isSubfolder'], $loggedInUserId);
    } elseif ($action === 'delete') {
        deleteFolder($conn, $targetFolderId, $_POST['isSubfolder'], $loggedInUserId);
    } elseif ($action === 'updateRemarks') {
        updateFolderRemarks($conn, $targetFolderId, $remarks, $_POST['isSubfolder'], $loggedInUserId);
    }

    header('Location: folder_content.php?fid=' . encryptParameter($folderId));
    exit;
}

function getUserUploadLimits($conn, $userId)
{
    $sql = "SELECT department_id, max_upload_size, max_file_uploads FROM employees WHERE id = :userId";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['userId' => $userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
function getEmployeeNameById($conn, $id)
{
    $sql = "SELECT fullname FROM employees WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $id]);
    return $stmt->fetchColumn();
}

function getAccessCode($userId)
{
    global $conn;

    try {
        $sql = "SELECT accesscode FROM employees WHERE id = :userId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return (int) $result['accesscode'];
        } else {
            return null; // User not found or access code not set
        }
    } catch (PDOException $e) {
        // Handle database error
        exit('Database error: ' . $e->getMessage());
    }
}

// Define permission codes
define('PERMISSION_HOD', 1);
define('PERMISSION_FULL_DEPT_CONTROL', 2);
define('PERMISSION_CREATE_FOLDERS', 4);
define('PERMISSION_FOLDERS_FULL', 8);
define('PERMISSION_READ_OPTION', 16);
define('PERMISSION_READ_DOWNLOAD', 32);
define('PERMISSION_UPLOAD_READ_DOWNLOAD', 64);
define('PERMISSION_ADMIN', 128);
define('PERMISSION_POWER_USER', 256);

/**
 * Function to calculate access code based on selected permissions.
 *
 * @param array $permissions An array of permission names.
 * @return int The calculated access code.
 */
function calculateAccessCode($permissions)
{
    // Map permission names to corresponding numeric values
    $mappedPermissions = [
        'HOD' => PERMISSION_HOD,
        'Full-Department-control' => PERMISSION_FULL_DEPT_CONTROL,
        'Create-Folders' => PERMISSION_CREATE_FOLDERS,
        'Folders-full-permission' => PERMISSION_FOLDERS_FULL,
        'Read-Option' => PERMISSION_READ_OPTION,
        'Read/Download' => PERMISSION_READ_DOWNLOAD,
        'Upload/Read/Download' => PERMISSION_UPLOAD_READ_DOWNLOAD,
        'Admin-permission' => PERMISSION_ADMIN,
        'Power-user' => PERMISSION_POWER_USER,
    ];

    $accessCode = 0;
    foreach ($permissions as $permission) {
        if (isset($mappedPermissions[$permission])) {
            $accessCode |= $mappedPermissions[$permission];
        } else {
            // Handle unrecognized permissions
        }
    }

    return $accessCode;
}

/**
 * Function to translate access code into an array of permission names.
 *
 * @param int $accessCode The access code to translate.
 * @return array An array of permission names.
 */
function translateAccessCode($accessCode)
{
    // Map numeric values to corresponding permission names
    $mappedPermissions = [
        PERMISSION_HOD => 'HOD',
        PERMISSION_FULL_DEPT_CONTROL => 'Full-Department-control',
        PERMISSION_CREATE_FOLDERS => 'Create-Folders',
        PERMISSION_FOLDERS_FULL => 'Folders-full-permission',
        PERMISSION_READ_OPTION => 'Read-Option',
        PERMISSION_READ_DOWNLOAD => 'Read/Download',
        PERMISSION_UPLOAD_READ_DOWNLOAD => 'Upload/Read/Download',
        PERMISSION_ADMIN => 'Admin-permission',
        PERMISSION_POWER_USER => 'Power-user',
    ];

    $permissions = [];
    foreach ($mappedPermissions as $value => $permission) {
        if ($accessCode & $value) {
            $permissions[] = $permission;
        }
    }

    return $permissions;
}
function formatSizeUnits($bytes)
{
    if ($bytes >= 1048576) {
        $size = number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        $size = number_format($bytes / 1024, 2) . ' KB';
    } else {
        $size = $bytes . ' bytes';
    }

    return $size;
}
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';
$sortColumn = isset($_GET['sort']) ? $_GET['sort'] : 'uploadeddate';
$sortOrder = isset($_GET['order']) ? $_GET['order'] : 'DESC';
$isSubFolder = isset($_GET['is_subfolder']) ? $_GET['is_subfolder'] : '0';
$userLimits = getUserUploadLimits($conn, $loggedInUserId);
$userAccessCode = getAccessCode($user_id);
$userPermissions = translateAccessCode($userAccessCode);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Folder Content</title>
    <link rel="stylesheet" href="../css/bootstrap-icons-1.11.3/font/bootstrap-icons.min.css" />
    <link rel="stylesheet" href="../css/bootstrap.min.css  " />
    <link rel="stylesheet" href="../style.css">
    <style>
        .folder-item {
            display: inline-block;
            text-align: center;
            margin: 10px;
            width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            position: relative;
        }

        .folder-icon {
            font-size: 48px;
            color: #007bff;
            cursor: pointer;
        }

        .no-access {
            opacity: 0.5;
            pointer-events: none;
        }

        .breadcrumb-item+.breadcrumb-item::before {
            content: ">";
        }

        .tooltip-inner {
            max-width: 350px;
        }

        th[data-sort] {
            cursor: pointer;
        }

        .table-container {
            max-height: 500px;
            overflow-y: auto;
            position: relative;
        }

        .table thead th {
            position: sticky;
            top: 0;
            background-color: white;
            z-index: 1;
            border: 1px solid #dee2e6;
            /* Border color matching table */
        }

        .table thead th.blur {
            backdrop-filter: blur(5px);
        }



        .form-group {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .hidden-form {
            display: none !important;
        }

        th .bi {
            color: tomato;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Folder Content</h3>
            <button id="backButton" class="btn btn-outline-secondary"><i class="bi bi-arrow-return-left"></i> Back</button>
            <button class="btn btn-outline-secondary" onclick="window.location.href='folders.php';">
                <i class="bi bi-house"></i>
            </button>
        </div>
        <?php include 'breadcrump.php'; ?>
        <?php if (isset($_GET['success'])) : ?>
            <div class="alert alert-success">
                Document number <?php echo htmlspecialchars($_GET['success']); ?> has been uploaded successfully.
            </div>
        <?php endif; ?>
        <?php if (isset($errorMsg)) : ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($errorMsg); ?>
            </div>
        <?php endif; ?>
        <div id="foldersListContainer">
            <?php foreach ($subfolders as $subfolder) : ?>
                <div class="folder-item <?php echo $permissionType === 'no_access' ? 'no-access' : 'clickable'; ?>" data-fid="<?php echo encryptParameter($subfolder['id']); ?>" data-bs-toggle="tooltip" title="<?php echo htmlspecialchars($subfolder['remarks']); ?>">
                    <span class="folder-icon bi bi-folder"></span>
                    <div class="folder-name"><?php echo htmlspecialchars($subfolder['sub_folder_name']); ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($permissionType === 'full_permission') : ?>

            <?php if (in_array('HOD', $userPermissions) || in_array('Full-Department-control', $userPermissions) ||  in_array('Create-Folders', $userPermissions)) : ?>


                <div class="container mt-5">
                    <button id="showFormButton" class="btn btn-outline-primary"><i class="bi bi-folder-plus"> Create Subfolder</i></button>
                    <form method="POST" class="hidden-form row" id="subfolderForm">
                        <div class="form-group col-md-6">
                            <br>
                            <input type="text" class="form-control" id="subfolderName" name="subfolderName" placeholder=" " required>
                            <label for="subfolderName" class="form-label">Subfolder Name</label>
                        </div>
                        <div class="form-group col-md-6">
                            <br>
                            <input type="text" class="form-control" id="remarks" name="remarks" placeholder=" ">
                            <label for="remarks" class="form-label">Remarks</label>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-outline-primary">Create</button>
                            <button type="button" class="btn btn-secondary" id="hideFormButton"><i class="bi bi-x-circle"></i></button>
                        </div>
                    </form>
                </div>
                <script>
                    document.getElementById('showFormButton').addEventListener('click', function() {
                        document.getElementById('subfolderForm').classList.toggle('hidden-form');
                    });

                    document.getElementById('hideFormButton').addEventListener('click', function() {
                        document.getElementById('subfolderForm').classList.add('hidden-form');
                    });
                    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
                    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                        return new bootstrap.Tooltip(tooltipTriggerEl)
                    })
                </script>

            <?php endif; ?>
        <?php else : ?>
            <br>
            <button class="btn btn-outline-secondary" data-bs-toggle="tooltip" data-bs-placement="top" title="No rights">
                <i class="bi bi-folder-plus"></i> Create Subfolder
            </button>
            <script>
                // Initialize tooltips
                var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
                var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl)
                })
            </script>
        <?php endif; ?>
        <div class="container mt-5">
            <?php if (in_array($permissionType, ['read_write', 'full_permission'])) : ?>
                <br>

                <script>
                    document.getElementById('uploadForm').addEventListener('submit', function(e) {
                        const files = document.getElementById('files').files;
                        const maxFileUploads = <?php echo $maxFileUploads; ?>;
                        const maxUploadSize = <?php echo $maxUploadSize; ?>;
                        let totalSize = 0;

                        for (let i = 0; i < files.length; i++) {
                            totalSize += files[i].size;
                        }

                        if (files.length > maxFileUploads) {
                            e.preventDefault();
                            document.getElementById('errorContainer').textContent = `You don't have permission to upload ${files.length} files. Maximum allowed is ${maxFileUploads} files.`;
                            document.getElementById('errorContainer').classList.remove('d-none');
                        } else if (totalSize > maxUploadSize) {
                            e.preventDefault();
                            const totalSizeMB = (totalSize / (1024 * 1024)).toFixed(2);
                            const maxUploadSizeMB = (maxUploadSize / (1024 * 1024)).toFixed(2);
                            document.getElementById('errorContainer').textContent = `Total size of files is ${totalSizeMB} MB. Maximum allowed is ${maxUploadSizeMB} MB.`;
                            document.getElementById('errorContainer').classList.remove('d-none');
                        }
                    });
                </script>
                <button class="btn btn-primary" onclick="showUploadForm()">Upload Document <i class="bi bi-upload"></i></button>
                <button class="btn btn-primary" onclick="showBulkUploadForm()">Bulk Upload Documents <i class="bi bi-upload"></i></button>

                <div class="container mt-5" id="uploadContainer" style="display: none;">
                    <h3>Upload Document</h3>
                    <form id="uploadForm" method="POST" action="upload.php" enctype="multipart/form-data">
                        <input type="hidden" name="folder_id" id="folderId" value="<?php echo $folderId; ?>">
                        <input type="hidden" name="is_subfolder" id="isSubfolder" value="<?php echo $isSubFolder; ?>">

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="file" class="form-label">Select Document</label>
                                <input type="file" class="form-control" id="file" name="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.txt" required>
                            </div>
                            <div class="col-md-6">
                                <label for="docNumber" class="form-label">Document Number</label>
                                <input type="text" class="form-control" id="docNumber" name="doc_number" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="remarks" class="form-label">Remarks</label>
                                <textarea class="form-control" id="remarks" name="remarks"></textarea>
                            </div>
                            <div class="col-md-6">
                                <label for="expiryDate" class="form-label">Expiry Date</label>
                                <input type="date" class="form-control" id="expiryDate" name="expiry_date">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="docType" class="form-label">Document Type</label>
                                <select class="form-select" id="docType" name="doc_type" required>
                                    <option value="invoice">Invoice</option>
                                    <option value="purchase_order">Purchase Order</option>
                                    <option value="general_document">General Document</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="docSeries" class="form-label">Document Series</label>
                                <input type="text" class="form-control" id="docSeries" name="doc_series" required>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary">Upload <i class="bi bi-upload"></i></button>
                            <button type="button" class="btn btn-secondary" onclick="hideUploadForm()">Close</button>
                        </div>
                    </form>
                </div>

                <div class="container mt-5" id="bulkUploadContainer" style="display: none;">
                    <h3>Bulk Upload Documents</h3>
                    <form id="bulkUploadForm" method="POST" action="bulk_upload.php" enctype="multipart/form-data">
                        <input type="hidden" name="folder_id" id="folderId" value="<?php echo $folderId; ?>">
                        <input type="hidden" name="is_subfolder" id="isSubfolder" value="<?php echo $isSubFolder; ?>">

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="files" class="form-label">Select Documents</label>
                                <input type="file" class="form-control" id="files" name="files[]" accept=".pdf,.doc,.docx,.xls,.xlsx,.txt" multiple required>
                            </div>
                            <div class="col-md-6">
                                <label for="bulkDocNumber" class="form-label">Starting Document Number</label>
                                <input type="text" class="form-control" id="bulkDocNumber" name="doc_number" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="bulkRemarks" class="form-label">Remarks</label>
                                <textarea class="form-control" id="bulkRemarks" name="remarks"></textarea>
                            </div>
                            <div class="col-md-6">
                                <label for="bulkExpiryDate" class="form-label">Expiry Date</label>
                                <input type="date" class="form-control" id="bulkExpiryDate" name="expiry_date">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="bulkDocType" class="form-label">Document Type</label>
                                <select class="form-select" id="bulkDocType" name="doc_type" required>
                                    <option value="invoice">Invoice</option>
                                    <option value="purchase_order">Purchase Order</option>
                                    <option value="general_document">General Document</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="bulkDocSeries" class="form-label">Document Series</label>
                                <input type="text" class="form-control" id="bulkDocSeries" name="doc_series" required>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary">Bulk Upload <i class="bi bi-upload"></i></button>
                            <button type="button" class="btn btn-secondary" onclick="hideBulkUploadForm()">Close</button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>

        <script>
            function showUploadForm() {
                document.getElementById('uploadContainer').style.display = 'block';
                document.getElementById('bulkUploadContainer').style.display = 'none';
            }

            function hideUploadForm() {
                document.getElementById('uploadContainer').style.display = 'none';
            }

            function showBulkUploadForm() {
                document.getElementById('bulkUploadContainer').style.display = 'block';
                document.getElementById('uploadContainer').style.display = 'none';
            }

            function hideBulkUploadForm() {
                document.getElementById('bulkUploadContainer').style.display = 'none';
            }
        </script>


        <div class="container-fluid">
            <h4 class="mt-5">Uploaded Contents</h4>
            <div class="search-sort-section mt-5">
                <form class="d-flex mb-3 align-items-center">
                    <div class="input-group">
                        <span class="input-group-text" id="searchIcon">
                            <i class="bi bi-search"></i>
                        </span>
                        <input class="form-control" type="search" placeholder="Search" aria-label="Search" id="searchInput">
                    </div>
                    <button class="btn btn-outline-danger ms-2" type="button" id="clearSearch">
                        <i class="bi bi-x-circle"></i>
                    </button>
                </form>
            </div>

            <script>
                document.getElementById('searchInput').addEventListener('input', function() {
                    const searchQuery = this.value.toLowerCase();
                    const rows = document.querySelectorAll('tbody tr');
                    rows.forEach(row => {
                        const docNumber = row.children[0].innerText.toLowerCase();
                        const originalFilename = row.children[1].innerText.toLowerCase();
                        const docType = row.children[4].innerText.toLowerCase();
                        if (docNumber.includes(searchQuery) || originalFilename.includes(searchQuery) || docType.includes(searchQuery)) {
                            row.style.display = '';
                            if (docNumber.includes(searchQuery) || originalFilename.includes(searchQuery) || docType.includes(searchQuery)) {
                                row.children[0].style.backgroundColor = 'yellow';
                            } else {
                                row.children[0].style.backgroundColor = '';
                            }
                        } else {
                            row.style.display = 'none';
                        }
                    });
                });

                document.getElementById('clearSearch').addEventListener('click', function() {
                    document.getElementById('searchInput').value = '';
                    const rows = document.querySelectorAll('tbody tr');
                    rows.forEach(row => {
                        row.style.display = '';
                        row.children[0].style.backgroundColor = '';
                    });
                });

                const tableContainer = document.querySelector('.table-container');
                tableContainer.addEventListener('scroll', () => {
                    const thead = tableContainer.querySelector('thead');
                    thead.classList.add('blur');
                    clearTimeout(thead.dataset.timeout);
                    thead.dataset.timeout = setTimeout(() => {
                        thead.classList.remove('blur');
                    }, 100);
                });
            </script>




            <div class="table-responsive table-container">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>SR #</th>
                            <th data-sort="doc-number">Doc# <i class="bi bi-sort-alpha-down"></i></th>
                            <th data-sort="filesize">File Size <i class="bi bi-sort-numeric-down"></i></th>
                            <th data-sort="filetype">File Type <i class="bi bi-file-earmark"></i></th>
                            <th data-sort="doc-type">Doc Type <i class="bi bi-file-earmark-text"></i></th>
                            <th data-sort="expiry-date">Expiry Date <i class="bi bi-calendar"></i></th>
                            <th data-sort="uploadeddate">Uploaded <i class="bi bi-clock"></i></th>
                            <th data-sort="uploadedby">Uploaded By <i class="bi bi-person"></i></th>
                            <th data-sort="validation">Validation <i class="bi bi-check-circle"></i></th>
                            <th>Actions <i class="bi bi-pencil"></i><i class="bi bi-trash"></i></th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <?php
                        $srNo = 1;
                        foreach ($uploadedContents as $content) : ?>
                            <tr data-id="<?php echo $content['id']; ?>">
                                <td class="sr-no"><?php echo $srNo++; ?></td>
                                <td class="doc-number"><?php echo htmlspecialchars($content['doc_number']); ?></td>

                                <td class="filesize"><?php echo htmlspecialchars(formatSizeUnits($content['filesize'])); ?></td>

                                <td class="filetype"><?php echo htmlspecialchars($content['filetype']); ?></td>
                                <td class="doc-type"><?php echo htmlspecialchars($content['doc_type']); ?></td>
                                <?php
                                $expiryDate = new DateTime($content['Expirydate']);
                                $today = new DateTime();
                                $interval = $today->diff($expiryDate)->days;

                                if ($expiryDate < $today) {
                                    $class = 'text-danger fw-bolder table-active';
                                } elseif ($interval <= 15) {
                                    $class = 'text-warning fw-bolder';
                                } else {
                                    $class = 'text-success fw-bolder';
                                }
                                ?>
                                <td class="expiry-date <?php echo $class; ?>"><?php echo htmlspecialchars($content['Expirydate']); ?></td>
                                <td class="uploadeddate"><?php echo htmlspecialchars($content['uploadeddate']); ?></td>
                                <td class="uploadedby"><?php echo htmlspecialchars(getEmployeeNameById($conn, $content['uploadedby'])); ?></td>
                                <td class="validation"><?php echo $content['validation'] ?? 'Not Verified'; ?></td>
                                <td>
                                    <?php
                                    $fileExtension = strtolower(pathinfo($content['orginalfilename'], PATHINFO_EXTENSION));
                                    $viewLink = '';
                                    if ($fileExtension == 'pdf') {
                                        $viewLink = $content['filepath'];
                                    } elseif (in_array($fileExtension, ['doc', 'docx', 'xls', 'xlsx'])) {
                                        $viewLink = "https://view.officeapps.live.com/op/view.aspx?src=" . urlencode($content['filepath']);
                                    }
                                    ?>
                                    <?php if ($viewLink) : ?>
                                        <a href="<?php echo $viewLink; ?>" class="btn btn-primary" title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo $content['filepath']; ?>" download="<?php echo $content['orginalfilename']; ?>" class="btn btn-success" title="Download">
                                        <i class="bi bi-download"></i>
                                    </a>
                                    <?php if ($permissionType === 'full_permission') : ?>
                                        <button class="btn btn-primary edit-button" data-id="<?php echo $content['id']; ?>">Edit</button>
                                        <button class="btn btn-danger delete-button" data-id="<?php echo $content['id']; ?>"><i class="bi bi-x-circle"></i></button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="folder_content.php?fid=<?php echo htmlspecialchars($_GET['fid']); ?>&search=<?php echo htmlspecialchars($searchQuery); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
        <script>
            document.getElementById('clearSearch').addEventListener('click', function() {
                document.getElementById('searchInput').value = '';
                window.location.href = 'folder_content.php?fid=<?php echo htmlspecialchars($_GET['fid']); ?>';
            });

            document.addEventListener('DOMContentLoaded', () => {
                const headers = document.querySelectorAll('th[data-sort]');
                headers.forEach(header => {
                    header.addEventListener('click', () => {
                        const tableBody = document.getElementById('tableBody');
                        if (!tableBody) return;

                        const rows = Array.from(tableBody.querySelectorAll('tr'));
                        const sortKey = header.getAttribute('data-sort');
                        const order = header.dataset.order = -(header.dataset.order || -1);

                        rows.sort((a, b) => {
                            const aElement = a.querySelector(`.${sortKey}`);
                            const bElement = b.querySelector(`.${sortKey}`);
                            if (!aElement || !bElement) return 0;

                            const aText = aElement.textContent.trim();
                            const bText = bElement.textContent.trim();
                            return aText > bText ? order : aText < bText ? -order : 0;
                        });

                        while (tableBody.firstChild) tableBody.removeChild(tableBody.firstChild);
                        rows.forEach((row, index) => {
                            row.querySelector('.sr-no').textContent = index + 1;
                            tableBody.appendChild(row);
                        });
                    });
                });
            });
        </script>
        <!-- Right-click context menu -->
        <div id="contextMenu" class="dropdown-menu">
            <?php if ($permissionType === 'full_permission') : ?>
                <button id="renameContextButton" class="dropdown-item">Rename</button>
                <button id="deleteContextButton" class="dropdown-item">Delete</button>
                <button id="updateRemarksContextButton" class="dropdown-item">Update Remarks</button>
            <?php else : ?>
                <button class="dropdown-item" disabled>No Rights</button>
            <?php endif; ?>
        </div>

        <!-- Rename Modal -->
        <div id="renameModal" class="modal fade" tabindex="-1" aria-labelledby="renameModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="renameModalLabel">Rename Folder</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="renameFolderForm" method="POST">
                            <input type="hidden" name="folderId" id="renameFolderId">
                            <input type="hidden" name="action" value="rename">
                            <input type="hidden" name="isSubfolder" id="isSubfolder">
                            <div class="mb-3">
                                <label for="newName" class="form-label">New Name</label>
                                <input type="text" class="form-control" id="newName" name="newName" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Rename</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Update Remarks Modal -->
        <div id="updateRemarksModal" class="modal fade" tabindex="-1" aria-labelledby="updateRemarksModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="updateRemarksModalLabel">Update Remarks</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="updateRemarksForm" method="POST">
                            <input type="hidden" name="folderId" id="remarksFolderId">
                            <input type="hidden" name="action" value="updateRemarks">
                            <input type="hidden" name="isSubfolder" id="remarksIsSubfolder">
                            <div class="mb-3">
                                <label for="newRemarks" class="form-label">New Remarks</label>
                                <textarea class="form-control" id="newRemarks" name="newRemarks" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <script>
            function showUploadForm() {
                document.getElementById('uploadContainer').style.display = 'block';
            }
        </script>



        <script src="../js/bootstrap.bundle.min.js"></script>
        <script>
            document.querySelectorAll('.clickable').forEach(function(element) {
                element.addEventListener('click', function() {
                    var folderId = this.getAttribute('data-fid');
                    window.location.href = 'folder_content.php?fid=' + folderId;
                });
            });

            document.getElementById('backButton').addEventListener('click', function() {
                window.history.back();
            });

            // Tooltip initialization
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });

            let contextMenu = document.getElementById('contextMenu');
            let renameModal = new bootstrap.Modal(document.getElementById('renameModal'));
            let updateRemarksModal = new bootstrap.Modal(document.getElementById('updateRemarksModal'));
            let currentFolderId;
            let isSubfolder;

            document.querySelectorAll('.folder-item').forEach(function(element) {
                element.addEventListener('contextmenu', function(event) {
                    event.preventDefault();
                    currentFolderId = element.getAttribute('data-fid');
                    isSubfolder = element.closest('.clickable') ? 1 : 0;
                    contextMenu.style.display = 'block';
                    contextMenu.style.left = event.pageX + 'px';
                    contextMenu.style.top = event.pageY + 'px';
                });
            });

            document.addEventListener('click', function() {
                contextMenu.style.display = 'none';
            });

            document.getElementById('renameContextButton').addEventListener('click', function() {
                document.getElementById('renameFolderId').value = currentFolderId;
                document.getElementById('isSubfolder').value = isSubfolder;
                renameModal.show();
            });

            document.getElementById('updateRemarksContextButton').addEventListener('click', function() {
                document.getElementById('remarksFolderId').value = currentFolderId;
                document.getElementById('remarksIsSubfolder').value = isSubfolder;
                updateRemarksModal.show();
            });

            document.getElementById('deleteContextButton').addEventListener('click', function() {
                if (confirm('Are you sure you want to delete this folder?')) {
                    var form = document.createElement('form');
                    form.method = 'POST';
                    form.style.display = 'none';

                    var folderIdInput = document.createElement('input');
                    folderIdInput.name = 'folderId';
                    folderIdInput.value = currentFolderId;
                    form.appendChild(folderIdInput);

                    var actionInput = document.createElement('input');
                    actionInput.name = 'action';
                    actionInput.value = 'delete';
                    form.appendChild(actionInput);

                    var isSubfolderInput = document.createElement('input');
                    isSubfolderInput.name = 'isSubfolder';
                    isSubfolderInput.value = isSubfolder;
                    form.appendChild(isSubfolderInput);

                    document.body.appendChild(form);
                    form.submit();
                }
            });


            document.querySelectorAll('.delete-button').forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    fetch('delete_document.php', {
                        method: 'POST',
                        body: JSON.stringify({
                            id: id
                        }),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }).then(response => response.json()).then(data => {
                        if (data.success) {
                            location.reload();
                        } else {
                            alert('Failed to delete document');
                        }
                    }).catch(error => console.error('Error:', error));
                });
            });

            document.querySelectorAll('.edit-button').forEach(button => {
                button.addEventListener('click', function() {
                    const row = this.closest('tr');
                    const docNumberCell = row.querySelector('.doc-number');
                    const docTypeCell = row.querySelector('.doc-type');
                    const expiryDateCell = row.querySelector('.expiry-date');
                    const validationCell = row.querySelector('.validation');

                    if (this.textContent === 'Edit') {
                        const docNumber = docNumberCell.innerText;
                        const docType = docTypeCell.innerText;
                        const expiryDate = expiryDateCell.innerText;
                        const validation = validationCell.innerText;

                        docNumberCell.innerHTML = `<input type="text" class="form-control" value="${docNumber}">`;
                        docTypeCell.innerHTML = `
                <select class="form-select">
                    <option value="invoice" ${docType === 'invoice' ? 'selected' : ''}>Invoice</option>
                    <option value="purchase_order" ${docType === 'purchase_order' ? 'selected' : ''}>Purchase Order</option>
                    <option value="general_document" ${docType === 'general_document' ? 'selected' : ''}>General Document</option>
                </select>
            `;
                        expiryDateCell.innerHTML = `<input type="date" class="form-control" value="${expiryDate}">`;
                        validationCell.innerHTML = `
                <select class="form-select">
                    <option value="Not Verified" ${validation === 'Not Verified' ? 'selected' : ''}>Not Verified</option>
                    <option value="Valid" ${validation === 'Valid' ? 'selected' : ''}>Valid</option>
                    <option value="Not Valid" ${validation === 'Not Valid' ? 'selected' : ''}>Not Valid</option>
                </select>
            `;

                        this.textContent = 'Save';
                        this.classList.remove('btn-primary');
                        this.classList.add('btn-success');
                    } else if (this.textContent === 'Save') {
                        const id = row.getAttribute('data-id');
                        const docNumber = docNumberCell.querySelector('input').value;
                        const docType = docTypeCell.querySelector('select').value;
                        const expiryDate = expiryDateCell.querySelector('input').value;
                        const validation = validationCell.querySelector('select').value;

                        fetch('update_document.php', {
                            method: 'POST',
                            body: JSON.stringify({
                                id: id,
                                docNumber: docNumber,
                                expiryDate: expiryDate,
                                docType: docType,
                                validation: validation
                            }),
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).then(response => response.json()).then(data => {
                            if (data.success) {
                                docNumberCell.innerHTML = docNumber;
                                docTypeCell.innerHTML = docType;
                                expiryDateCell.innerHTML = expiryDate;
                                validationCell.innerHTML = validation;

                                this.textContent = 'Edit';
                                this.classList.remove('btn-success');
                                this.classList.add('btn-primary');
                                window.location.reload();
                            } else {
                                alert('Failed to update document');
                            }
                        }).catch(error => console.error('Error:', error));
                    }
                });
            });
        </script>
</body>

</html>