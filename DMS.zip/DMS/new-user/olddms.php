<?php
session_start();
include 'functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get user details from session or database
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$fullname = $_SESSION['fullname']; // Assuming this is set in the session
$email = $_SESSION['email']; // Assuming this is set in the session

// Fetch user's access code from the database
$userAccessCode = getAccessCode($user_id);

// Translate access code to human-readable permissions
$userPermissions = translateAccessCode($userAccessCode);

// Example URL encryption and passing department ID
$department_id = 1; // Example department ID, replace with actual logic to get department ID
$encryptedDepartmentId = base64_encode(openssl_encrypt($department_id, 'AES-256-CBC', 'encryption_key', OPENSSL_RAW_DATA, '1234567890123456'));

// Example logout URL
$logout_url = 'logout.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DMS - Document Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.8.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        /* Custom styles */
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky">
                    <div class="py-4 px-3 mb-4 bg-white shadow">
                        <h3 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                            <span>Options</span>
                        </h3>
                    </div>
                    <ul class="nav flex-column">
                        <?php if (in_array('HOD', $userPermissions)) : ?>
                            <li class="nav-item">
                                <a class="nav-link" href="dms.php?dept=<?php echo $encryptedDepartmentId; ?>">
                                    <i class="bi bi-folder"></i> Department
                                </a>
                                <a class="nav-link" href="dms.php?dept=<?php echo $encryptedDepartmentId; ?>">
                                    <i class="bi bi-folder"></i> MY Departments
                                </a>
                                <a class="nav-link" href="dms.php?dept=<?php echo $encryptedDepartmentId; ?>">
                                    <i class="bi bi-folder"></i> User Management
                                </a>
                                <a class="nav-link" href="dms.php?dept=<?php echo $encryptedDepartmentId; ?>">
                                    <i class="bi bi-folder"></i> Folder Permission
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (in_array('Admin-permission', $userPermissions)) : ?>
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                    <i class="bi bi-gear"></i> Admin Settings
                                </a>
                            </li>
                        <?php endif; ?>
                        <!-- Add more options based on user permissions -->
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="pt-3 pb-2 mb-3">
                    <h2>Welcome, <?php echo htmlspecialchars($fullname); ?></h2>
                    <p>Email: <?php echo htmlspecialchars($email); ?></p>
                    <a href="<?php echo $logout_url; ?>" class="btn btn-danger">Logout</a>
                </div>

                <!-- Main content area -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!-- Add your main content here -->
                                <h4 class="card-title">Document Management System</h4>
                                <p class="card-text">Welcome to the Document Management System. Choose an option from the sidebar.</p>
                                <div class="mt-4">
                                    <h5>Permissions:</h5>
                                    <?php foreach ($userPermissions as $permission) : ?>
                                        <div><?php echo htmlspecialchars($permission); ?></div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </main>
        </div>
    </div>

    <!-- Bootstrap JS and other scripts -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>

</html>