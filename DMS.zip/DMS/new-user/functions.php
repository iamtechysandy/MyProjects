<?php
// Include your database connection file
require_once 'db.php';

/**
 * Function to fetch user by username or email
 * @param string $usernameOrEmail Username or email of the user
 * @return array|bool User data array if found, false otherwise
 */
function getUserByUsernameOrEmail($usernameOrEmail)
{
    global $conn;
    $sql = "SELECT * FROM employees WHERE username = :username OR email = :email";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':username', $usernameOrEmail);
    $stmt->bindParam(':email', $usernameOrEmail);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    return $user ? $user : false;
}

/**
 * Function to update user password by user ID
 * @param int $userId User ID
 * @param string $newPassword New password (already hashed)
 * @return bool True on success, false on failure
 */
function updateUserPassword($userId, $newPassword)
{
    global $conn;
    $sql = "UPDATE employees SET password = :password WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':password', $newPassword);
    $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    return $stmt->execute();
}

/**
 * Function to check if a username is already taken
 * @param string $username Username to check
 * @return bool True if username exists, false otherwise
 */
function isUsernameTaken($username)
{
    global $conn;
    $sql = "SELECT COUNT(*) AS count FROM employees WHERE username = :username";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['count'] > 0;
}

/**
 * Function to get department name by department ID
 * @param int $departmentId Department ID
 * @return string Department name
 */
function getDepartmentNameById($departmentId)
{
    global $conn; // Access the global database connection object

    try {
        // Prepare SQL statement
        $stmt = $conn->prepare("SELECT department_name FROM departments WHERE id = :id");
        $stmt->bindParam(':id', $departmentId, PDO::PARAM_INT);
        $stmt->execute();

        // Fetch department name
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            return $row['department_name'];
        } else {
            return 'Unknown Department'; // Default if department ID doesn't exist
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return 'Unknown Department'; // Default on error
    }
}

function getAccessCode($userId)
{
    global $conn;

    try {
        $sql = "SELECT accesscode FROM employees WHERE id = :userId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return (int) $result['accesscode'];
        } else {
            return null; // User not found or access code not set
        }
    } catch (PDOException $e) {
        // Handle database error
        exit('Database error: ' . $e->getMessage());
    }
}





// Define permission codes
define('PERMISSION_HOD', 1);
define('PERMISSION_FULL_DEPT_CONTROL', 2);
define('PERMISSION_CREATE_FOLDERS', 4);
define('PERMISSION_FOLDERS_FULL', 8);
define('PERMISSION_READ_OPTION', 16);
define('PERMISSION_READ_DOWNLOAD', 32);
define('PERMISSION_UPLOAD_READ_DOWNLOAD', 64);
define('PERMISSION_ADMIN', 128);
define('PERMISSION_POWER_USER', 256);

/**
 * Function to calculate access code based on selected permissions.
 *
 * @param array $permissions An array of permission names.
 * @return int The calculated access code.
 */
function calculateAccessCode($permissions)
{
    // Map permission names to corresponding numeric values
    $mappedPermissions = [
        'HOD' => PERMISSION_HOD,
        'Full-Department-control' => PERMISSION_FULL_DEPT_CONTROL,
        'Create-Folders' => PERMISSION_CREATE_FOLDERS,
        'Folders-full-permission' => PERMISSION_FOLDERS_FULL,
        'Read-Option' => PERMISSION_READ_OPTION,
        'Read/Download' => PERMISSION_READ_DOWNLOAD,
        'Upload/Read/Download' => PERMISSION_UPLOAD_READ_DOWNLOAD,
        'Admin-permission' => PERMISSION_ADMIN,
        'Power-user' => PERMISSION_POWER_USER,
    ];

    $accessCode = 0;
    foreach ($permissions as $permission) {
        if (isset($mappedPermissions[$permission])) {
            $accessCode |= $mappedPermissions[$permission];
        } else {
            // Handle unrecognized permissions
        }
    }

    return $accessCode;
}

/**
 * Function to translate access code into an array of permission names.
 *
 * @param int $accessCode The access code to translate.
 * @return array An array of permission names.
 */
function translateAccessCode($accessCode)
{
    // Map numeric values to corresponding permission names
    $mappedPermissions = [
        PERMISSION_HOD => 'HOD',
        PERMISSION_FULL_DEPT_CONTROL => 'Full-Department-control',
        PERMISSION_CREATE_FOLDERS => 'Create-Folders',
        PERMISSION_FOLDERS_FULL => 'Folders-full-permission',
        PERMISSION_READ_OPTION => 'Read-Option',
        PERMISSION_READ_DOWNLOAD => 'Read/Download',
        PERMISSION_UPLOAD_READ_DOWNLOAD => 'Upload/Read/Download',
        PERMISSION_ADMIN => 'Admin-permission',
        PERMISSION_POWER_USER => 'Power-user',
    ];

    $permissions = [];
    foreach ($mappedPermissions as $value => $permission) {
        if ($accessCode & $value) {
            $permissions[] = $permission;
        }
    }

    return $permissions;
}

function fetchFolders()
{
    global $conn;
    try {
        $sql = "SELECT * FROM master_folder WHERE deleted = 1";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}


function deleteFolder($folderId)
{
    global $conn;
    try {
        $sql = "UPDATE master_folder SET deleted = 0 WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $folderId, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}
function updateFolderName($folderId, $newFolderName)
{
    global $conn;
    try {
        $sql = "UPDATE master_folder SET Foldername = :foldername, updated_at = NOW() WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':foldername', $newFolderName);
        $stmt->bindParam(':id', $folderId, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}
// Fetch employees by department ID
function getEmployeesByDepartmentId($departmentId)
{
    global $conn;

    try {
        $sql = "SELECT id, username, fullname, email, status FROM employees WHERE department_id = :departmentId AND deleted = 1";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':departmentId', $departmentId, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return [];
    }
}


function updateEmployeeStatus($employeeId, $status)
{
    global $conn;

    try {
        $sql = "UPDATE employees SET status = :status WHERE id = :employeeId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':status', $status, PDO::PARAM_INT);
        $stmt->bindParam(':employeeId', $employeeId, PDO::PARAM_INT);

        error_log("Executing query: UPDATE employees SET status = $status WHERE id = $employeeId");

        if ($stmt->execute()) {
            return true;
        } else {
            error_log("Failed to execute update query.");
            return false;
        }
    } catch (PDOException $e) {
        error_log("Error updating status: " . $e->getMessage());
        return false;
    }
}


// Reset employee password
function resetEmployeePassword($employeeId, $newPassword)
{
    global $conn;

    try {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $sql = "UPDATE employees SET password = :password WHERE id = :employeeId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':employeeId', $employeeId, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}
// Fetch users by department
function getUsersByDepartment($departmentId)
{
    global $conn;
    $stmt = $conn->prepare("SELECT id, fullname FROM employees WHERE department_id = :departmentId");
    $stmt->bindParam(':departmentId', $departmentId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch folders by department
function getFoldersByDepartment($departmentId)
{
    global $conn;
    $stmt = $conn->prepare("SELECT id, Foldername FROM master_folder WHERE DepartmentId = :departmentId");
    $stmt->bindParam(':departmentId', $departmentId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to check for duplicate folder names
function checkDuplicateFolderName($folderName, $departmentId)
{
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) FROM master_folder WHERE Foldername = :folderName AND DepartmentId = :departmentId");
    $stmt->bindParam(':folderName', $folderName);
    $stmt->bindParam(':departmentId', $departmentId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchColumn() > 0;
}
