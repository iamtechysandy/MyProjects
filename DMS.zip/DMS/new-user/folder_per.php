<h1 class="text-enter">Folder</h1>
<div class="container mt-5">
    <?php if (isset($_SESSION['folder_success_message'])) : ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['folder_success_message'];
            unset($_SESSION['folder_success_message']); ?>
        </div>
    <?php endif; ?>
    <?php if (isset($_SESSION['folder_error_message'])) : ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['folder_error_message'];
            unset($_SESSION['folder_error_message']); ?>
        </div>
    <?php endif; ?>

    <!-- Folder creation form -->
    <div class="card mb-4">
        <div class="card-header">
            Create New Folder
        </div>
        <div class="card-body">
            <form action="dms.php" method="POST">
                <div class="mb-3">
                    <label for="foldername" class="form-label">Folder Name</label>
                    <input type="text" class="form-control" id="foldername" name="foldername" required>
                </div>
                <!-- Hidden fields -->
                <input type="hidden" name="department_id" value="<?php echo htmlspecialchars($_SESSION['department_id']); ?>">
                <input type="hidden" name="department_name" value="<?php echo htmlspecialchars($department_name); ?>">
                <input type="hidden" name="created_by" value="<?php echo htmlspecialchars($_SESSION['user_id']); ?>">
                <button type="submit" name="create_folder" class="btn btn-primary">Create Folder</button>
            </form>
        </div>
    </div>

    <!-- Folder list -->
    <div class="card">
        <div class="card-header">
            Folder List
        </div>
        <div class="card-body">
            <?php if ($folders) : ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Folder Name</th>
                            <th>Department ID</th>
                            <th>Department Name</th>
                            <th>Created By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($folders as $folder) : ?>
                            <tr>
                                <td><?php echo $folder['id']; ?></td>
                                <td><?php echo htmlspecialchars($folder['Foldername']); ?></td>
                                <td><?php echo $folder['DepartmentId']; ?></td>
                                <td><?php echo htmlspecialchars($folder['DepartmentName']); ?></td>
                                <td><?php echo $folder['Createdby']; ?></td>
                                <td>
                                    <!-- Edit Folder Button -->
                                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editFolderModal" data-folder-id="<?php echo $folder['id']; ?>" data-folder-name="<?php echo htmlspecialchars($folder['Foldername']); ?>">Edit</button>
                                    <!-- Delete Folder Button -->
                                    <form action="dms.php" method="POST" class="d-inline">
                                        <input type="hidden" name="folder_id" value="<?php echo $folder['id']; ?>">
                                        <button type="submit" name="delete_folder" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p>No folders found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Edit Folder Modal -->
<div class="modal fade" id="editFolderModal" tabindex="-1" aria-labelledby="editFolderModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editFolderModalLabel">Edit Folder</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editFolderForm" action="dms.php" method="POST">
                    <input type="hidden" id="edit_folder_id" name="folder_id">
                    <div class="mb-3">
                        <label for="edit_foldername" class="form-label">New Folder Name</label>
                        <input type="text" class="form-control" id="edit_foldername" name="new_foldername" required>
                    </div>
                    <button type="submit" name="edit_folder" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>
<h3 class="text-center">Assign Permissions</h3>
<?php if (in_array('HOD', $userPermissions)) : ?>


    <div class="container mt-5">


        <div class="mb-3">
            <label for="userSelect" class="form-label">Select User:</label>
            <select id="userSelect" class="form-select">
                <option value="">Select a user</option>
                <?php foreach ($users as $user) : ?>
                    <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['fullname']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div id="foldersContainer" style="display: none;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Sr</th>
                        <th>Folder Name</th>
                        <th>Read</th>
                        <th>Read/Write</th>
                        <th>Full Permission</th>
                        <th>View Only</th>
                    </tr>
                </thead>
                <tbody id="foldersTableBody">
                    <!-- Folders will be loaded here dynamically -->
                </tbody>
            </table>
            <button id="savePermissionsBtn" class="btn btn-primary">Save Permissions</button>
        </div>
    <?php else : ?>
        <div class="alert alert-danger" role="alert">
            You do not have rights to access this module.
            <p class="text-muted">Only HOD (Head Of Department) having access of this moduel.</p>
        </div>
    <?php endif; ?>
    <!-- Modal for Remarks -->
    <div class="modal fade" id="remarksModal" tabindex="-1" aria-labelledby="remarksModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="remarksModalLabel">Add Remarks</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <textarea id="remarks" class="form-control" rows="3"></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" id="saveRemarksBtn" class="btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('userSelect').addEventListener('change', function() {
                const userId = this.value;
                if (userId) {
                    loadFolders();
                } else {
                    document.getElementById('foldersContainer').style.display = 'none';
                }
            });

            function loadFolders() {
                const userId = document.getElementById('userSelect').value;

                fetch(`get_folders_permissions.php?userId=${userId}`)
                    .then(response => response.json())
                    .then(data => {
                        const folders = data.folders;
                        const permissions = data.permissions;

                        const foldersTableBody = document.getElementById('foldersTableBody');
                        foldersTableBody.innerHTML = '';

                        folders.forEach((folder, index) => {
                            const row = document.createElement('tr');
                            const userPermission = permissions.find(p => p.Folderid == folder.id) || {};

                            row.innerHTML = `
                        <td>${index + 1}</td>
                        <td>${folder.Foldername}</td>
                        <td><input type="checkbox" class="permission-checkbox" data-folder-id="${folder.id}" data-permission="read" ${userPermission.Permission_type === 'read' ? 'checked' : ''}></td>
                        <td><input type="checkbox" class="permission-checkbox" data-folder-id="${folder.id}" data-permission="read_write" ${userPermission.Permission_type === 'read_write' ? 'checked' : ''}></td>
                        <td><input type="checkbox" class="permission-checkbox" data-folder-id="${folder.id}" data-permission="full_permission" ${userPermission.Permission_type === 'full_permission' ? 'checked' : ''}></td>
                        <td><input type="checkbox" class="permission-checkbox" data-folder-id="${folder.id}" data-permission="view_only" ${userPermission.Permission_type === 'view_only' ? 'checked' : ''}></td>
                        <td><input type="checkbox" class="permission-checkbox" data-folder-id="${folder.id}" data-permission="no_access" ${userPermission.Permission_type === 'no_access' ? 'checked' : ''}></td>
                    `;
                            foldersTableBody.appendChild(row);
                        });

                        document.querySelectorAll('.permission-checkbox').forEach(checkbox => {
                            checkbox.addEventListener('change', handlePermissionChange);
                        });

                        document.getElementById('foldersContainer').style.display = 'block';
                    })
                    .catch(error => console.error('Error fetching folders or permissions:', error));
            }

            function handlePermissionChange(event) {
                const checkbox = event.target;
                const row = checkbox.closest('tr');
                const permission = checkbox.getAttribute('data-permission');

                const checkboxes = row.querySelectorAll('.permission-checkbox');
                if (permission === 'full_permission' && checkbox.checked) {
                    checkboxes.forEach(cb => {
                        if (cb !== checkbox) {
                            cb.checked = false;
                            cb.disabled = true;
                        }
                    });
                } else if (permission === 'no_access' && checkbox.checked) {
                    checkboxes.forEach(cb => {
                        if (cb !== checkbox) {
                            cb.checked = false;
                            cb.disabled = true;
                        }
                    });
                } else {
                    checkboxes.forEach(cb => {
                        cb.disabled = false;
                    });
                }
            }

            document.getElementById('savePermissionsBtn').addEventListener('click', function() {
                const userId = document.getElementById('userSelect').value;
                const permissions = [];

                document.querySelectorAll('.permission-checkbox').forEach(checkbox => {
                    if (checkbox.checked) {
                        permissions.push({
                            folderId: checkbox.getAttribute('data-folder-id'),
                            permission: checkbox.getAttribute('data-permission')
                        });
                    }
                });

                const remarksModal = new bootstrap.Modal(document.getElementById('remarksModal'));
                remarksModal.show();

                document.getElementById('saveRemarksBtn').addEventListener('click', function() {
                    const remarks = document.getElementById('remarks').value;
                    savePermissions(userId, permissions, remarks);
                });
            });

            function savePermissions(userId, permissions, remarks) {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'save_permissions.php', true);
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4) {
                        if (xhr.status === 200) {
                            try {
                                const response = JSON.parse(xhr.responseText);
                                if (response.success) {
                                    alert('Permissions saved successfully');
                                    location.reload();
                                } else {
                                    alert('Error saving permissions: ' + response.message);
                                }
                            } catch (e) {
                                console.error('Invalid JSON response', e);
                            }
                        } else {
                            console.error('Server error: ' + xhr.status);
                        }
                    }
                };

                const data = {
                    userId: userId,
                    permissions: permissions,
                    remarks: remarks
                };
                xhr.send(JSON.stringify(data));
            }
        });
    </script>