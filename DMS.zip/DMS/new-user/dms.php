<?php
include 'session_check.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include 'functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get user details from session or database
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$fullname = $_SESSION['fullname']; // Assuming this is set in the session
$email = $_SESSION['email']; // Assuming this is set in the session
$department_id = $_SESSION['department_id']; // Example, assuming this exists

// Fetch user's access code from the database
$userAccessCode = getAccessCode($user_id);

// Translate access code to human-readable permissions
$userPermissions = translateAccessCode($userAccessCode);

// Example URL encryption and passing department ID
$encryptedDepartmentId = base64_encode(openssl_encrypt($department_id, 'AES-256-CBC', 'encryption_key', OPENSSL_RAW_DATA, '1234567890123456'));
$department_name = getDepartmentNameById($department_id);
$folders = fetchFolders();
$employees = getEmployeesByDepartmentId($department_id);
// Fetch users in the same department
$users = getUsersByDepartment($department_id);

// Fetch folders for the department
$folders_fun1 = getFoldersByDepartment($department_id);
// Handle form submissions for folder creation, update, and deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_folder'])) {
        // Handle folder creation
        $foldername = $_POST['foldername'];
        $departmentId = $_POST['department_id'];
        $departmentName = $_POST['department_name'];
        $createdBy = $_POST['created_by'];

        // Check for duplicate folder name
        if (isDuplicateFolderName($foldername, $departmentId)) {
            $_SESSION['folder_error_message'] = "Folder '$foldername' already exists.";
        } else {
            if (createFolder($foldername, $departmentId, $departmentName, $createdBy)) {
                $_SESSION['folder_success_message'] = "Folder '$foldername' created successfully.";
            } else {
                $_SESSION['folder_error_message'] = "Error creating folder.";
            }
        }
    } elseif (isset($_POST['edit_folder'])) {
        // Handle folder update
        $folderId = $_POST['folder_id'];
        $newFolderName = $_POST['new_foldername'];

        if (updateFolderName($folderId, $newFolderName)) {
            $_SESSION['folder_success_message'] = "Folder name updated successfully.";
        } else {
            $_SESSION['folder_error_message'] = "Error updating folder name.";
        }
    } elseif (isset($_POST['delete_folder'])) {
        // Handle folder deletion (soft delete)
        $folderId = $_POST['folder_id'];

        if (deleteFolder($folderId)) {
            $_SESSION['folder_success_message'] = "Folder deleted successfully.";
        } else {
            $_SESSION['folder_error_message'] = "Error deleting folder.";
        }
    }

    header("Location: dms.php");
    exit;
}

// Check for duplicate folder name
function isDuplicateFolderName($foldername, $departmentId)
{
    global $conn;
    $sql = "SELECT COUNT(*) AS count FROM master_folder WHERE Foldername = :foldername AND DepartmentId = :departmentId";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':foldername', $foldername);
    $stmt->bindParam(':departmentId', $departmentId);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    return $result['count'] > 0;
}

// Create a new folder
function createFolder($foldername, $departmentId, $departmentName, $createdBy)
{
    global $conn;
    $sql = "INSERT INTO master_folder (Foldername, DepartmentId, DepartmentName, Createdby, lastupdatedby) 
            VALUES (:foldername, :departmentId, :departmentName, :createdBy, :lastUpdatedBy)";

    try {
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':foldername', $foldername);
        $stmt->bindParam(':departmentId', $departmentId);
        $stmt->bindParam(':departmentName', $departmentName);
        $stmt->bindParam(':createdBy', $createdBy);
        $stmt->bindParam(':lastUpdatedBy', $createdBy);
        return $stmt->execute();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}
// Example logout URL
$logout_url = 'logout.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DMS</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            background-color: #f8f9fa;
            padding: 50px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .text-center {
            color: #343a40;
        }

        .icon {
            font-size: 50px;
            color: #007bff;
            margin-bottom: 20px;
        }

        .subtext {
            color: #6c757d;
        }
    </style>
</head>

<body>
    <div class="main-body">
        <div class="side-bar">
            <button class="collapse-btn" id="collapse-btn"><i class="bi bi-list"></i></button>
            <div class="side-bar-li active" id="dashboard">
                <i class="bi bi-house-exclamation-fill"></i> <span>Home</span>
            </div>
            <?php if (in_array('HOD', $userPermissions)) : ?>
                <?php
                include 'hodsidebar.php';
                ?>
            <?php endif; ?>
            <?php if (in_array('HOD', $userPermissions) || in_array('Full-Department-control', $userPermissions)) : ?>
                <?php
                include 'sidebar-file-hod.php';
                ?>
            <?php endif; ?>
            <div class="side-bar-li" id="gsearch">
                <i class="bi bi-search"></i> <span>Global Search</span>
            </div>
            <div class="side-bar-li" id="profile">
                <i class="bi bi-person-fill"></i> <span>Profile</span>
            </div>
            <div class="side-bar-li last-li" id="help">
                <i class="bi bi-question-circle-fill"></i> <span>Help</span>
            </div>
            <div class="toggle-switch">
                <a href="logout.php" id="logout-link"><i class="bi bi-box-arrow-right" style="font-size: 2rem;"></i></a>
            </div>


        </div>
        <div class="main-content">
            <!--hod-->
            <style>
                .fixed-buttons {
                    position: fixed;
                    top: 0;

                    z-index: 1000;

                    padding: 10px;
                    border-bottom: 1px solid #ddd;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    width: 80% !important;
                    float: right;
                }
            </style>

            <div class="content active" id="dashboard-content">
                <div class="mt-5 text-center">
                    My Folders
                    <i class="bi bi-house-door"></i>
                </div>
                <div class="container-fluid">
                    <div class="fixed-buttons">
                        <button id="backButton" class="btn btn-outline-secondary"><i class="bi bi-arrow-return-left"></i> </button>
                        <button class="btn btn-outline-secondary" onclick="reloadIframe()">
                            <i class="bi bi-arrow-clockwise"></i> Reload
                        </button>
                    </div>
                    <iframe id="folderIframe" src="folders.php" width="100%" height="1000px" frameborder="0" style="margin-top: 50px;"></iframe>
                </div>
            </div>
            <!---folder--->
            <?php if (in_array('HOD', $userPermissions) || in_array('Full-Department-control', $userPermissions)) : ?>
                <div class="content active" id="folders-content">

                    <?php
                    include 'folder_per.php';
                    ?>
                </div>

            <?php endif; ?>


            <div class="content" id="departments-content">
                <H1 class="TEXT-CENTER">Department</H1>

                <p>Department: <?php echo htmlspecialchars($department_name); ?></p>

            </div>
            <?php if (in_array('HOD', $userPermissions)) : ?>
                <!---emp--->
                <div class="content" id="usermgmt-content">
                    <H1 class="TEXT-CENTER"><?php echo htmlspecialchars($department_name); ?></H1>

                    <?php
                    include 'emp.php';
                    ?>

                </div>
            <?php endif; ?>
            <div class="content" id="customize-content">
                <h2>Customize</h2>
                <p>Customize your settings here.</p>
            </div>
            <div class="content" id="employee-content">
                <h2>Employee Data</h2>
                <p>Here is the Employee Data.</p>
            </div>
            <div class="content" id="asset-content">
                <h2>Asset</h2>

            </div>
            <div class="content" id="profile-content">
                <h2>Profile</h2>
                <p>View your profile here.</p>
                <div class="container mt-5">
                    <h3>Change Password</h3>
                    <div id="messageContainer"></div>
                    <form id="changePasswordForm" method="POST" action="change_password.php">
                        <div class="mb-3">
                            <label for="currentPassword" class="form-label">Current Password</label>
                            <input type="password" class="form-control" id="currentPassword" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="newPassword" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="newPassword" name="new_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="confirmPassword" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirmPassword" name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Change Password</button>
                    </form>
                </div>
            </div>
            <div class="content" id="gsearch-content">

                <div class="container-fluid">
                    <div class="fixed-buttons">
                        <button id="backButton" class="btn btn-outline-secondary"><i class="bi bi-arrow-return-left"></i> </button>
                        <button class="btn btn-outline-secondary" onclick="reloadIframe1()">
                            <i class="bi bi-arrow-clockwise"></i> Reload
                        </button>
                    </div>
                    <iframe id="folderIframe2" src="search.php" width="100%" height="1000px" frameborder="0" style="margin-top: 50px;"></iframe>
                </div>
            </div>
            <div class="content" id="help-content">
                <?php if (in_array('HOD', $userPermissions) || in_array('Full-Department-control', $userPermissions)) : ?>
                    <iframe src="helphod.html" width="100%" height="1000px" frameborder="0"></iframe>
                <?php endif; ?>
            </div>
            <?php
            include '../footer.php';
            ?>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script src="../script.js"></script>
    <script>
        document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const form = e.target;
            const formData = new FormData(form);

            fetch('ajax/change_password.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    const messageContainer = document.getElementById('messageContainer');
                    if (data.success) {
                        messageContainer.innerHTML = `<div class="alert alert-success" role="alert">${data.message}</div>`;
                        form.reset();
                    } else {
                        messageContainer.innerHTML = `<div class="alert alert-danger" role="alert">${data.message}</div>`;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        });
        document.getElementById('backButton').addEventListener('click', function() {
            window.history.back();
        });

        function reloadIframe() {
            document.getElementById('folderIframe').contentWindow.location.reload();
        }

        function reloadIframe1() {
            document.getElementById('folderIframe2').contentWindow.location.reload();
        }


        // Pass folder data to the edit modal
        var editFolderModal = document.getElementById('editFolderModal');
        editFolderModal.addEventListener('show.bs.modal', function(event) {
            var button = event.relatedTarget;
            var folderId = button.getAttribute('data-folder-id');
            var folderName = button.getAttribute('data-folder-name');

            var modalTitle = editFolderModal.querySelector('.modal-title');
            var modalBodyInput = editFolderModal.querySelector('.modal-body input#edit_foldername');
            var modalBodyIdInput = editFolderModal.querySelector('.modal-body input#edit_folder_id');

            modalTitle.textContent = 'Edit Folder: ' + folderName;
            modalBodyInput.value = folderName;
            modalBodyIdInput.value = folderId;
        });

        document.getElementById('logout-link').addEventListener('click', function(event) {
            event.preventDefault(); // Prevent the default link behavior

            // Perform the logout action, such as making a request to the server
            window.location.href = 'logout.php';
        });
    </script>
</body>

</html>