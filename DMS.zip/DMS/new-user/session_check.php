<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_id'])) {
    header("Location: login.php");
    exit();
}

// Optionally, you can also check the session ID against the database to ensure it matches
require 'db.php';
$user_id = $_SESSION['user_id'];
$session_id = $_SESSION['session_id'];

$stmt = $conn->prepare("SELECT session_id FROM user_sessions WHERE user_id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$db_session_id = $stmt->fetchColumn();

if ($db_session_id !== $session_id) {
    session_unset();
    session_destroy();
    header("Location: login.php?message=Logged in from another device.");
    exit();
}
