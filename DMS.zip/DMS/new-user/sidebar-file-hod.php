<div class="side-bar-li" id="folders">
    <i class="bi bi-folder"></i> <span>Folders</span>
</div>
<div class="side-bar-li" id="departments">
    <i class="bi bi-briefcase-fill"></i> <span>My Departments</span>
</div>