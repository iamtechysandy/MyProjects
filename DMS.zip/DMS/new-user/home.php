<?php
require 'session_check.php';

require 'db.php';
include 'functions.php';

$inactivityLimit = 15 * 60; // 15 minutes

if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$session_id = $_SESSION['session_id'];
$username = $_SESSION['username'];
$fullname = $_SESSION['fullname'];
$email = $_SESSION['email'];
$department_id = $_SESSION['department_id']; // Example, assuming this exists
$status = $_SESSION['status']; // Example, assuming this exists
$role = $_SESSION['role'];

// Check if session ID in database matches the session ID in the current session
$stmt = $conn->prepare("SELECT session_id FROM user_sessions WHERE user_id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$db_session_id = $stmt->fetchColumn();

if ($db_session_id !== $session_id) {
    session_unset();
    session_destroy();
    header("Location: login.php?message=Logged in from another device.");
    exit();
}

// Check for inactivity
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $inactivityLimit) {
    session_unset();
    session_destroy();
    header("Location: login.php?message=Session expired due to inactivity.");
    exit();
}

$_SESSION['last_activity'] = time();
// Update the last activity time in the database
$stmt = $conn->prepare("UPDATE user_sessions SET last_activity = NOW() WHERE user_id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();

// Update the last activity time in the database
$stmt = $conn->prepare("UPDATE user_sessions SET last_activity = NOW() WHERE user_id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
// Fetch total number of files by file type
function fetchTotalFilesByType($conn, $department_id)
{
    $sql = "SELECT filetype, COUNT(*) as count 
            FROM uploaded_content 
            WHERE department_id = :department_id AND `delete` = 1
            GROUP BY filetype";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['department_id' => $department_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function fetchLoginDetails($conn, $user_id)
{
    $stmt = $conn->prepare("SELECT login_time, ip_address FROM user_sessions WHERE user_id = :user_id AND session_id = :session_id");
    $stmt->execute(['user_id' => $user_id, 'session_id' => session_id()]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

$loginDetails = fetchLoginDetails($conn, $user_id);
// Fetch total number of files in folders
function fetchTotalFilesInFolders($conn, $department_id)
{
    $sql = "SELECT uc.folderid, uc.is_subfolder, 
                   CASE 
                       WHEN uc.is_subfolder = 0 THEN mf.Foldername 
                       ELSE sf.sub_folder_name 
                   END as folder_name, 
                   COUNT(*) as count 
            FROM uploaded_content uc
            LEFT JOIN master_folder mf ON uc.folderid = mf.id AND uc.is_subfolder = 0
            LEFT JOIN sub_folders sf ON uc.folderid = sf.id AND uc.is_subfolder = 1
            WHERE uc.department_id = :department_id AND uc.`delete` = 1
            GROUP BY uc.folderid, uc.is_subfolder";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['department_id' => $department_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch total number of subfolders under each master folder
function fetchTotalSubfolders($conn, $department_id)
{
    $subfolderCounts = [];

    // Fetch all master folders for the department
    $sql = "SELECT id, Foldername 
            FROM master_folder 
            WHERE DepartmentId = :department_id AND deleted = 1";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['department_id' => $department_id]);
    $masterFolders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($masterFolders as $folder) {
        $masterFolderId = $folder['id'];
        $subfolderCounts[$folder['Foldername']] = getSubfolderCount($conn, $masterFolderId);
    }

    return $subfolderCounts;
}

function getSubfolderCount($conn, $folderId)
{
    $count = 0;

    // Fetch direct subfolders
    $sql = "SELECT id 
            FROM sub_folders 
            WHERE master_folder_id = :folderId AND deleted = 1";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['folderId' => $folderId]);
    $subfolders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($subfolders as $subfolder) {
        $count += 1 + getSubfolderCount($conn, $subfolder['id']); // Add subfolder and its subfolders count
    }

    return $count;
}

// Fetch total number of deleted files by file type
function fetchDeletedFilesByType($conn, $department_id)
{
    $sql = "SELECT filetype, COUNT(*) as count 
            FROM uploaded_content 
            WHERE department_id = :department_id AND `delete` = 0
            GROUP BY filetype";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['department_id' => $department_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch total number of deleted folders
function fetchDeletedFolders($conn, $department_id)
{
    $sql = "SELECT 
                COUNT(CASE WHEN sf.deleted = 0 THEN 1 END) AS subfolders_deleted,
                COUNT(CASE WHEN mf.deleted = 0 THEN 1 END) AS masterfolders_deleted
            FROM master_folder mf
            LEFT JOIN sub_folders sf ON mf.id = sf.master_folder_id
            WHERE mf.DepartmentId = :department_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['department_id' => $department_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function fetchDeletedFilesCount($conn, $departmentId)
{
    $sql = "SELECT COUNT(*) FROM uploaded_content WHERE department_id = :departmentId AND `delete` = 0";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['departmentId' => $departmentId]);
    return $stmt->fetchColumn();
}

function fetchDeletedFiles($conn, $departmentId)
{
    $sql = "SELECT * FROM uploaded_content WHERE department_id = :departmentId AND `delete` = 0";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['departmentId' => $departmentId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$deletedFilesCount = fetchDeletedFilesCount($conn, $department_id);
$deletedFiles = fetchDeletedFiles($conn, $department_id);

function getEmployeeNameById($conn, $id)
{
    $sql = "SELECT fullname FROM employees WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $id]);
    return $stmt->fetchColumn();
}

$logout_url = 'logout.php'; // Update with your actual logout script path
$totalFilesByType = fetchTotalFilesByType($conn, $department_id);
$totalFilesInFolders = fetchTotalFilesInFolders($conn, $department_id);
$totalSubfolders = fetchTotalSubfolders($conn, $department_id);
$deletedFilesByType = fetchDeletedFilesByType($conn, $department_id);
$deletedFolders = fetchDeletedFolders($conn, $department_id);
$department_name = getDepartmentNameById($department_id);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home DMS</title>
    <link rel="stylesheet" href="../style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-container {
            position: relative;
            margin: auto;
            height: 400px;


            box-shadow: 11px 7px 14px -3px rgba(150, 123, 150, 1);
            background-color: #ffffff;
            border-radius: 10px;
            padding: 20px;
        }

        body {
            overflow-x: hidden !important;
            background-color: #f8f9fa;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        }

        .card-header {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            color: white;
            font-weight: bold;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            border: none;
        }

        .btn-danger {
            background: linear-gradient(135deg, #dc3545 0%, #b21f3a 100%);
            border: none;
        }

        .chart-container h3 {
            text-align: center;
            margin-bottom: 20px;
        }

        canvas {
            max-width: 300px;
            max-height: 300px;
        }

        footer p {
            text-align: center !important;
            padding: 0rem !important;
        }

        .collapsible {
            cursor: pointer;
            padding: 10px;

            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
        }

        .active,
        .collapsible:hover {
            background-color: #ccc;
        }

        .content {
            display: none;
            overflow: hidden;
            padding: 0 18px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">

        <button class="btn btn-outline-primary collapsible">Deleted Files In Department
            <span class="badge bg-danger"><i class="bi bi-trash3-fill"></i> <?php echo $deletedFilesCount; ?></span>
        </button>

        <div class="content">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Document Number</th>
                            <th>Original Filename</th>
                            <th>File Size</th>
                            <th>File Type</th>
                            <th>Document Type</th>
                            <th>Expiry Date</th>
                            <th>Uploaded Date</th>
                            <th>Uploaded By</th>
                            <th>Deleted By</th>
                            <th>Deleted On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($deletedFiles as $file) : ?>
                            <tr>
                                <td><?php echo htmlspecialchars($file['doc_number']); ?></td>
                                <td><?php echo htmlspecialchars($file['orginalfilename']); ?></td>
                                <td><?php echo htmlspecialchars($file['filesize']); ?></td>
                                <td><?php echo htmlspecialchars($file['filetype']); ?></td>
                                <td><?php echo htmlspecialchars($file['doc_type']); ?></td>
                                <td><?php echo htmlspecialchars($file['Expirydate']); ?></td>
                                <td><?php echo htmlspecialchars($file['uploadeddate']); ?></td>
                                <td><?php echo htmlspecialchars(getEmployeeNameById($conn, $file['uploadedby'])); ?></td>
                                <td><?php echo htmlspecialchars(getEmployeeNameById($conn, $file['deleted_by'])); ?></td>
                                <td><?php echo htmlspecialchars($file['deleted_on']); ?></td>
                                <td>
                                    <form method="POST" action="restore_file.php">
                                        <input type="hidden" name="id" value="<?php echo $file['id']; ?>">
                                        <button type="submit" class="btn btn-primary">Restore</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Rest of your folder content display code -->

    </div>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        Welcome, <?php echo htmlspecialchars($fullname); ?>
                    </div>
                    <div class="card-body">
                        <p>Username: <?php echo htmlspecialchars($username); ?></p>
                        <p>Email: <?php echo htmlspecialchars($email); ?></p>
                        <p>Department: <?php echo htmlspecialchars($department_name); ?></p>
                        <p>Status: <?php echo htmlspecialchars($status); ?></p>
                        <p>Role: <?php echo htmlspecialchars($role); ?></p>
                        <p>Login Time: <?php echo htmlspecialchars($loginDetails['login_time']); ?></p>
                        <p>IP Address: <?php echo htmlspecialchars($loginDetails['ip_address']); ?></p>
                        <a href="dms.php?dept=<?php echo urlencode(base64_encode($department_id)); ?>" class="btn btn-primary" target="_blank">
                            <i class="bi bi-folder"></i> Department Documents
                        </a>
                        <a href="<?php echo $logout_url; ?>" class="btn btn-danger">Logout</a>

                    </div>
                </div>
            </div>
        </div>
        <h2 class="text-center mt-5">Department Statistics</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="chart-container">
                    <h3>Total Files by File Type</h3>
                    <canvas id="filesByTypeChart"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="chart-container">
                    <h3>Total Files in Folders</h3>
                    <canvas id="filesInFoldersChart"></canvas>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-6">
                <div class="chart-container">
                    <h3>Total Subfolders under Each Master Folder</h3>
                    <canvas id="subfoldersChart"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="chart-container">
                    <h3>Deleted Files by File Type</h3>
                    <canvas id="deletedFilesByTypeChart"></canvas>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-6 offset-md-3">
                <div class="chart-container">
                    <h3>Deleted Folders</h3>
                    <canvas id="deletedFoldersChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <?php
    include '../footer.php';
    ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Data for Total Files by File Type
        const filesByTypeData = {
            labels: <?php echo json_encode(array_column($totalFilesByType, 'filetype')); ?>,
            datasets: [{
                label: 'Total Files',
                data: <?php echo json_encode(array_column($totalFilesByType, 'count')); ?>,
                backgroundColor: [
                    'rgba(0, 123, 255, 0.2)', // Soft Blue
                    'rgba(220, 53, 69, 0.2)', // Soft Red
                    'rgba(255, 193, 7, 0.2)', // Soft Yellow
                    'rgba(40, 167, 69, 0.2)', // Soft Green
                    'rgba(102, 16, 242, 0.2)', // Soft Purple
                    'rgba(255, 193, 7, 0.2)' // Soft Amber

                ],
                borderColor: [
                    'rgba(0, 123, 255, 1)', // Soft Blue
                    'rgba(220, 53, 69, 1)', // Soft Red
                    'rgba(255, 193, 7, 1)', // Soft Yellow
                    'rgba(40, 167, 69, 1)', // Soft Green
                    'rgba(102, 16, 242, 1)', // Soft Purple
                    'rgba(255, 193, 7, 1)' // Soft Amber
                ],
                borderWidth: 1
            }]
        };

        // Data for Total Files in Folders
        const filesInFoldersData = {
            labels: <?php echo json_encode(array_column($totalFilesInFolders, 'folder_name')); ?>,
            datasets: [{
                label: 'Total Files',
                data: <?php echo json_encode(array_column($totalFilesInFolders, 'count')); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        };

        // Data for Total Subfolders under Each Master Folder
        const subfoldersData = {
            labels: <?php echo json_encode(array_keys($totalSubfolders)); ?>,
            datasets: [{
                label: 'Total Subfolders',
                data: <?php echo json_encode(array_values($totalSubfolders)); ?>,
                backgroundColor: 'rgba(153, 102, 255, 0.2)',
                borderColor: 'rgba(153, 102, 255, 1)',
                borderWidth: 1
            }]
        };

        // Data for Deleted Files by File Type
        const deletedFilesByTypeData = {
            labels: <?php echo json_encode(array_column($deletedFilesByType, 'filetype')); ?>,
            datasets: [{
                label: 'Deleted Files',
                data: <?php echo json_encode(array_column($deletedFilesByType, 'count')); ?>,
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        };

        // Data for Deleted Folders
        const deletedFoldersData = {
            labels: ['Master Folders', 'Sub Folders'],
            datasets: [{
                label: 'Deleted Folders',
                data: [<?php echo $deletedFolders['masterfolders_deleted']; ?>, <?php echo $deletedFolders['subfolders_deleted']; ?>],
                backgroundColor: ['rgba(255, 159, 64, 0.2)', 'rgba(54, 162, 235, 0.2)'],
                borderColor: ['rgba(255, 159, 64, 1)', 'rgba(54, 162, 235, 1)'],
                borderWidth: 1
            }]
        };

        // Chart for Total Files by File Type
        new Chart(document.getElementById('filesByTypeChart'), {
            type: 'pie',
            data: filesByTypeData,
            options: {
                responsive: true
            }
        });

        // Chart for Total Files in Folders
        new Chart(document.getElementById('filesInFoldersChart'), {
            type: 'bar',
            data: filesInFoldersData,
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Chart for Total Subfolders under Each Master Folder
        new Chart(document.getElementById('subfoldersChart'), {
            type: 'bar',
            data: subfoldersData,
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Chart for Deleted Files by File Type
        new Chart(document.getElementById('deletedFilesByTypeChart'), {
            type: 'pie',
            data: deletedFilesByTypeData,
            options: {
                responsive: true
            }
        });

        // Chart for Deleted Folders
        new Chart(document.getElementById('deletedFoldersChart'), {
            type: 'doughnut',
            data: deletedFoldersData,
            options: {
                responsive: true
            }
        });
        document.querySelectorAll('.collapsible').forEach(button => {
            button.addEventListener('click', function() {
                this.classList.toggle('active');
                var content = this.nextElementSibling;
                if (content.style.display === "block") {
                    content.style.display = "none";
                } else {
                    content.style.display = "block";
                }
            });
        });
    </script>
</body>

</html>