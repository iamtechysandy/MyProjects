<div class="container">
    <h1>Employee Management</h1>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($employees as $employee) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($employee['id']); ?></td>
                    <td><?php echo htmlspecialchars($employee['username']); ?></td>
                    <td><?php echo htmlspecialchars($employee['fullname']); ?></td>
                    <td><?php echo htmlspecialchars($employee['email']); ?></td>
                    <td class="status-text"><?php echo $employee['status'] == 1 ? 'Enabled' : 'Disabled'; ?></td>
                    <td>
                        <button class="btn <?php echo $employee['status'] == 1 ? 'btn-danger' : 'btn-success'; ?> edit-status-btn" data-id="<?php echo htmlspecialchars($employee['id']); ?>" data-status="<?php echo $employee['status'] == 1 ? 'enabled' : 'disabled'; ?>">
                            <?php echo $employee['status'] == 1 ? 'Disable' : 'Enable'; ?>
                        </button>
                        <button class="btn btn-warning reset-password-btn" data-id="<?php echo htmlspecialchars($employee['id']); ?>">Reset Password</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.edit-status-btn').forEach(button => {
            button.addEventListener('click', function() {
                const employeeId = this.getAttribute('data-id');
                const currentStatus = this.getAttribute('data-status');

                // Toggle status
                const newStatus = currentStatus === 'enabled' ? 'disabled' : 'enabled';

                console.log(`Changing status of employee ID ${employeeId} from ${currentStatus} to ${newStatus}`);

                fetch('update_status.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: `id=${employeeId}&status=${newStatus}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        console.log('Response from server:', data);
                        if (data.success) {
                            alert('Status updated successfully.');
                            // Update button text and data-status attribute
                            this.setAttribute('data-status', newStatus);
                            this.textContent = newStatus === 'enabled' ? 'Disable' : 'Enable';
                            this.className = newStatus === 'enabled' ? 'btn btn-danger edit-status-btn' : 'btn btn-success edit-status-btn';
                            // Update the status text in the table
                            this.closest('tr').querySelector('td.status-text').textContent = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
                        } else {
                            alert('Failed to update status.');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error updating status.');
                    });
            });
        });
    });





    // Handle reset password button click
    document.querySelectorAll('.reset-password-btn').forEach(button => {
        button.addEventListener('click', function() {
            const employeeId = this.getAttribute('data-id');
            const newPassword = prompt('Enter the new password:');

            if (newPassword) {
                // Make an AJAX request to reset password
                fetch('reset_password.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            id: employeeId,
                            password: newPassword
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Password reset successfully.');
                        } else {
                            alert('Failed to reset password.');
                        }
                    });
            }
        });
    });
</script>