<div class="side-bar-li" id="usermgmt">
    <i class="bi bi-laptop-fill"></i> <span>User Management</span>
</div>