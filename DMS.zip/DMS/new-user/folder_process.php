<?php
session_start();
include 'functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $foldername = $_POST['foldername'];
    $departmentId = $_POST['department_id'];
    $departmentName = $_POST['department_name'];
    $createdBy = $_POST['created_by'];

    // Check if foldername already exists
    $checkSql = "SELECT COUNT(*) AS count FROM master_folder WHERE Foldername = :foldername AND DepartmentId = :departmentId";
    $stmt = $conn->prepare($checkSql);
    $stmt->bindParam(':foldername', $foldername);
    $stmt->bindParam(':departmentId', $departmentId);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result['count'] > 0) {
        // Folder name already exists for the department
        $_SESSION['folder_error_message'] = "Folder '$foldername' already exists for this department.";
        header("Location: newdms.php");
        exit;
    }

    // Insert into master_folder table
    $insertSql = "INSERT INTO master_folder (Foldername, DepartmentId, DepartmentName, Createdby, lastupdatedby) 
                  VALUES (:foldername, :departmentId, :departmentName, :createdBy, :lastUpdatedBy)";

    try {
        $stmt = $conn->prepare($insertSql);
        $stmt->bindParam(':foldername', $foldername);
        $stmt->bindParam(':departmentId', $departmentId);
        $stmt->bindParam(':departmentName', $departmentName);
        $stmt->bindParam(':createdBy', $createdBy);
        $stmt->bindParam(':lastUpdatedBy', $createdBy); // Assuming createdBy is also lastUpdatedBy initially
        $stmt->execute();

        // Set success message in session
        $_SESSION['folder_success_message'] = "Folder '$foldername' created successfully.";

        // Redirect back to create_folder.php
        header("Location: newdms.php");
        exit;
    } catch (PDOException $e) {
        // Set error message in session for database error
        $_SESSION['folder_error_message'] = "Error creating folder: " . $e->getMessage();
        header("Location: create_folder.php");
        exit;
    }
} else {
    // Handle invalid request method
    $_SESSION['folder_error_message'] = "Invalid request method.";
    header("Location: create_folder.php");
    exit;
}
